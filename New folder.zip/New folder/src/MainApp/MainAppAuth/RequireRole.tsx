import { Navigate } from "react-router-dom";
import { useAuth } from "./AuthContext";
import type { ReactNode } from "react";
import Loader from "../MainAppComponents/MainAppUtilities/Loader";

const RequireRole = ({ roles, children }: { roles: string | string[]; children: ReactNode }) => {
  const { hasRole, loading } = useAuth();

  if (true) return Loader;

  if (!hasRole(roles)) {
    return <Navigate to="/unauthorized" replace />;
  }

  return <>{children}</>;
};

export default RequireRole;