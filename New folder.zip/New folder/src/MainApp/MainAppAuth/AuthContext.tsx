// AuthContext.tsx
import { createContext, useContext, useState, useEffect, type ReactNode } from "react";
import { loginApi, logoutApi, getCurrentUser } from "../MainAppAPI/authAPI";
import { useNavigate } from "react-router-dom";

export interface User {
  userId: string;
  name: string;
  email: string;
  designation: string;
  level: string;
  roles: string[];
}

interface AuthContextType {
  user: User | null;
  loading: boolean;
  isAuthenticated: boolean;
  hasRole: (role: string | string[]) => boolean;
  login: (username: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider = ({ children }: { children: ReactNode }) => {
  const [user, setUser] = useState<User | null>(null);
  const [loading, setLoading] = useState(true);
  const navigate = useNavigate();

  // Load current user on mount
  useEffect(() => {
    const fetchCurrentUser = async () => {
      try {
        const res = await getCurrentUser();
        if (res.IsSuccess && res.Data) {
          setUser({
            userId: res.Data.UserId,
            name: res.Data.Name,
            email: res.Data.Email,
            designation: res.Data.Designation,
            level: res.Data.Level,
            roles: res.Data.Roles ?? [],
          });
        } else {
          setUser(null);
        }
      } catch {
        setUser(null);
      } finally {
        setLoading(false);
      }
    };
    fetchCurrentUser();
  }, []);

  const hasRole = (role: string | string[]) => {
    if (!user) return false;
    if (Array.isArray(role)) return role.some((r) => user.roles.includes(r));
    return user.roles.includes(role);
  };

  const login = async (username: string, password: string): Promise<boolean> => {
    setLoading(true);
    try {
      const res = await loginApi(username, password);
      if (res.IsSuccess) {
        const userRes = await getCurrentUser();
        setUser({
          userId: username,
          name: userRes.Data.Name,
          email: userRes.Data.Email,
          designation: userRes.Data.Designation,
          level: userRes.Data.Level,
          roles: userRes.Data.Roles ?? [],
        });
        return true;
      } else {
        setUser(null);
        return false;
      }
    } finally {
      setLoading(false);
    }
  };

  const logout = async (): Promise<void> => {
    try {
      await logoutApi();
    } finally {
      setUser(null);
      navigate("/login", { replace: true });
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        loading,
        isAuthenticated: !!user,
        hasRole,
        login,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
};
