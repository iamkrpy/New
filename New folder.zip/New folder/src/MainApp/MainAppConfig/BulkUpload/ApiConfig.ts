import { type BulkUploadRequest, type BulkUploadResponseRow } from "./types";

export async function uploadBulkData(
  payload: BulkUploadRequest,
  apiUrl: string
): Promise<{ rowResults: BulkUploadResponseRow[] } | BulkUploadResponseRow[]> {
  try {
    const res = await fetch(apiUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
    });

    if (!res.ok) {
      const text = await res.text();
      throw new Error(text || "Upload failed");
    }

    const data = await res.json();

    // Ensure consistent return type
    if (Array.isArray(data)) return data as BulkUploadResponseRow[];
    if (data.rowResults && Array.isArray(data.rowResults)) return data;
    throw new Error("Unexpected API response format");
  } catch (err) {
    console.error("Bulk upload error:", err);
    throw err;
  }
}
