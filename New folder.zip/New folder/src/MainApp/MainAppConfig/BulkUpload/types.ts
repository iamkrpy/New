export type ColumnType = "string" | "number" | "date" | "boolean";

export interface ColumnDefinition {
  excelColumn: string; // Name in Excel
  dbColumn: string;    // Name in DB payload
  required?: boolean;
  type?: ColumnType;
  maxLength?: number;
  regex?: RegExp;
  enum?: string[];
  unique?: boolean;
  uniqueWith?: string[];
  defaultValue?: string;
}

export interface BulkUploadProps {
  apiUrl: string;
  columns: ColumnDefinition[];
  onUploadSuccess?: (results: BulkUploadResult[]) => void;
  onUploadError?: (err: Error) => void;
  isOpen?: boolean;
  onClose?: () => void;
}

export interface BulkUploadResult {
  rowIndex: number;
  status: "success" | "error";
  remarks?: string;
  data: Record<string, any>;
}

export interface BulkUploadResponseRow {
  rowIndex: number;
  status: "success" | "error";
  remarks?: string;
  rowResults?: {
    field: string;
    message: string;
    isValid: boolean;
  }[];
}

export interface BulkUploadRequest<T = any> {
  data: T[];
}
