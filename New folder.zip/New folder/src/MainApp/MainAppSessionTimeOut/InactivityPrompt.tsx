// InactivityPrompt.tsx
import React from "react";

interface InactivityPromptProps {
  countdown: number;
  onContinue: () => void;
}

export const InactivityPrompt: React.FC<InactivityPromptProps> = ({
  countdown,
  onContinue,
}) => {
  return (
    <div style={styles.overlay}>
      <div style={styles.promptBox}>
        <p>You will be logged out in <strong>{countdown}</strong> seconds due to inactivity.</p>
        <button onClick={onContinue} style={styles.button}>Continue Session</button>
      </div>
    </div>
  );
};

const styles = {
  overlay: {
    position: "fixed" as const,
    top: 0,
    left: 0,
    width: "100vw",
    height: "100vh",
    backgroundColor: "rgba(0,0,0,0.5)",
    display: "flex",
    justifyContent: "center",
    alignItems: "center",
    zIndex: 9999,
  },
  promptBox: {
    background: "white",
    padding: "2rem",
    borderRadius: "12px",
    textAlign: "center" as const,
    boxShadow: "0 0 10px rgba(0,0,0,0.2)",
  },
  button: {
    marginTop: "1rem",
    padding: "0.5rem 1rem",
    fontSize: "1rem",
    cursor: "pointer",
  },
};
