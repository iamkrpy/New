import { useEffect, useRef, useState } from "react";

interface UseInactivityWithPromptOptions {
  idleTimeout: number;
  promptTimeout: number;
  onLogout: () => void;
}

export function useInactivityWithPrompt({ idleTimeout, promptTimeout, onLogout }: UseInactivityWithPromptOptions) {
  const [showPrompt, setShowPrompt] = useState(false);
  const [countdown, setCountdown] = useState(promptTimeout / 1000);
  const promptTimerRef = useRef<NodeJS.Timeout | null>(null);
  const idleTimerRef = useRef<NodeJS.Timeout | null>(null);

  const clearAllTimers = () => {
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    if (promptTimerRef.current) clearInterval(promptTimerRef.current);
  };

  const startIdleTimer = () => {
    if (idleTimerRef.current) clearTimeout(idleTimerRef.current);
    idleTimerRef.current = setTimeout(() => {
      setShowPrompt(true);
      setCountdown(promptTimeout / 1000); // start fresh countdown
    }, idleTimeout);
  };

  const resetActivity = () => {
    if (showPrompt) return;
    startIdleTimer();
  };

  const continueSession = () => {
    clearAllTimers();
    setShowPrompt(false);
    setCountdown(promptTimeout / 1000);
    startIdleTimer();
  };

  // Start countdown interval when prompt is shown
  useEffect(() => {
    if (!showPrompt) return;

    promptTimerRef.current = setInterval(() => {
      setCountdown((prev) => {
        if (prev <= 1) {
          clearInterval(promptTimerRef.current!);
          setShowPrompt(false);
          onLogout();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => {
      if (promptTimerRef.current) clearInterval(promptTimerRef.current);
    };
  }, [showPrompt]);

  useEffect(() => {
    const events = ["mousemove", "mousedown", "keydown", "touchstart"];
    events.forEach((event) => window.addEventListener(event, resetActivity));
    startIdleTimer();

    return () => {
      events.forEach((event) => window.removeEventListener(event, resetActivity));
      clearAllTimers();
    };
  }, []);

  return {
    showPrompt,
    countdown,
    continueSession,
  };
}
