
import { useNavigate } from "react-router-dom";
import { useInactivityWithPrompt } from "./Hook/useInactivityWithPrompt";
import { InactivityPrompt } from "./InactivityPrompt";

export default function InactivityHandler() {
  const navigate = useNavigate()
  const handleLogout = () => {
    // alert("You have been logged out due to inactivity.");
    navigate('/login')
    // Do logout logic here (token clear, route change, etc.)
  };

  const {
    showPrompt,
    countdown,
    continueSession,
  } = useInactivityWithPrompt({
    idleTimeout: 15 * 60 * 1000,    // 15 minutes
    promptTimeout: 2 * 60 * 1000,      // 2 minutes
    onLogout: handleLogout,
  });

  return (
    <div>

      {showPrompt && (
        <InactivityPrompt
          countdown={countdown}
          onContinue={continueSession}
        />
      )}
    </div>
  );
}
