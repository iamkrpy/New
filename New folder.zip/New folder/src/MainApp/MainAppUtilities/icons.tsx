import type { JSX } from "react";
import { FiHome, FiTool, FiSettings,FiShoppingCart } from "react-icons/fi";


export const iconMap: Record<string, JSX.Element> = {
    home: <FiShoppingCart />,
    tools: <FiTool />,
    settings: <FiSettings />,
  };
export const LogoutIcon = ({ className = "w-5 h-5" }) => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className={className}
    fill="none"
    viewBox="0 0 24 24"
    stroke="currentColor"
    strokeWidth={2}
  >
    <path
      strokeLinecap="round"
      strokeLinejoin="round"
      d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a2 2 0 01-2 2H5a2 2 0 01-2-2V7a2 2 0 012-2h6a2 2 0 012 2v1"
    />
  </svg>
);

export const HamburgerIcon = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className="w-10 h-8 text-gray-700 cursor-pointer"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M3 6h18M3 12h18M3 18h18" />
  </svg>
);

export const NotificationBell = () => (
  <svg
    xmlns="http://www.w3.org/2000/svg"
    className="w-6 h-6 text-gray-700 cursor-pointer"
    viewBox="0 0 24 24"
    fill="none"
    stroke="currentColor"
    strokeWidth="2"
    strokeLinecap="round"
    strokeLinejoin="round"
  >
    <path d="M18 8a6 6 0 10-12 0c0 7-3 9-3 9h18s-3-2-3-9" />
    <path d="M13.73 21a2 2 0 01-3.46 0" />
  </svg>
);

export const CollapseIcon = () => (
  <svg width="100%" height="100%" viewBox="0 0 48 48" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier"></g><g id="SVGRepo_tracerCarrier"></g><g id="SVGRepo_iconCarrier"> <title>collapse-fullscreen</title> <g id="Layer_2" data-name="Layer 2"> <g id="invisible_box" data-name="invisible box"> <rect width="48" height="48" fill="none"></rect> </g> <g id="icons_Q2" data-name="icons Q2"> <g> <path d="M8,26a2,2,0,0,0-2,2.3A2.1,2.1,0,0,0,8.1,30h7.1L4.7,40.5a2,2,0,0,0-.2,2.8A1.8,1.8,0,0,0,6,44a2,2,0,0,0,1.4-.6L18,32.8v7.1A2.1,2.1,0,0,0,19.7,42,2,2,0,0,0,22,40V28a2,2,0,0,0-2-2Z"></path> <path d="M43.7,4.8a2,2,0,0,0-3.1-.2L30,15.2V8.1A2.1,2.1,0,0,0,28.3,6,2,2,0,0,0,26,8V20a2,2,0,0,0,2,2H39.9A2.1,2.1,0,0,0,42,20.3,2,2,0,0,0,40,18H32.8L43.4,7.5A2.3,2.3,0,0,0,43.7,4.8Z"></path> </g> </g> </g> </g></svg>
)
export const ExpandIcon = () => (
  <svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path d="M14 10L21 3M21 3H15M21 3V9M10 14L3 21M3 21H9M3 21L3 15" stroke="#000000" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"></path> </g></svg>
)
export const DeleteIcon = () => (
  <svg width="100%" height="100%" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" fill="#000000"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M154 260h568v700H154z" fill="#ec665f"></path><path d="M624.428 261.076v485.956c0 57.379-46.737 103.894-104.391 103.894h-362.56v107.246h566.815V261.076h-99.864z" fill="#b94141"></path><path d="M320.5 870.07c-8.218 0-14.5-6.664-14.5-14.883V438.474c0-8.218 6.282-14.883 14.5-14.883s14.5 6.664 14.5 14.883v416.713c0 8.219-6.282 14.883-14.5 14.883zM543.5 870.07c-8.218 0-14.5-6.664-14.5-14.883V438.474c0-8.218 6.282-14.883 14.5-14.883s14.5 6.664 14.5 14.883v416.713c0 8.219-6.282 14.883-14.5 14.883z" fill="#152B3C"></path><path d="M721.185 345.717v-84.641H164.437z" fill="#b94141"></path><path d="M633.596 235.166l-228.054-71.773 31.55-99.3 228.055 71.773z" fill="#ec665f"></path><path d="M847.401 324.783c-2.223 0-4.475-0.333-6.706-1.034L185.038 117.401c-11.765-3.703-18.298-16.239-14.592-27.996 3.706-11.766 16.241-18.288 27.993-14.595l655.656 206.346c11.766 3.703 18.298 16.239 14.592 27.996-2.995 9.531-11.795 15.631-21.286 15.631z" fill="#ec665f"></path></g></svg>
)
export const RefreshIcon = () =>(
  <svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill-rule="evenodd" clip-rule="evenodd" d="M22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12ZM5.46056 11.0833C5.83331 7.79988 8.62404 5.25 12.0096 5.25C14.148 5.25 16.0489 6.26793 17.2521 7.84246C17.5036 8.17158 17.4406 8.64227 17.1115 8.89376C16.7824 9.14526 16.3117 9.08233 16.0602 8.7532C15.1289 7.53445 13.6613 6.75 12.0096 6.75C9.45213 6.75 7.33639 8.63219 6.9733 11.0833H7.33652C7.63996 11.0833 7.9135 11.2662 8.02953 11.5466C8.14556 11.8269 8.0812 12.1496 7.86649 12.364L6.69823 13.5307C6.40542 13.8231 5.9311 13.8231 5.63829 13.5307L4.47003 12.364C4.25532 12.1496 4.19097 11.8269 4.30699 11.5466C4.42302 11.2662 4.69656 11.0833 5 11.0833H5.46056ZM18.3617 10.4693C18.0689 10.1769 17.5946 10.1769 17.3018 10.4693L16.1335 11.636C15.9188 11.8504 15.8545 12.1731 15.9705 12.4534C16.0865 12.7338 16.3601 12.9167 16.6635 12.9167H17.0267C16.6636 15.3678 14.5479 17.25 11.9905 17.25C10.3464 17.25 8.88484 16.4729 7.9529 15.2638C7.70002 14.9358 7.22908 14.8748 6.90101 15.1277C6.57295 15.3806 6.512 15.8515 6.76487 16.1796C7.96886 17.7416 9.86205 18.75 11.9905 18.75C15.376 18.75 18.1667 16.2001 18.5395 12.9167H19C19.3035 12.9167 19.577 12.7338 19.693 12.4534C19.8091 12.1731 19.7447 11.8504 19.53 11.636L18.3617 10.4693Z" fill="#cfb820"></path> </g></svg>
)
export const SearchIcon = ({ fill = '#d97c54' }: { fill?: string }) => (
  <svg width="100%" height="100%" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g id="SVGRepo_bgCarrier" strokeWidth="0" />
    <g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round" />
    <g id="SVGRepo_iconCarrier">
      <rect width="24" height="24" fill="white" />
      <path
        fillRule="evenodd"
        clipRule="evenodd"
        d="M7.25007 2.38782C8.54878 2.0992 10.1243 2 12 2C13.8757 2 15.4512 2.0992 16.7499 2.38782C18.06 2.67897 19.1488 3.176 19.9864 4.01358C20.824 4.85116 21.321 5.94002 21.6122 7.25007C21.9008 8.54878 22 10.1243 22 12C22 13.8757 21.9008 15.4512 21.6122 16.7499C21.321 18.06 20.824 19.1488 19.9864 19.9864C19.1488 20.824 18.06 21.321 16.7499 21.6122C15.4512 21.9008 13.8757 22 12 22C10.1243 22 8.54878 21.9008 7.25007 21.6122C5.94002 21.321 4.85116 20.824 4.01358 19.9864C3.176 19.1488 2.67897 18.06 2.38782 16.7499C2.0992 15.4512 2 13.8757 2 12C2 10.1243 2.0992 8.54878 2.38782 7.25007C2.67897 5.94002 3.176 4.85116 4.01358 4.01358C4.85116 3.176 5.94002 2.67897 7.25007 2.38782ZM9 11.5C9 10.1193 10.1193 9 11.5 9C12.8807 9 14 10.1193 14 11.5C14 12.8807 12.8807 14 11.5 14C10.1193 14 9 12.8807 9 11.5ZM11.5 7C9.01472 7 7 9.01472 7 11.5C7 13.9853 9.01472 16 11.5 16C12.3805 16 13.202 15.7471 13.8957 15.31L15.2929 16.7071C15.6834 17.0976 16.3166 17.0976 16.7071 16.7071C17.0976 16.3166 17.0976 15.6834 16.7071 15.2929L15.31 13.8957C15.7471 13.202 16 12.3805 16 11.5C16 9.01472 13.9853 7 11.5 7Z"
        fill={fill}
      />
    </g>
  </svg>
);

export const ColumnsIcon = ({ fill1 = "#7DD2F0", fill2 = "#6AB2CC" }: { fill1?: string; fill2?: string }) => (
  <svg height="100%" width="100%" viewBox="0 0 512 512" fill="none" xmlns="http://www.w3.org/2000/svg">
    <g id="SVGRepo_bgCarrier" strokeWidth="0" />
    <g id="SVGRepo_tracerCarrier" strokeLinecap="round" strokeLinejoin="round" />
    <g id="SVGRepo_iconCarrier">
      {/* Top Left Box */}
      <path style={{ fill: fill1 }} d="M197.999,47.933H31.943c-12.941,0-23.433,10.492-23.433,23.433V114.8c0,12.941,10.492,23.433,23.433,23.433h166.057c12.941,0,23.433-10.492,23.433-23.433V71.366C221.432,58.424,210.941,47.933,197.999,47.933z" />
      
      {/* Top Right Box */}
      <path style={{ fill: fill1 }} d="M314.001,47.933h166.057c12.941,0,23.433,10.492,23.433,23.433V114.8c0,12.941-10.492,23.433-23.433,23.433H314.001c-12.941,0-23.433-10.492-23.433-23.433V71.366C290.568,58.424,301.058,47.933,314.001,47.933z" />
      
      {/* Middle Boxes */}
      <path style={{ fill: fill1 }} d="M197.999,210.85H31.943c-12.941,0-23.433,10.492-23.433,23.433v43.434c0,12.941,10.492,23.433,23.433,23.433h166.057c12.941,0,23.433-10.492,23.433-23.433v-43.434C221.432,221.342,210.941,210.85,197.999,210.85z" />
      <path style={{ fill: fill1 }} d="M314.001,210.85h166.057c12.941,0,23.433,10.492,23.433,23.433v43.434c0,12.941-10.492,23.433-23.433,23.433H314.001c-12.941,0-23.433-10.492-23.433-23.433v-43.434C290.568,221.342,301.058,210.85,314.001,210.85z" />
      
      {/* Bottom Boxes */}
      <path style={{ fill: fill2 }} d="M197.999,373.767H31.943c-12.941,0-23.433,10.492-23.433,23.433v43.434c0,12.941,10.492,23.433,23.433,23.433h166.057c12.941,0,23.433-10.492,23.433-23.433V397.2C221.432,384.258,210.941,373.767,197.999,373.767z" />
      <path style={{ fill: fill2 }} d="M314.001,373.767h166.057c12.941,0,23.433,10.492,23.433,23.433v43.434c0,12.941-10.492,23.433-23.433,23.433H314.001c-12.941,0-23.433-10.492-23.433-23.433V397.2C290.568,384.258,301.058,373.767,314.001,373.767z" />
    </g>
  </svg>
);

export const ExportIcon = ({ stroke1 = '#4acb3a', stroke2 = '#054217' }: { stroke1?: string; stroke2?: string }) => (
  <svg fill="none" height="100%" width="100%" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
    {/* Arrow Top Right */}
    <polyline
      points="17 3 21 3 21 7"
      style={{
        stroke: stroke1,
        strokeWidth: 2,
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
        fill: 'none',
      }}
    />
    {/* Diagonal Line */}
    <line
      x1="11"
      y1="13"
      x2="21"
      y2="3"
      style={{
        stroke: stroke1,
        strokeWidth: 2,
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
        fill: 'none',
      }}
    />
    {/* Box Outline */}
    <path
      d="M19,13.89V20a1,1,0,0,1-1,1H4a1,1,0,0,1-1-1V6A1,1,0,0,1,4,5h6.11"
      style={{
        stroke: stroke2,
        strokeWidth: 2,
        strokeLinecap: 'round',
        strokeLinejoin: 'round',
        fill: 'none',
      }}
    />
  </svg>
);
export const AllIcon = ({ fill = '#24afeb' }) => (
  <svg
    width='100%'
    height='100%'
    viewBox="0 0 24 24"
    fill={fill}
    stroke={fill}
    xmlns="http://www.w3.org/2000/svg"
  >
    <g id="SVGRepo_iconCarrier">
      <path d="M20,24H4c-2.2,0-4-1.8-4-4V5c0-0.6,0.4-1,1-1h22c0.6,0,1,0.4,1,1v15C24,22.2,22.2,24,20,24z M2,6v14c0,1.1,0.9,2,2,2h16 c1.1,0,2-0.9,2-2V6H2z"></path>
      <path d="M23,5H1V4c0-1.7,1.3-3,3-3h16c1.7,0,3,1.3,3,3V5z"></path>
      <path d="M23,6H1C0.4,6,0,5.6,0,5V4c0-2.2,1.8-4,4-4h16c2.2,0,4,1.8,4,4v1C24,5.6,23.6,6,23,6z M2,4h20c0-1.1-0.9-2-2-2H4 C2.9,2,2,2.9,2,4z"></path>
      <path d="M7,24c-0.6,0-1-0.4-1-1V5c0-0.6,0.4-1,1-1s1,0.4,1,1v18C8,23.6,7.6,24,7,24z"></path>
      <path d="M23,12H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h22c0.6,0,1,0.4,1,1S23.6,12,23,12z"></path>
      <path d="M23,18H1c-0.6,0-1-0.4-1-1s0.4-1,1-1h22c0.6,0,1,0.4,1,1S23.6,18,23,18z"></path>
    </g>
  </svg>
);

export const CheckedIcon = ({ fill = "#19d294" }: { fill?: string;}) => (
  <svg
    width='100%'
    height='100%'
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <rect width="24" height="24" fill="white" />
    <path
      fillRule="evenodd"
      clipRule="evenodd"
      d="M2 12C2 6.47715 6.47715 2 12 2C17.5228 2 22 6.47715 22 12C22 17.5228 17.5228 22 12 22C6.47715 22 2 17.5228 2 12ZM15.7071 9.29289C16.0976 9.68342 16.0976 10.3166 15.7071 10.7071L12.0243 14.3899C11.4586 14.9556 10.5414 14.9556 9.97568 14.3899L8.29289 12.7071C7.90237 12.3166 7.90237 11.6834 8.29289 11.2929C8.68342 10.9024 9.31658 10.9024 9.70711 11.2929L11 12.5858L14.2929 9.29289C14.6834 8.90237 15.3166 8.90237 15.7071 9.29289Z"
      fill={fill}
    />
  </svg>
);
export const UncheckedIcon = ({
  stroke = "#14f068",
  size = 24,
  strokeWidth = 2,
}) => (
  <svg
    width={size}
    height={size}
    viewBox="0 0 24 24"
    fill="none"
    xmlns="http://www.w3.org/2000/svg"
  >
    <path
      d="M12 4C7.58172 4 4 7.58172 4 12C4 16.4183 7.58172 20 12 20C16.4183 20 20 16.4183 20 12C20 7.58172 16.4183 4 12 4Z"
      stroke={stroke}
      strokeWidth={strokeWidth}
      strokeLinecap="round"
      strokeLinejoin="round"
    />
  </svg>
);

export const PointerIcon = ({ fill = "#e2c718" }: { fill?: string;}) => (
  <svg fill={fill} width='100%' height='100%' viewBox="0 0 56 56" xmlns="http://www.w3.org/2000/svg" stroke="#e2c718"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"><path d="M 3.3437 30.8945 C 3.3437 40.8086 9.9999 47.4414 20.9687 47.4414 L 26.0780 47.4414 C 31.4921 47.4414 34.6327 44.8867 34.7030 40.5274 C 36.4140 39.9883 37.4687 38.5820 37.4687 36.6133 C 37.4687 35.9570 37.3280 35.2774 37.1171 34.5742 C 38.9921 33.9648 40.1640 32.4180 40.1640 30.3789 C 40.1640 29.8398 40.0936 29.2774 39.9062 28.7148 L 47.7109 28.7148 C 50.6874 28.7148 52.6563 26.7461 52.6563 23.9805 C 52.6563 21.1914 50.6874 19.2227 47.7109 19.2227 L 28.1640 19.2227 C 28.0468 19.2227 27.9530 19.1523 27.9530 19.0352 C 27.9530 18.9414 28.0233 18.8711 28.1171 18.8476 L 31.8671 17.2774 C 34.3046 16.2461 35.2421 14.1367 34.4218 11.9336 C 33.5077 9.4727 31.1171 8.5586 28.1874 9.5898 L 16.5858 13.7148 C 7.7968 16.8320 3.3437 22.6211 3.3437 30.8945 Z M 6.5780 31.0117 C 6.5780 24.4492 9.6014 19.4336 17.5936 16.5742 L 29.1718 12.4258 C 30.3905 11.9805 31.2812 12.3086 31.6562 13.2461 C 31.9843 14.1367 31.4687 14.9570 30.4609 15.4023 L 23.3358 18.5898 C 22.1640 19.1055 21.7890 19.8320 21.7890 20.6523 C 21.7890 21.6367 22.5624 22.3398 23.6405 22.3398 L 47.9216 22.3398 C 48.9296 22.3398 49.6328 23.0196 49.6328 23.9805 C 49.6328 24.9414 48.9296 25.5976 47.9216 25.5976 L 30.5780 25.5976 C 29.7577 25.5976 29.1483 26.3008 29.1483 27.1211 C 29.1483 27.9180 29.7577 28.5742 30.5780 28.5742 L 36.8124 28.5742 C 37.0233 28.9727 37.1405 29.5117 37.1405 29.9805 C 37.1405 31.1523 36.3671 31.8555 35.1483 31.8555 L 29.6874 31.8555 C 28.8202 31.8555 28.2577 32.5586 28.2577 33.3555 C 28.2577 34.1289 28.8202 34.8320 29.6874 34.8320 L 34.1171 34.8320 C 34.3280 35.2305 34.4452 35.7696 34.4452 36.2148 C 34.4452 37.4101 33.6718 38.0898 32.4530 38.0898 L 28.7968 38.0898 C 27.9296 38.0898 27.3436 38.8164 27.3436 39.6133 C 27.3436 40.3867 27.9296 41.0664 28.7968 41.0664 L 31.4921 41.0664 C 31.4921 43.1523 29.3358 44.3477 25.6093 44.3477 L 21.3436 44.3477 C 11.9218 44.3477 6.5780 39.2852 6.5780 31.0117 Z"></path></g></svg>
)

export const CloseIcon = ({ fill = "#ce3645" }: { fill?: string;}) => (
  <svg width='100%' height='100%' viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill-rule="evenodd" clip-rule="evenodd" d="M12 22C7.28595 22 4.92893 22 3.46447 20.5355C2 19.0711 2 16.714 2 12C2 7.28595 2 4.92893 3.46447 3.46447C4.92893 2 7.28595 2 12 2C16.714 2 19.0711 2 20.5355 3.46447C22 4.92893 22 7.28595 22 12C22 16.714 22 19.0711 20.5355 20.5355C19.0711 22 16.714 22 12 22ZM8.96965 8.96967C9.26254 8.67678 9.73742 8.67678 10.0303 8.96967L12 10.9394L13.9696 8.96969C14.2625 8.6768 14.7374 8.6768 15.0303 8.96969C15.3232 9.26258 15.3232 9.73746 15.0303 10.0303L13.0606 12L15.0303 13.9697C15.3232 14.2625 15.3232 14.7374 15.0303 15.0303C14.7374 15.3232 14.2625 15.3232 13.9696 15.0303L12 13.0607L10.0303 15.0303C9.73744 15.3232 9.26256 15.3232 8.96967 15.0303C8.67678 14.7374 8.67678 14.2626 8.96967 13.9697L10.9393 12L8.96965 10.0303C8.67676 9.73744 8.67676 9.26256 8.96965 8.96967Z" fill={fill}></path> </g></svg>
)

export const EditIcon = ({fill = "#6aa09c"}: {fill?: string;}) => (
  <svg viewBox="0 0 24 24" width='100%' height='100%' fill="none" xmlns="http://www.w3.org/2000/svg"><g id="SVGRepo_bgCarrier" stroke-width="0"></g><g id="SVGRepo_tracerCarrier" stroke-linecap="round" stroke-linejoin="round"></g><g id="SVGRepo_iconCarrier"> <path fill-rule="evenodd" clip-rule="evenodd" d="M7 4C5.34315 4 4 5.34315 4 7V17C4 18.6569 5.34315 20 7 20H17C18.6569 20 20 18.6569 20 17V11C20 10.4477 20.4477 10 21 10C21.5523 10 22 10.4477 22 11V17C22 19.7614 19.7614 22 17 22H7C4.23858 22 2 19.7614 2 17V7C2 4.23858 4.23858 2 7 2H13C13.5523 2 14 2.44772 14 3C14 3.55228 13.5523 4 13 4H7Z" fill="#6aa09c"></path> <path fill-rule="evenodd" clip-rule="evenodd" d="M17.2156 2.82088C17.7412 2.29528 18.4541 2 19.1974 2C19.9407 2 20.6535 2.29528 21.1791 2.82088C21.7047 3.34648 22 4.05934 22 4.80265C22 5.54596 21.7047 6.25883 21.1791 6.78443L20.396 7.56757C20.0055 7.9581 19.3723 7.9581 18.9818 7.56757L16.4324 5.01824C16.0419 4.62771 16.0419 3.99455 16.4324 3.60402L17.2156 2.82088ZM15.0182 6.43245C14.6277 6.04192 13.9945 6.04192 13.604 6.43245L9.14269 10.8938C9.01453 11.0219 8.92362 11.1825 8.87966 11.3583L8.02988 14.7575C7.94468 15.0982 8.04453 15.4587 8.29291 15.7071C8.54129 15.9555 8.90178 16.0553 9.24256 15.9701L12.6417 15.1204C12.8175 15.0764 12.9781 14.9855 13.1062 14.8573L17.5676 10.396C17.9581 10.0055 17.9581 9.37231 17.5676 8.98179L15.0182 6.43245Z" fill={fill}></path> </g></svg>
)