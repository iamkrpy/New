import React from "react";
import WarnAlert from "../../MainApp/MainAppAssets/WarnAlert.gif";
import ErrorAlert from "../../MainApp/MainAppAssets/ErrorAlert.gif";
import SuccessAlert from "../../MainApp/MainAppAssets/SuccessAlert.gif";
import FailedAlert from "../../MainApp/MainAppAssets/FailedAlert.gif";

interface AlertProps {
  Head: string;
  Type: string;
  Message: React.ReactNode;
  BtnPos?: string;
  BtnNeg?: string;
  Ret?: (value: string) => string;
}

const AlertDialogue: React.FC<AlertProps> = ({
  Head,
  Type,
  Message,
  BtnPos,
  BtnNeg,
  Ret,
}) => {
  const handlePosClick = () => {
    Ret?.(BtnPos ?? "Ok");
  };

  const handleNegClick = () => {
    Ret?.(BtnNeg ?? "Cancel");
  };

  return (
      <div className="fixed inset-0 z-150 flex items-center justify-center bg-black/50">
        <div className="bg-yellow-200 rounded-4xl shadow-lg p-6 w-3xl h-max">
            <img src={Type === "Warning" ? WarnAlert : Type === "Error" ? ErrorAlert : Type === "Success" ? SuccessAlert : Type === "Failed" ? FailedAlert : ""} alt="Warning" className="h-20 w-20 justify-self-center" />
            <div className="flex items-center justify-center">                
                <h2 className="text-3xl font-bold mb-2">{Head}</h2>
            </div>
          <div className="text-xl text-center p-1 border-2 border-amber-300 font-bold rounded-4xl mb-10 mt-6 justify-center bg-white">{Message}</div>
          <div className="flex justify-end space-x-4">            
            {BtnPos && BtnPos !== "" && (
              <button
                onClick={handlePosClick}
                className="px-4 py-2 bg-blue-400 text-white rounded hover:bg-blue-700 cursor-pointer"
              >
                {BtnPos}
              </button>
            )}
            {BtnNeg && BtnNeg !== "" && (
              <button
                onClick={handleNegClick}
                className="px-4 py-2 text-white bg-red-500 rounded hover:bg-red-800 cursor-pointer"
              >
                {BtnNeg}
              </button>
            )}
          </div>
        </div>
      </div>
  );
};

export default AlertDialogue;
