import axios from "axios";
import { logoutApi } from "./authAPI";
import { useNavigate } from "react-router-dom";

const navigate = useNavigate();

const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
  withCredentials: true,
  timeout: 10000,
});

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      console.warn("Unauthorized - redirect to login");
      try {
        logoutApi();
      } finally {
        navigate("/login", { replace: true });
      }
    }
    return Promise.reject(error);
  }
);

export default axiosInstance;
