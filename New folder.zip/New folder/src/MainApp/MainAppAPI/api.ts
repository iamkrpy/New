import axios, { type AxiosRequestConfig, type AxiosResponse } from "axios";

export interface ApiResponse<T = any> {
  IsSuccess: boolean;
  Message: string;
  StatusCode: number;
  Data: T | null;
}

const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL || "/api",
  withCredentials: true,
  timeout: 10000,
});

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      console.warn("Unauthorized - redirect to login");
    }
    return Promise.reject(error);
  }
);

export async function postApi<T = any>(
  url: string,
  payload: object = {},
  config?: AxiosRequestConfig
): Promise<ApiResponse<T>> {
  try {
    const res: AxiosResponse = await axiosInstance.post(url, payload, config);

    return {
      StatusCode: res.status,
      IsSuccess: res.data?.IsSuccess ?? true,
      Message: res.data?.Message ?? "Success",
      Data: res.data?.Data ?? res.data,
    };
  } catch (err: any) {
    return {
      StatusCode: err.response?.status ?? 500,
      IsSuccess: false,
      Message: err.response?.data?.Message || err.message || "Unknown error",
      Data: null,
    };
  }
}

export async function getApi<T = any>(
  url: string,
  config?: AxiosRequestConfig
): Promise<ApiResponse<T>> {
  try {
    const res: AxiosResponse = await axiosInstance.get(url, config);

    return {
      StatusCode: res.status,
      IsSuccess: res.data?.IsSuccess ?? true,
      Message: res.data?.Message ?? "Success",
      Data: res.data?.Data ?? res.data,
    };
  } catch (err: any) {
    return {
      StatusCode: err.response?.status ?? 500,
      IsSuccess: false,
      Message: err.response?.data?.Message || err.message || "Unknown error",
      Data: null,
    };
  }
}

export default axiosInstance;
