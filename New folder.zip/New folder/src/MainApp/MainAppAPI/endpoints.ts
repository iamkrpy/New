const API_ENDPOINTS = {
    login: "/auth/login",
    logout: "/auth/logout",
    me: "/auth/me",
    refresh: "/auth/refresh-token",
  };
  
  export default API_ENDPOINTS;
  