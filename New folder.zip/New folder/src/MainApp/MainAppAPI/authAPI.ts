import { postApi, getApi, type ApiResponse } from "./api";
import API_ENDPOINTS from "./endpoints";

export const loginApi = (UserId: string, Password: string): Promise<ApiResponse> => {
  return postApi(API_ENDPOINTS.login, { UserId, Password });
};

export const logoutApi = (): Promise<ApiResponse> => {
  return postApi(API_ENDPOINTS.logout);
};

export const getCurrentUser = (): Promise<ApiResponse> => {
  return getApi(API_ENDPOINTS.me);
};
