import { type ReactNode, type CSSProperties, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface ModalProps {
  isOpen: boolean;
  title: string;
  onClose: () => void;
  children: ReactNode;
  footer?: ReactNode;
  width?: string | number;
  height?: string | number;
  icon?: ReactNode;
  gradientHeader?: boolean;
  gradientFooter?: boolean;
  disableBackdropClose?: boolean;
  closeButtonProps?: {
    disabled?: boolean;
    title?: string;
  };
}

export default function GenericModal({
  isOpen,
  title,
  onClose,
  children,
  footer,
  width = "40vw",
  height = "60vh",
  icon,
  gradientHeader = true,
  gradientFooter = true,
  disableBackdropClose = false,
  closeButtonProps = {},
}: ModalProps) {
  const modalStyle: CSSProperties = {
    width: typeof width === "number" ? `${width}px` : width,
    height: typeof height === "number" ? `${height}px` : height,
    maxWidth: "95vw",   // Small devices
    maxHeight: "90vh",
    minWidth: "300px",  // Prevent it from being too narrow
    minHeight: "200px",
  };

  useEffect(() => {
    if (!isOpen) return;
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === "Escape" && !disableBackdropClose && !closeButtonProps.disabled) {
        onClose();
      }
    };
    window.addEventListener("keydown", handleKeyDown);
    return () => window.removeEventListener("keydown", handleKeyDown);
  }, [isOpen, disableBackdropClose, closeButtonProps.disabled, onClose]);

  return (
    <AnimatePresence>
      {isOpen && (
        <motion.div
          className="fixed inset-0 z-50 flex items-center justify-center bg-black/30 backdrop-blur-xl p-4 sm:p-6"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1, marginBottom: 0 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.25 }}
          role="dialog"
          aria-modal="true"
          aria-labelledby="modal-title"
          aria-describedby="modal-body"
        >
          <motion.div
            className="bg-white rounded-2xl shadow-2xl flex flex-col overflow-hidden border border-gray-200 w-full sm:w-auto sm:mx-4"
            style={modalStyle}
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
            transition={{ duration: 0.3 }}
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <motion.div
              className={`flex justify-between items-center p-5 ${gradientHeader
                ? "bg-gradient-to-r from-emerald-500 via-emerald-400 to-indigo-100 text-white shadow-md"
                : "bg-gray-100 text-gray-800 border-b border-gray-200"
                }`}
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.3 }}
            >
              <div className="flex items-center gap-3">
                {icon && (
                  <motion.div
                    className="text-xl"
                    whileHover={{ scale: 1.15 }}
                    transition={{ type: "spring", stiffness: 300 }}
                  >
                    {icon}
                  </motion.div>
                )}
                <h3 id="modal-title" className="text-xl font-semibold tracking-wide">
                  {title}
                </h3>
              </div>
              <button
                className={`font-extrabold text-xl transition transform ${closeButtonProps.disabled
                  ? "text-gray-400 cursor-not-allowed"
                  : "text-red-500 hover:text-black hover:scale-110 cursor-pointer"
                  }`}
                onClick={() => {
                  if (!closeButtonProps.disabled) onClose();
                }}
                aria-label="Close Modal"
                disabled={closeButtonProps.disabled}
                title={closeButtonProps.title || (closeButtonProps.disabled ? "Disabled" : "Close")}
              >
                &#x2715;
              </button>
            </motion.div>

            {/* Body */}
            <motion.div
              id="modal-body"
              className="p-6 flex-1 space-y-4 overflow-y-auto break-words whitespace-pre-wrap"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: 10 }}
              transition={{ duration: 0.25 }}
            >
              {children}
            </motion.div>

            {/* Footer */}
            {footer && (
              <motion.div
                className={`p-5 flex justify-end gap-3 ${gradientFooter
                  ? "bg-gradient-to-r from-gray-200 to-gray-100"
                  : "bg-gray-50 border-t border-gray-200"
                  }`}
                initial={{ y: 20, opacity: 0 }}
                animate={{ y: 0, opacity: 1 }}
                transition={{ duration: 0.3 }}
              >
                {footer}
              </motion.div>
            )}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
