import React, { useMemo, useRef, useState, useCallback } from "react";
import * as XLSX from "xlsx";
import ExcelJS from "exceljs";
import { motion, AnimatePresence } from "framer-motion";
import {
  FiDownload,
  FiUpload,
  FiSearch,
  FiX,
  FiChevronLeft,
  FiChevronRight,
  FiTrash2,
  FiChevronDown,
  FiChevronUp,
} from "react-icons/fi";
import ConfirmationModal from "./ConfirmationModal";

export type ColumnDefinition = {
  excelColumn: string;
  dbColumn: string;
  required?: boolean;
  type?: "string" | "number" | "date" | "boolean";
  maxLength?: number;
  enum?: string[];
  unique?: boolean;
  uniqueWith?: string[];
};

export type BulkUploadResult = {
  rowIndex: number;
  status: "success" | "error";
  remarks?: string;
  data: Record<string, any>;
};

type BulkUploadProps = {
  columns: ColumnDefinition[];
  headerText?: string;
  uploadButtonText?: string;
  isOpen?: boolean;
  onClose?: () => void;
  onDataReady?: (
    payload: Record<string, any>[],
    updateResults: (results: BulkUploadResult[]) => void
  ) => void;
};

export default function BulkUploadAdvanced({
  columns,
  headerText = "Bulk Upload",
  uploadButtonText = "Upload & Get Report",
  isOpen = true,
  onClose,
  onDataReady,
}: BulkUploadProps) {
  const [fileName, setFileName] = useState<string | null>(null);
  const [sheetRows, setSheetRows] = useState<Record<string, any>[]>([]);
  const [serverResults, setServerResults] = useState<BulkUploadResult[]>([]);
  const [uploading, setUploading] = useState(false);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [showValidation, setShowValidation] = useState(true);
  const [showPreview, setShowPreview] = useState(true);
  const [confirmOpen, setConfirmOpen] = useState(false);
  const [reportUrl, setReportUrl] = useState<string | null>(null);
  const [filterStatus, setFilterStatus] = useState<"all" | "success" | "error">("all");
  const [infoModal, setInfoModal] = useState<{
    open: boolean;
    type: "info" | "warning" | "error" | "success";
    message: string;
  }>({ open: false, type: "info", message: "" });

  const fileInputRef = useRef<HTMLInputElement | null>(null);
  const pageSize = 50;

  const normalizeHeaderKey = useCallback(
    (key: string) => key.replace(/\s*\(.*?\)\s*/g, "").trim(),
    []
  );

  const handleClearData = useCallback(() => {
    setSheetRows([]);
    setServerResults([]);
    setQuery("");
    setPage(1);
    setReportUrl(null);
    setFilterStatus("all");
  }, []);

  const handleClearFile = useCallback(() => {
    setFileName(null);
    handleClearData();
    if (fileInputRef.current) fileInputRef.current.value = "";
  }, [handleClearData]);

  const handleGenerateTemplate = useCallback(async () => {
    const wb = new ExcelJS.Workbook();
    const ws = wb.addWorksheet("Template");
    ws.addRow(columns.map((c) => c.excelColumn));
    ws.addRow(columns.map(() => ""));

    columns.forEach((col, idx) => {
      const column = ws.getColumn(idx + 1);
      const colLetter = column.letter;
      const headerCell = ws.getCell(`${colLetter}1`);
      headerCell.font = { bold: true, color: { argb: "FFFFFFFF" } };
      headerCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: "FF1E3A8A" } };
      headerCell.alignment = { vertical: "middle", horizontal: "center" };
      const inputCell = ws.getCell(`${colLetter}2`);
      inputCell.fill = { type: "pattern", pattern: "solid", fgColor: { argb: col.required ? "FFFFEBEB" : "FFE9F7EF" } };

      if (col.enum?.length) {
        inputCell.dataValidation = {
          type: "list",
          allowBlank: !col.required,
          formulae: [`"${col.enum.join(",")}"`],
        };
      }

      column.width = Math.max(12, Math.min(32, col.excelColumn.length + 6));
    });

    const infoSheet = wb.addWorksheet("README");
    infoSheet.addRow(["📄 INSTRUCTIONS"]);
    infoSheet.addRow(["Fill data starting at row 2. Do not edit header row."]);
    infoSheet.addRow(["Required columns are highlighted in red."]);
    infoSheet.addRow(["Enum columns have dropdowns with allowed values."]);
    infoSheet.addRow(["Save & upload this file after filling data."]);

    const buf = await wb.xlsx.writeBuffer();
    const blob = new Blob([buf], { type: "application/octet-stream" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "bulk_upload_template.xlsx";
    a.click();
    URL.revokeObjectURL(url);
  }, [columns]);

  const handleFileChange = useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (!file) return;
      setFileName(file.name);

      const reader = new FileReader();
      reader.onload = (evt) => {
        const data = evt.target?.result;
        if (!data) return;

        const wb = XLSX.read(data, { type: "array" });
        const sheet = wb.Sheets[wb.SheetNames[0]];
        const raw = XLSX.utils.sheet_to_json<Record<string, any>>(sheet, { defval: null, raw: false });

        const cleaned = raw.map((row) => {
          const out: Record<string, any> = {};
          Object.entries(row).forEach(([k, v]) => (out[normalizeHeaderKey(k)] = typeof v === "string" ? v.trim() : v));
          return out;
        });

        const filtered = cleaned.filter((r) => Object.values(r).some((v) => v !== null && v !== ""));
        setSheetRows(filtered);
        setServerResults([]);
        setPage(1);
        setReportUrl(null);
        setFilterStatus("all");
      };
      reader.readAsArrayBuffer(file);
    },
    [normalizeHeaderKey]
  );
  const validationResults = useMemo(() => {
    if (!sheetRows.length) return [];

    const results: BulkUploadResult[] = [];
    const uniqueTrackers = new Map<string, Map<any, number[]>>();
    const uniqueWithTrackers = new Map<string, Map<string, number[]>>();

    columns.forEach((col) => {
      const colKey = normalizeHeaderKey(col.excelColumn);
      if (col.unique) uniqueTrackers.set(colKey, new Map());
      if (col.uniqueWith?.length) uniqueWithTrackers.set(colKey, new Map());
    });

    sheetRows.forEach((row, idx) => {
      const excelRow = idx + 2;
      const errors: string[] = [];

      columns.forEach((col) => {
        const colKey = normalizeHeaderKey(col.excelColumn);
        const val = row[colKey];

        if (col.required && (!val || String(val).trim() === "")) errors.push(`${col.excelColumn} is required`);
        if (val && col.type === "number" && isNaN(Number(val))) errors.push(`${col.excelColumn} must be a number`);
        if (val && col.type === "date" && isNaN(Date.parse(String(val)))) errors.push(`${col.excelColumn} must be a valid date`);
        if (val && col.enum && !col.enum.includes(String(val))) errors.push(`${col.excelColumn} must be one of: ${col.enum.join(", ")}`);

        if (col.unique) {
          const tracker = uniqueTrackers.get(colKey)!;
          const key = val ?? "__NULL__";
          tracker.set(key, [...(tracker.get(key) || []), excelRow]);
        }

        if (col.uniqueWith?.length) {
          const tracker = uniqueWithTrackers.get(colKey)!;
          const compositeKey = [val, ...col.uniqueWith.map(c => row[normalizeHeaderKey(c)] ?? "__NULL__")].join("||");
          tracker.set(compositeKey, [...(tracker.get(compositeKey) || []), excelRow]);
        }
      });

      results.push({
        rowIndex: excelRow,
        status: errors.length ? "error" : "success",
        remarks: errors.length ? errors.join("\n") : undefined,
        data: row,
      });
    });

    uniqueTrackers.forEach((map, colKey) => {
      map.forEach((rows) => {
        if (rows.length > 1) {
          rows.forEach((rn) => {
            const idx = results.findIndex((r) => r.rowIndex === rn);
            if (idx >= 0) {
              results[idx].status = "error";
              results[idx].remarks = [results[idx].remarks, `${colKey} must be unique`].filter(Boolean).join("\n");
            }
          });
        }
      });
    });

    uniqueWithTrackers.forEach((map, colKey) => {
      map.forEach((rows) => {
        if (rows.length > 1) {
          rows.forEach((rn) => {
            const idx = results.findIndex((r) => r.rowIndex === rn);
            if (idx >= 0) {
              const otherCols = columns.find(c => normalizeHeaderKey(c.excelColumn) === colKey)?.uniqueWith?.join(", ") || "";
              results[idx].status = "error";
              results[idx].remarks = [results[idx].remarks, `Combination of ${colKey} with [${otherCols}] must be unique`].filter(Boolean).join("\n");
            }
          });
        }
      });
    });

    return results;
  }, [sheetRows, columns, normalizeHeaderKey]);

  const totalRows = sheetRows.length;
  const errorCount = validationResults.filter((r) => r.status === "error").length;
  const successCount = validationResults.filter((r) => r.status === "success").length;

  const filteredRows = useMemo(() => {
    let rows = sheetRows;
    if (filterStatus !== "all") {
      rows = validationResults.filter((r) => r.status === filterStatus).map((r) => r.data);
    }
    if (query.trim()) {
      const q = query.toLowerCase();
      rows = rows.filter((r) => columns.some((c) => String(r[c.excelColumn] ?? "").toLowerCase().includes(q)));
    }
    return rows;
  }, [sheetRows, validationResults, query, columns, filterStatus]);

  const pageCount = Math.max(1, Math.ceil(filteredRows.length / pageSize));
  const pageSafe = Math.min(page, pageCount);
  const pageRows = filteredRows.slice((pageSafe - 1) * pageSize, pageSafe * pageSize);

  const mappedPayload = useMemo(() => {
    return sheetRows.map((r) => {
      const mapped: Record<string, any> = {};
      columns.forEach((c) => (mapped[c.dbColumn] = r[c.excelColumn] ?? null));
      return mapped;
    });
  }, [sheetRows, columns]);

  const handleUploadConfirm = () => {
    if (!sheetRows.length) return;
    if (validationResults.some((r) => r.status === "error")) {

      // alert("Please fix validation errors first.");
      setInfoModal({ open: true, type: "error", message: "Please fix validation errors first." });
      return;
    }
    setConfirmOpen(true);
  };

  const handleDownloadReport = () => {
    if (!reportUrl) return;
    const a = document.createElement("a");
    a.href = reportUrl;
    a.download = "Upload_result.xlsx";
    a.click();
  };
  if (!isOpen) return null;

  return (
    <>
      <AnimatePresence>
        <motion.div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-2 sm:p-4"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
          <motion.div className="bg-white rounded-2xl shadow-2xl w-full max-w-7xl max-h-[95vh] flex flex-col overflow-hidden border border-gray-200"
            initial={{ scale: 0.95, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.95, opacity: 0, y: 20 }}
            transition={{ type: "spring", stiffness: 120, damping: 15 }}>

            {/* Header */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between p-4 border-b bg-gradient-to-r from-indigo-50 to-white gap-3 sm:gap-0">
              <div>
                <h2 className="text-lg font-semibold">{headerText}</h2>
                <p className="text-sm text-gray-500">Upload Excel → Validate → Paginate → Download Results</p>
              </div>
              <div className="flex flex-wrap gap-2">
                <button onClick={handleGenerateTemplate} className="flex items-center gap-2 px-3 py-2 bg-white border rounded hover:shadow-md">
                  <FiDownload /> Template
                </button>
                <label className="flex items-center gap-2 px-3 py-2 bg-emerald-600 text-white rounded cursor-pointer hover:opacity-95">
                  <FiUpload />
                  <input ref={fileInputRef} type="file" accept=".xlsx,.xls" onChange={handleFileChange} className="hidden" />
                  {fileName ?? "Choose File"}
                </label>
                {fileName && (
                  <button onClick={handleClearFile} className="flex items-center gap-2 px-3 py-2 bg-red-100 text-red-700 rounded hover:bg-red-200">
                    <FiTrash2 /> Clear File
                  </button>
                )}
                {sheetRows.length > 0 && (
                  <button onClick={handleClearData} className="flex items-center gap-2 px-3 py-2 bg-yellow-100 text-yellow-700 rounded hover:bg-yellow-200">
                    <FiTrash2 /> Clear Data
                  </button>
                )}
                {onClose && (
                  <button onClick={onClose} className="p-2 hover:bg-gray-100 rounded">
                    <FiX />
                  </button>
                )}
              </div>
            </div>

            {/* Counts & Search */}
            <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-2 p-3 border-b">
              <div className="flex items-center gap-3 text-sm">
                <span>
                  Rows: <b>{totalRows}</b>
                </span>
                <span className="flex items-center gap-1 cursor-pointer" onClick={() => setFilterStatus("error")}>
                  Errors:
                  <span className={`inline-flex items-center justify-center rounded-full w-6 h-6 text-xs font-bold ${filterStatus === "error" ? "bg-red-700 text-white" : "bg-red-600 text-white"}`}>
                    {errorCount}
                  </span>
                </span>
                <span className="flex items-center gap-1 cursor-pointer" onClick={() => setFilterStatus("success")}>
                  Success:
                  <span className={`inline-flex items-center justify-center rounded-full w-6 h-6 text-xs font-bold ${filterStatus === "success" ? "bg-green-700 text-white" : "bg-green-600 text-white"}`}>
                    {successCount}
                  </span>
                </span>
                <span className="flex items-center gap-1 cursor-pointer" onClick={() => setFilterStatus("all")}>
                  All
                </span>
              </div>

              <div className="flex items-center gap-2">
                <div className="relative">
                  <FiSearch className="absolute left-2 top-2 text-gray-400" />
                  <input
                    className="pl-8 pr-3 py-2 border rounded-md w-64"
                    placeholder="Search..."
                    value={query}
                    onChange={e => { setQuery(e.target.value); setPage(1); }}
                  />
                </div>
                <div className="flex items-center gap-1">
                  <button onClick={() => setPage(p => Math.max(1, p - 1))} className="p-2 border rounded"><FiChevronLeft /></button>
                  <span className="text-sm">Page {pageSafe}/{pageCount}</span>
                  <button onClick={() => setPage(p => Math.min(pageCount, p + 1))} className="p-2 border rounded"><FiChevronRight /></button>
                </div>
              </div>
            </div>

            {/* Main Content */}
            <div className="flex flex-col sm:flex-row gap-3 p-3 flex-1 overflow-hidden">

              {/* Preview Table */}
              <div className="border rounded-lg bg-white shadow flex flex-col h-64 sm:flex-1">
                <div className="flex justify-between items-center p-2 cursor-pointer bg-gray-50 sm:hidden" onClick={() => setShowPreview(prev => !prev)}>
                  <div className="font-medium">Preview</div>
                  {showPreview ? <FiChevronUp /> : <FiChevronDown />}
                </div>
                {(showPreview || window.innerWidth >= 640) && (
                  <div className="flex-1 overflow-auto">
                    <table className="min-w-full text-sm">
                      <thead className="bg-gray-50 sticky top-0">
                        <tr>
                          <th className="border px-2 py-1">Excel Row</th>
                          {columns.map(c => <th key={c.excelColumn} className="border px-2 py-1">{c.excelColumn}</th>)}
                        </tr>
                      </thead>
                      <tbody>
                        {pageRows.length === 0 ? (
                          <tr><td colSpan={columns.length + 1} className="text-center text-gray-400 py-4">No rows found</td></tr>
                        ) : pageRows.map((row, i) => {
                          const excelRowIndex = sheetRows.indexOf(row) + 2;
                          const v = validationResults.find(v => v.rowIndex === excelRowIndex);
                          return (
                            <tr key={i} className={v?.status === "error" ? "bg-red-50" : ""}>
                              <td className="border px-2 py-1">{excelRowIndex}</td>
                              {columns.map(c => <td key={c.excelColumn} className="border px-2 py-1">{String(row[c.excelColumn] ?? "")}</td>)}
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>

              {/* Validation Panel */}
              <div className="flex flex-col gap-2 w-full sm:w-96 h-full overflow-hidden">

                <div className="border rounded-lg bg-white shadow flex flex-col h-64">
                  <div className="flex justify-between items-center p-2 cursor-pointer bg-gray-50" onClick={() => setShowValidation(prev => !prev)}>
                    <div className="font-medium">Input Validation</div>
                    {showValidation ? <FiChevronUp /> : <FiChevronDown />}
                  </div>
                  {showValidation && (
                    <div className="flex-1 overflow-auto p-2">
                      {validationResults.length === 0 && <div className="text-gray-400 text-sm">No validation results</div>}
                      {validationResults.map(v => (
                        <div key={v.rowIndex} className={`p-2 mb-1 rounded ${v.status === "error" ? "bg-red-50 text-red-700" : "bg-green-50 text-green-700"}`}>
                          <b>Row {v.rowIndex}:</b> {v.status}
                          {v.remarks && <div className="text-xs">{v.remarks}</div>}
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                {/* Server Results Panel */}
                {serverResults.length > 0 && (
                  <div className="border rounded-lg bg-white shadow flex flex-col h-64 sm:h-auto sm:max-h-[30vh]">
                    <div className="flex justify-between items-center p-2 cursor-pointer bg-gray-50" onClick={() => setShowValidation(prev => !prev)}>
                      <div className="font-medium">Upload Report</div>
                      {showValidation ? <FiChevronUp /> : <FiChevronDown />}
                    </div>
                    <div className="flex-1 overflow-auto p-2">
                      {serverResults.map(r => (
                        <div key={r.rowIndex} className={`p-2 mb-1 rounded ${r.status === "error" ? "bg-red-50 text-red-700" : "bg-green-50 text-green-700"}`}>
                          {r.status}
                          {r.remarks && <div className="text-xs">{r.remarks}</div>}
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>

            {/* Footer Buttons */}
            <div className="border-t p-3 flex flex-wrap justify-end gap-2">
              {reportUrl && (
                <button onClick={handleDownloadReport} className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700">
                  Download Report
                </button>
              )}
              <button onClick={onClose} className="px-4 py-2 bg-gray-200 rounded hover:bg-gray-300">Close</button>
              <button
                onClick={handleUploadConfirm}
                disabled={uploading || !sheetRows.length}
                className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700 disabled:opacity-50"
              >
                {uploading ? "Uploading..." : uploadButtonText}
              </button>
            </div>
          </motion.div>
        </motion.div>
      </AnimatePresence>

      {/* Confirmation Modal */}
      <ConfirmationModal
        isOpen={confirmOpen}
        type="confirmation"
        title="Confirm Upload"
        message={`You are about to upload ${sheetRows.length} row(s). Continue?`}
        onClose={() => setConfirmOpen(false)}
        height="auto"
        onConfirm={() => {
          setConfirmOpen(false);
          if (!onDataReady) return;
          setUploading(true);
          onDataReady(mappedPayload, async (results) => {
            setServerResults(results);
            setUploading(false);

            // Generate report for manual download
            const workbook = new ExcelJS.Workbook();
            const worksheet = workbook.addWorksheet("Upload Report");
            const headers = [...columns.map((c) => c.excelColumn), "Status", "Remarks"];
            worksheet.addRow(headers);
            results.forEach((res) => {
              const originalRow = sheetRows[res.rowIndex - 2];
              const rowValues = [...columns.map((c) => originalRow?.[c.excelColumn] ?? ""), res.status, res.remarks || ""];
              const row = worksheet.addRow(rowValues);
              const statusCell = row.getCell(columns.length + 1);
              statusCell.fill = {
                type: "pattern",
                pattern: "solid",
                fgColor: { argb: res.status === "success" ? "FFDCFCE7" : res.status === "error" ? "FFFEE2E2" : "FFFFF7E6" },
              };
            });
            worksheet.columns.forEach((col) => {
              let maxLength = 10;
              col.eachCell?.({ includeEmpty: true }, (cell) => {
                maxLength = Math.max(maxLength, cell.value?.toString().length || 0);
              });
              col.width = maxLength + 2;
            });

            const buf = await workbook.xlsx.writeBuffer();
            const blob = new Blob([buf], { type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" });
            const url = URL.createObjectURL(blob);
            setReportUrl(url);
          });
        }}
      />
      <ConfirmationModal
        isOpen={infoModal.open}
        type={infoModal.type}
        title={
          infoModal.type === "error"
            ? "Error"
            : infoModal.type === "warning"
            ? "Warning"
            : "Information"
        }
        message={infoModal.message}
        onClose={() => setInfoModal({ ...infoModal, open: false })}
        positiveLabel="OK"
        height="auto"
      />
    </>
  );
}
