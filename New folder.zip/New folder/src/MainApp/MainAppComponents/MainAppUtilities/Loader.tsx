import { motion } from "framer-motion";

interface LoaderProps {
  size?: number;
  color?: string;       // Any valid CSS color: "blue", "#3b82f6", "rgb(59,130,246)"
  border?: number;      // Border thickness for spinner/dualRing
  text?: string;        // Optional text below loader
  fullscreen?: boolean; // Whether to cover the whole screen
  zIndex?: number;      // Layer control
  variant?: "spinner" | "dots" | "bar" | "pulse" | "dualRing";
}

export default function Loader({
  size = 40,
  color = "#3b82f6", // Tailwind blue-500 hex value
  border = 4,
  text = "Loading...",
  fullscreen = false,
  zIndex = 50,
  variant = "spinner",
}: LoaderProps) {
  const renderLoader = () => {
    switch (variant) {
      case "dots":
        return (
          <div className="flex gap-2">
            {[0, 1, 2].map((i) => (
              <motion.div
                key={i}
                style={{
                  width: size / 4,
                  height: size / 4,
                  backgroundColor: color,
                  borderRadius: "50%",
                }}
                animate={{ y: [0, -8, 0] }}
                transition={{ repeat: Infinity, duration: 0.6, delay: i * 0.2 }}
              />
            ))}
          </div>
        );

      case "bar":
        return (
          <motion.div
            style={{
              height: size / 5,
              width: size * 2,
              backgroundColor: color,
              borderRadius: 6,
            }}
            animate={{ scaleX: [0.2, 1, 0.2] }}
            transition={{ repeat: Infinity, duration: 1.2, ease: "easeInOut" }}
          />
        );

      case "pulse":
        return (
          <motion.div
            style={{
              width: size,
              height: size,
              borderRadius: "50%",
              backgroundColor: color,
            }}
            animate={{ scale: [1, 1.4, 1], opacity: [1, 0.5, 1] }}
            transition={{ repeat: Infinity, duration: 1.2 }}
          />
        );

      case "dualRing":
        return (
          <motion.div
            style={{
              width: size,
              height: size,
              borderWidth: border,
              borderStyle: "solid",
              borderRadius: "50%",
              borderColor: "#e5e7eb", // gray-200
              borderTopColor: color,
              borderLeftColor: color,
            }}
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
          />
        );

      case "spinner":
      default:
        return (
          <motion.div
            style={{
              width: size,
              height: size,
              borderWidth: border,
              borderStyle: "solid",
              borderRadius: "50%",
              borderColor: "#e5e7eb", // gray-200
              borderTopColor: color,
            }}
            animate={{ rotate: 360 }}
            transition={{ repeat: Infinity, duration: 1, ease: "linear" }}
          />
        );
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
      role="status"
      aria-busy="true"
      className={`flex flex-col items-center justify-center ${
        fullscreen ? `fixed inset-0 bg-black/60 backdrop-blur z-[${zIndex}]` : ""
      }`}
    >
      {renderLoader()}

      {text && (
        <motion.p
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.2 }}
          className="mt-4 text-black-200 text-sm font-medium tracking-wide animate-pulse"
        >
          {text}
        </motion.p>
      )}
    </motion.div>
  );
}
