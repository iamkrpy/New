// import { type ReactNode, useState } from "react";
// import { motion } from "framer-motion";
// import Modal from "./GenericModal";

// type ConfirmationType = "info" | "warning" | "error" | "confirmation";

// interface ConfirmationModalProps {
//   isOpen: boolean;
//   type: ConfirmationType;
//   title?: string;
//   message: string | ReactNode;
//   onClose: () => void;
//   onConfirm?: () => void | Promise<void>;
//   positiveLabel?: string;
//   negativeLabel?: string;
//   width?: string | number;
//   height?: string | number;
// }

// const ICONS: Record<ConfirmationType, ReactNode> = {
//   info: <span aria-hidden className="text-blue-600 text-4xl">ℹ️</span>,
//   warning: <span aria-hidden className="text-yellow-500 text-4xl">⚠️</span>,
//   error: <span aria-hidden className="text-red-600 text-4xl">❌</span>,
//   confirmation: <span aria-hidden className="text-gray-700 text-4xl">❓</span>,
// };

// const TYPE_COLORS: Record<ConfirmationType, string> = {
//   info: "from-blue-200 to-blue-50 text-blue-800",
//   warning: "from-yellow-200 to-yellow-50 text-yellow-800",
//   error: "from-red-200 to-red-50 text-red-800",
//   confirmation: "from-gray-200 to-gray-50 text-gray-800",
// };

// const DEFAULT_TITLES: Record<ConfirmationType, string> = {
//   info: "Information",
//   warning: "Warning",
//   error: "Error",
//   confirmation: "Please Confirm",
// };

// export default function ConfirmationModal({
//   isOpen,
//   type,
//   title,
//   message,
//   onClose,
//   onConfirm,
//   positiveLabel = "Yes",
//   negativeLabel = "Cancel",
//   width = "30vw",
//   height = "30vh",
// }: ConfirmationModalProps) {
//   const [loading, setLoading] = useState(false);

//   if (!isOpen) return null;

//   const handleConfirm = async () => {
//     if (!onConfirm) {
//       onClose();
//       return;
//     }

//     try {
//       setLoading(true);
//       await onConfirm();
//       onClose();
//     } catch {
//     } finally {
//       setLoading(false);
//     }
//   };

//   return (
//     <Modal
//       isOpen={isOpen}
//       onClose={loading ? () => {} : onClose}
//       title={title || DEFAULT_TITLES[type]}
//       width={width}
//       height={height}
//       disableBackdropClose={loading}
//       closeButtonProps={{
//         disabled: loading,
//         title: loading ? "Cannot close while processing" : "Close",
//       }}
//       footer={
//         type === "confirmation" ? (
//           <div className="flex justify-end gap-3">
//             {!loading && (
//               <button
//                 type="button"
//                 aria-label={negativeLabel}
//                 className="px-5 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 font-medium shadow transition-transform hover:cursor-pointer hover:scale-105"
//                 onClick={onClose}
//               >
//                 {negativeLabel}
//               </button>
//             )}

//             <button
//               type="button"
//               aria-label={positiveLabel}
//               className={`px-5 py-2 rounded-lg text-white font-medium shadow transition-transform hover:cursor-pointer hover:scale-105 ${
//                 loading
//                   ? "bg-green-400 cursor-not-allowed opacity-70"
//                   : "bg-green-600 hover:bg-green-700"
//               }`}
//               onClick={handleConfirm}
//               disabled={loading}
//               title={loading ? "Processing, please wait..." : positiveLabel}
//             >
//               {loading ? (
//                 <span className="flex items-center gap-2">
//                   <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
//                   Processing...
//                 </span>
//               ) : (
//                 positiveLabel
//               )}
//             </button>
//           </div>
//         ) : (
//           <button
//             type="button"
//             aria-label="OK"
//             className="px-5 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 font-medium shadow transition-transform hover:cursor-pointer hover:scale-105"
//             onClick={onClose}
//             disabled={loading}
//             title={loading ? "Cannot close while processing" : "Close"}
//           >
//             OK
//           </button>
//         )
//       }
//     >
//       <motion.div
//         initial={{ opacity: 0, scale: 0.85 }}
//         animate={{ opacity: 1, scale: 1 }}
//         exit={{ opacity: 0, scale: 0.85 }}
//         transition={{ duration: 0.25 }}
//         className={`flex flex-col items-center justify-center gap-4 p-6 rounded-2xl bg-gradient-to-br ${TYPE_COLORS[type]} shadow-lg text-center`}
//       >
//         <div>{ICONS[type]}</div>

//         <div className="font-bold sm:text-lg break-words whitespace-pre-wrap max-h-[40vh] overflow-y-auto w-full text-center px-2">{message}</div>
//       </motion.div>
//     </Modal>
//   );
// }

import { type ReactNode, useState } from "react";
import { motion } from "framer-motion";
import Modal from "./GenericModal";

type ConfirmationType = "info" | "warning" | "error" | "confirmation" | "success";

interface ConfirmationModalProps {
  isOpen: boolean;
  type: ConfirmationType;
  title?: string;
  message: string | ReactNode;
  onClose: () => void;
  onConfirm?: () => void | Promise<void>;
  positiveLabel?: string;
  negativeLabel?: string;
  width?: string | number;
  height?: string | number;
}

// Animated illustrations for each type
const ANIMATIONS: Record<ConfirmationType, ReactNode> = {
  info: (
    <motion.div
      className="w-16 h-16 rounded-full border-4 border-blue-600 flex items-center justify-center text-blue-600 font-bold text-xl"
      initial={{ scale: 0 }}
      animate={{ scale: [0, 1.2, 1] }}
      transition={{ duration: 0.8 }}
    >
      i
    </motion.div>
  ),
  warning: (
    <motion.div
      className="w-16 h-16 flex items-center justify-center"
      initial={{ rotate: 0 }}
      animate={{ rotate: [0, -10, 10, -10, 10, 0] }}
      transition={{ repeat: Infinity, duration: 0.6 }}
    >
      <svg viewBox="0 0 24 24" className="w-16 h-16 text-yellow-500">
        <polygon points="12,2 22,20 2,20" fill="none" stroke="currentColor" strokeWidth="2" />
        <line x1="12" y1="8" x2="12" y2="14" stroke="currentColor" strokeWidth="2" />
        <circle cx="12" cy="17" r="1" fill="currentColor" />
      </svg>
    </motion.div>
  ),
  error: (
    <motion.svg
      xmlns="http://www.w3.org/2000/svg"
      className="w-16 h-16 text-red-600"
      fill="none"
      viewBox="0 0 24 24"
    >
      <motion.line
        x1="6"
        y1="6"
        x2="18"
        y2="18"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.5 }}
      />
      <motion.line
        x1="6"
        y1="18"
        x2="18"
        y2="6"
        stroke="currentColor"
        strokeWidth="3"
        strokeLinecap="round"
        initial={{ pathLength: 0 }}
        animate={{ pathLength: 1 }}
        transition={{ duration: 0.5, delay: 0.5 }}
      />
    </motion.svg>
  ),
  confirmation: (
    <motion.div
      className="w-16 h-16 rounded-full border-4 border-gray-700 flex items-center justify-center text-gray-700 font-bold text-xl"
      initial={{ scale: 0 }}
      animate={{ scale: [0, 1.2, 1] }}
      transition={{ duration: 0.8 }}
    >
      ?
    </motion.div>
  ),
  success: (
    <motion.svg
      xmlns="http://www.w3.org/2000/svg"
      className="w-16 h-16 text-green-600"
      fill="none"
      viewBox="0 0 24 24"
      initial={{ rotate: -90 }}
      animate={{ rotate: 0 }}
      transition={{ duration: 0.6, ease: "easeOut" }}
    >
      <motion.circle
        cx="12"
        cy="12"
        r="10"
        stroke="currentColor"
        strokeWidth="2.5"
        fill="transparent"
        strokeDasharray="63"
        strokeDashoffset="63"
        animate={{ strokeDashoffset: 0 }}
        transition={{ duration: 0.6, ease: "easeOut" }}
      />
      <motion.path
        stroke="currentColor"
        strokeWidth="2.5"
        strokeLinecap="round"
        strokeLinejoin="round"
        d="M7 13l3 3 7-7"
        strokeDasharray="20"
        strokeDashoffset="20"
        animate={{ strokeDashoffset: 0 }}
        transition={{ duration: 0.5, ease: "easeOut", delay: 0.6 }}
      />
    </motion.svg>
  ),
};

const TYPE_COLORS: Record<ConfirmationType, string> = {
  info: "from-blue-200 to-blue-50 text-blue-800",
  warning: "from-yellow-200 to-yellow-50 text-yellow-800",
  error: "from-red-200 to-red-50 text-red-800",
  confirmation: "from-gray-200 to-gray-50 text-gray-800",
  success: "from-green-200 to-green-50 text-green-800",
};

const DEFAULT_TITLES: Record<ConfirmationType, string> = {
  info: "Information",
  warning: "Warning",
  error: "Error",
  confirmation: "Please Confirm",
  success: "Success",
};

export default function ConfirmationModal({
  isOpen,
  type,
  title,
  message,
  onClose,
  onConfirm,
  positiveLabel = "Yes",
  negativeLabel = "Cancel",
  width = "30vw",
  height = "30vh",
}: ConfirmationModalProps) {
  const [loading, setLoading] = useState(false);

  if (!isOpen) return null;

  const handleConfirm = async () => {
    if (!onConfirm) {
      onClose();
      return;
    }

    try {
      setLoading(true);
      await onConfirm();
      onClose();
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      onClose={loading ? () => {} : onClose}
      title={title || DEFAULT_TITLES[type]}
      width={width}
      height={height}
      disableBackdropClose={loading}
      closeButtonProps={{
        disabled: loading,
        title: loading ? "Cannot close while processing" : "Close",
      }}
      footer={
        type === "confirmation" ? (
          <div className="flex justify-end gap-3">
            {!loading && (
              <button
                type="button"
                aria-label={negativeLabel}
                className="px-5 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 font-medium shadow transition-transform hover:cursor-pointer hover:scale-105"
                onClick={onClose}
              >
                {negativeLabel}
              </button>
            )}
            <button
              type="button"
              aria-label={positiveLabel}
              className={`px-5 py-2 rounded-lg text-white font-medium shadow transition-transform hover:cursor-pointer hover:scale-105 ${
                loading
                  ? "bg-green-400 cursor-not-allowed opacity-70"
                  : "bg-green-600 hover:bg-green-700"
              }`}
              onClick={handleConfirm}
              disabled={loading}
              title={loading ? "Processing, please wait..." : positiveLabel}
            >
              {loading ? (
                <span className="flex items-center gap-2">
                  <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                  Processing...
                </span>
              ) : (
                positiveLabel
              )}
            </button>
          </div>
        ) : (
          <button
            type="button"
            aria-label="OK"
            className={`px-5 py-2 rounded-lg font-medium shadow transition-transform hover:cursor-pointer hover:scale-105 ${
              type === "success"
                ? "bg-green-600 text-white hover:bg-green-700"
                : "bg-blue-600 text-white hover:bg-blue-700"
            }`}
            onClick={onClose}
          >
            OK
          </button>
        )
      }
    >
      <motion.div
        initial={{ opacity: 0, scale: 0.85 }}
        animate={{ opacity: 1, scale: 1 }}
        exit={{ opacity: 0, scale: 0.85 }}
        transition={{ duration: 0.25 }}
        className={`flex flex-col items-center justify-center gap-4 p-6 rounded-2xl bg-gradient-to-br ${TYPE_COLORS[type]} shadow-lg text-center`}
      >
        <div>{ANIMATIONS[type]}</div>
        <div className="font-bold sm:text-lg break-words whitespace-pre-wrap max-h-[40vh] overflow-y-auto w-full text-center px-2">
          {message}
        </div>
      </motion.div>
    </Modal>
  );
}
