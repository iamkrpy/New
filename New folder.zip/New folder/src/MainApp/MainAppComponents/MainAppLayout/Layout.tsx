import { useEffect, useState } from "react";
import { Sidebar } from "./Sidebar";
import { Header } from "./Header";
import { useSidebarStore } from "../MainAppStore/sidebarStore";
import clsx from "clsx";
import { SidebarMobile } from "./SidebarMobile";
import { Outlet } from "react-router-dom";
import { usePageTitle } from "../../MainAppContexts/PageTitleContext";

interface PageItem {
  id: number;
  label: string;
  route: string;
}

interface RoleItem {
  id: number;
  label: string;
  pages: PageItem[];
}

interface MenuItem {
  id: number;
  label: string;
  icon: string;
  route: string;
  roles?: RoleItem[];
}

const mockFetchMenu = async (): Promise<MenuItem[]> =>
  new Promise((res) =>
    setTimeout(
      () =>
        res([
          {
            id: 1,
            label: "Smart Procurement",
            icon: "home",
            route: "/",
            roles: [
              {
                id: 101,
                label: "Initiator",
                pages: [
                  { id: 1001, label: "Live PRs", route: "/TGSApp/LivePRs" },
                  { id: 1002, label: "PR Categorization", route: "/TGSApp/CatSubCatBuyer" },
                  { id: 1003, label: "Purchase Group Mapping", route: "/TGSApp/PurchaseGrpHead" },
                ],
              },
              {
                id: 102,
                label: "Procurement Manager",
                pages: [
                  { id: 1004, label: "RFQ Creation", route: "/TGSApp/LivePRsBuyer" },
                  { id: 1005, label: "View RFQ Requests", route: "/TGSApp/RFQRequests" },
                ],
              }
              // {
              //   id: 102,
              //   label: "Approver",
              //   pages: [
              //     { id: 1003, label: "Pending Approvals", route: "/approvals" },
              //     { id: 1004, label: "Approved List", route: "/approved" },
              //   ],
              // },
            ],
          },
        ]),
      500
    )
  );

const Layout = () => {
  const { isOpen: isSidebarOpen } = useSidebarStore(); // ✅ Zustand store access
  const [menuItems, setMenuItems] = useState<MenuItem[]>([]);
  const { title } = usePageTitle();

  useEffect(() => {
    const loadMenu = async () => {
      const data = await mockFetchMenu();
      setMenuItems(data);
    };
    loadMenu();
  }, []);

  return (
    <div className="flex">
      {/* Sidebar */}
      <Sidebar menuItems={menuItems} />
      <SidebarMobile menuItems={menuItems} />
      {/* Main content area */}
      
      <div
  className={clsx(
    "transition-all duration-300 w-full",
    isSidebarOpen ? "lg:pl-80" : "pl-0 lg:pl-20"
  )}
>
  <Header />
  <main className="p-3 mt-2 shadow-md rounded-2xl">
  <h1 className="w-full max-w-md mb-1 p-2 text-center text-white lg:text-xl font-bold 
  rounded-2xl border-6 border-white bg-emerald-400 
  shadow-[inset_0_0_25px_rgba(0,0,0,0.8)]">
  {title || "Dashboard"}
</h1>

    <div className="bg-white p-4 rounded-2xl h-[83vh] overflow-y-scroll">
      <Outlet />
    </div>
  </main>
</div>
    </div>
  );
};

export default Layout;
