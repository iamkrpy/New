import React, { useState, useRef, useEffect } from "react";
import { iconMap, HamburgerIcon } from "../../MainAppUtilities/icons";
import { useSidebarStore } from "../MainAppStore/sidebarStore";
import AppLogo from "../../MainAppAssets/ProcTrack2.svg";
import { Link } from "react-router-dom";
import "../../MainAppCss/main.css";
import { createPortal } from "react-dom";

interface PageItem {
  id: number;
  label: string;
  route: string;
}

interface RoleItem {
  id: number;
  label: string;
  pages: PageItem[];
}

interface MenuItem {
  id: number;
  label: string;
  icon: string;
  route: string;
  roles?: RoleItem[];
}

interface SidebarProps {
  menuItems: MenuItem[];
}

export const Sidebar: React.FC<SidebarProps> = ({ menuItems }) => {
  const { isOpen, toggleSidebar } = useSidebarStore();
  const [hoveredMenuId, setHoveredMenuId] = useState<number | null>(null);
  const [hoveredRoleId, setHoveredRoleId] = useState<number | null>(null);
  const [popupPos, setPopupPos] = useState<{ top: number; left: number } | null>(null);

  // Store refs of menu items to get positions
  const menuRefs = useRef<Map<number, HTMLDivElement | null>>(new Map());

  const onMenuMouseEnter = (id: number) => {
    setHoveredMenuId(id);
    setHoveredRoleId(null);
    const el = menuRefs.current.get(id);
    if (el) {
      const rect = el.getBoundingClientRect();
      setPopupPos({
        top: rect.top,
        left: rect.right + 8, // 8px gap from sidebar right edge
      });
    }
  };

  const onMenuMouseLeave = () => {
    // Use a small timeout to allow nested popups to detect hover before closing
    setTimeout(() => {
      setHoveredMenuId(null);
      setHoveredRoleId(null);
      setPopupPos(null);
    }, 2000);
  };

  const onRoleMouseEnter = (roleId: number) => {
    setHoveredRoleId(roleId);
  };

  const onRoleMouseLeave = () => {
    setTimeout(() => {
      setHoveredRoleId(null);
    }, 2000);
  };
  const setMenuRef = (id: number) => (el: HTMLDivElement | null) => {
  menuRefs.current.set(id, el);
};
const popupRef = useRef<HTMLDivElement | null>(null);
useEffect(() => {
    function handleClickOutside(event: MouseEvent) {
      if (
        popupRef.current && 
        !popupRef.current.contains(event.target as Node)
      ) {
        setHoveredMenuId(null);
      }
    }

    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, []);

  return (
    <>
      <aside
        className={`fixed top-0 left-0 h-screen transition-all duration-300 hidden lg:block 
                  ${isOpen ? "w-80" : "w-20"} z-40 overflow-visible`}
      >
        {/* Toggle Button */}
        <div className="flex items-center justify-around h-15 mb-5 border-b-2 border-b-gray-300">
          <button onClick={toggleSidebar}>
            {isOpen ? (
              <img
                src={AppLogo}
                alt="Procurement Tracker"
                className="h-10 sm:h-12 md:h-14 cursor-pointer"
              />
            ) : (
              <HamburgerIcon />
            )}
          </button>
        </div>

        {/* Menu Items */}
        <div className="overflow-y-auto mt-10 h-[80vh] px-1 custom-scrollbar relative">
          <nav className="space-y-2 p-1">
            {menuItems.map((item) => (
              <div
                key={item.id}
                ref={setMenuRef(item.id)}
                className="relative"
                onClick={() => onMenuMouseEnter(item.id)}
                // onMouseLeave={onMenuMouseLeave}
              >
                <div className="hover_ p-3 shadow-md border-4 border-transparent rounded-2xl flex items-center justify-start mb-4 cursor-pointer">
                  <span className="me-2">{iconMap[item.icon]}</span>
                  {isOpen && <span>{item.label}</span>}
                </div>
              </div>
            ))}
          </nav>
        </div>
      </aside>

      {/* Roles Popup Portal */}
      {hoveredMenuId !== null && popupPos && menuItems.find((i) => i.id === hoveredMenuId)?.roles && 
        createPortal(
          <div
            style={{
              position: "fixed",
              top: popupPos.top,
              left: popupPos.left,
              width: 224, // same as w-56 in Tailwind (14rem * 16px)
              backgroundColor: "white",
              boxShadow: "0 4px 8px rgba(0,0,0,0.15)",
              borderRadius: "0.75rem",
              padding: "0.5rem",
              zIndex: 9999,
              userSelect: "none",
            }}
            ref={popupRef}
            onClick={() => {
              // Keep popup open on hover
            }}
            // onMouseLeave={() => {
            //   setHoveredMenuId(null);
            //   setHoveredRoleId(null);
            //   setPopupPos(null);
            // }}
          >
            {menuItems
              .find((i) => i.id === hoveredMenuId)
              ?.roles?.map((role) => (
                <div
                  key={role.id}
                  className="relative"
                  onClick={() => onRoleMouseEnter(role.id)}
                  // onMouseLeave={onRoleMouseLeave}
                >
                  <div className="p-2 hover:bg-emerald-100 rounded-md cursor-pointer font-semibold">
                    {role.label}
                  </div>

                  {/* Nested Page Popup */}
                  {hoveredRoleId === role.id && (
                    <div
                      className="absolute top-0 left-full ml-2 w-56 bg-white shadow-xl rounded-xl p-2 z-50"
                      style={{ minWidth: 224 }}
                    >
                      {role.pages.map((page) => (
                        <Link
                          key={page.id}
                          to={page.route}
                          className="block p-2 text-sm text-gray-800 hover:bg-emerald-100 rounded-md"
                        >
                          {page.label}
                        </Link>
                      ))}
                    </div>
                  )}
                </div>
              ))}
          </div>,
          document.body
        )}
    </>
  );
};
