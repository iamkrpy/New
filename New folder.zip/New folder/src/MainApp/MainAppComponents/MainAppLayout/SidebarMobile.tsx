import { useState } from "react";
import { useSidebarStore } from "../MainAppStore/sidebarStore";
import { iconMap, HamburgerIcon } from "../../MainAppUtilities/icons";
import AppLogo from "../../MainAppAssets/ProcTrack2.svg";
import { Link, useLocation } from "react-router-dom";

interface PageItem {
  id: number;
  label: string;
  route: string;
}

interface RoleItem {
  id: number;
  label: string;
  pages: PageItem[];
}

interface MenuItem {
  id: number;
  label: string;
  icon: string;
  route: string;
  roles?: RoleItem[];
}

interface SidebarProps {
  menuItems: MenuItem[];
}

export const SidebarMobile: React.FC<SidebarProps> = ({ menuItems }) => {
  const { isOpen, toggleSidebar, setSidebar } = useSidebarStore();
  const location = useLocation();

  // const [swing, setSwing] = useState(false);
  const [expandedMenus, setExpandedMenus] = useState<number[]>([]);
  const [expandedRoles, setExpandedRoles] = useState<number[]>([]);

  const toggleMenuExpand = (id: number) => {
    setExpandedMenus((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const toggleRoleExpand = (id: number) => {
    setExpandedRoles((prev) =>
      prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };

  const handleLogoClick = () => {
    // setSwing(true);
    // setTimeout(() => setSwing(false), 1000);
  };

  if (!isOpen) return null;

  return (
    <>
      {/* Backdrop */}
      <div
        className="fixed inset-0 bg-black opacity-60 z-200 lg:hidden"
        onClick={() => setSidebar(false)}
      ></div>

      {/* Mobile Sidebar */}
      <aside className="fixed top-0 left-0 h-screen w-64 bg-white z-250 lg:hidden shadow-md transition-all duration-700">
        <div className="flex items-center justify-around h-16 mb-5 border-b-2 border-gray-300">
          <button onClick={toggleSidebar} className="text-lg">
            {isOpen ? (
              <img
                src={AppLogo}
                alt="Procurement Tracker"
                onClick={handleLogoClick}
                // className={`h-10 cursor-pointer ${swing ? "animate-pulse" : ""}`}
                className={`h-10 cursor-pointer`}
              />
            ) : (
              <HamburgerIcon />
            )}
          </button>
        </div>

        <div className="overflow-y-auto mt-4 h-[85vh] px-1 custom-scrollbar">
          <nav className="space-y-2 px-4">
            {menuItems.map((menu) => {
              const isMenuExpanded = expandedMenus.includes(menu.id);
              const hasRoles = menu.roles && menu.roles.length > 0;

              return (
                <div key={menu.id}>
                  {/* Menu Level */}
                  <div
                    className="hover:bg-gray-100 p-3 shadow border border-transparent rounded-2xl flex items-center justify-between mb-2 cursor-pointer"
                    onClick={() =>
                      hasRoles ? toggleMenuExpand(menu.id) : setSidebar(false)
                    }
                  >
                    <div className="flex items-center gap-2">
                      <span>{iconMap[menu.icon]}</span>
                      <span>{menu.label}</span>
                    </div>
                    {hasRoles && <span>{isMenuExpanded ? "▲" : "▼"}</span>}
                  </div>

                  {/* Role Level */}
                  {hasRoles && isMenuExpanded && (
                    <div className="ml-4 border-l-2 border-gray-200 pl-2">
                      {menu.roles!.map((role) => {
                        const isRoleExpanded = expandedRoles.includes(role.id);
                        return (
                          <div key={role.id}>
                            <div
                              className="cursor-pointer mb-1 flex items-center justify-between p-2 hover:bg-gray-100 rounded"
                              onClick={() => toggleRoleExpand(role.id)}
                            >
                              <span>{role.label}</span>
                              <span>{isRoleExpanded ? "▲" : "▼"}</span>
                            </div>

                            {/* Page Level */}
                            {isRoleExpanded && (
                              <div className="ml-4 border-l pl-2 space-y-1">
                                {role.pages.map((page) => (
                                  <Link
                                    key={page.id}
                                    to={page.route}
                                    onClick={() => setSidebar(false)}
                                    className={`block px-3 py-1 rounded hover:bg-gray-100 ${
                                      location.pathname === page.route
                                        ? "bg-gray-200 font-semibold"
                                        : ""
                                    }`}
                                  >
                                    {page.label}
                                  </Link>
                                ))}
                              </div>
                            )}
                          </div>
                        );
                      })}
                    </div>
                  )}
                </div>
              );
            })}
          </nav>
        </div>
      </aside>
    </>
  );
};
