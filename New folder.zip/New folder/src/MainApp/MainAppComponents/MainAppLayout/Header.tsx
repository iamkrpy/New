import React, { useEffect, useRef, useState } from "react";
import AppLogo from "../../MainAppAssets/ProcTrack2.svg";
import AvatarLogo from '../../MainAppAssets/avatar.svg';
import "../../MainAppCss/swing.css";
import { HamburgerIcon, NotificationBell, LogoutIcon } from "../../MainAppUtilities/icons";
import { useSidebarStore } from "../MainAppStore/sidebarStore";
import TataSteelLogo from '../../MainAppAssets/tata-steel-logo1.png';
import Portal from "../../MainAppUtilities/Portal";
import { useAuth } from "../../MainAppAuth/AuthContext";
import { useNavigate } from "react-router-dom";

const UserAvatar = ({ src }: { src?: string }) => (
  <img
    src={src || AvatarLogo}
    alt="User"
    className="w-8 h-8 sm:w-10 sm:h-10 rounded-full object-cover bg-gray-200 cursor-pointer"
  />
);

export const Header: React.FC = () => {
  const { isOpen, toggleSidebar } = useSidebarStore();
  const [showProfile, setShowProfile] = useState(false);
  const profileRef = useRef<HTMLDivElement>(null);
  const navigate = useNavigate();
  const { user, logout } = useAuth();

  const toggleProfile = () => setShowProfile(!showProfile);

  const handleLogout = async () => {
    await logout();
  };

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setShowProfile(false);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  const userImageUrl = user?.userId
    ? `https://tslapps.tatasteel.co.in/intranet/GIH001.ashx?cid=${user.userId}`
    : AvatarLogo;

  return (
    <header className="sticky top-0 bg-neutral-200 shadow-md z-[50]">
      <div className="mx-auto pe-2 flex items-center justify-between">
        {/* Left Section */}
        <div className="flex items-center lg:gap-5 gap-3">
          {isOpen && (
            <button className="pl-2" onClick={toggleSidebar}>
              <HamburgerIcon />
            </button>
          )}
          <button className="lg:hidden" onClick={toggleSidebar}>
            <HamburgerIcon />
          </button>
          <img src={TataSteelLogo} alt="TatLogo" className="h-8 w-10 p-1 lg:h-15 lg:w-30" />
          {!isOpen && (
            <img
              src={AppLogo}
              alt="Procurement Tracker"
              className="h-10 sm:h-12 md:h-14 cursor-pointer"
            />
          )}
        </div>

        {/* Right Section */}
        <div className="flex items-center lg:gap-6 gap-2 relative">
          <NotificationBell />
          <button onClick={toggleProfile} className="rounded-full border-red-400 border-2">
            <UserAvatar src={userImageUrl} />
          </button>

          {showProfile && (
            <Portal>
              <div
                ref={profileRef}
                className="fixed top-16 right-4 w-56 bg-white shadow-lg rounded-lg border border-gray-200 z-[9999] p-4"
              >
                <div className="flex-col text-center gap-3">
                  <div className="flex justify-center p-2">
                    <img
                      src={userImageUrl}
                      alt="User"
                      className="w-14 h-14 rounded-full object-cover border-red-400 border-2"
                    />
                  </div>
                  <div className="p-2">
                    <div className="text-sm lg:text-xl font-bold">{user?.name || "User"}</div>
                    <div className="text-xs lg:text-sm text-gray-500">{user?.designation || "Head"}</div>
                  </div>
                  <div className="border-t-2 border-red-300 p-2">
                    <button
                      onClick={handleLogout}
                      className="lg:text-xl font-bold flex items-center gap-2 mx-auto hover:cursor-pointer"
                    >
                      <LogoutIcon />
                      <span>Log out</span>
                    </button>
                  </div>
                </div>
              </div>
            </Portal>
          )}
        </div>
      </div>
    </header>
  );
};
