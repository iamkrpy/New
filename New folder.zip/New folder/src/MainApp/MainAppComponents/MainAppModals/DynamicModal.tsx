import React from "react";
import { createPortal } from "react-dom";
import { motion, AnimatePresence } from "framer-motion";
import { X } from "lucide-react";

export type ModalType = "confirmation" | "error" | "warning";

export interface DynamicModalProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  type: ModalType;
  title?: string;
  message: string;
  // Confirmation specific
  positiveText?: string;
  negativeText?: string;
  onPositive?: () => void;
  onNegative?: () => void;
  // Error/Warning specific
  buttonText?: string;
  onButtonClick?: () => void;
}

export const DynamicModal: React.FC<DynamicModalProps> = ({
  open,
  onOpenChange,
  type,
  title,
  message,
  positiveText = "Yes",
  negativeText = "No",
  onPositive,
  onNegative,
  buttonText = "OK",
  onButtonClick
}) => {
  const modalRoot = document.getElementById("modal-root") || document.body;

  const handleClose = () => onOpenChange(false);

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          exit={{ opacity: 0 }}
        >
          <motion.div
            className="bg-white rounded-2xl shadow-lg p-6 w-full max-w-md"
            initial={{ scale: 0.9, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.9, opacity: 0 }}
          >
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">
                {title || (type === "confirmation" ? "Confirm" : type === "error" ? "Error" : "Warning")}
              </h2>
              <button onClick={handleClose} className="p-1 rounded hover:bg-gray-100">
                <X size={20} />
              </button>
            </div>

            <p className="text-gray-700 mb-6">{message}</p>

            <div className="flex justify-end gap-3">
              {type === "confirmation" ? (
                <>
                  <button
                    className="px-4 py-2 rounded bg-gray-200 hover:bg-gray-300"
                    onClick={() => {
                      onNegative?.();
                      handleClose();
                    }}
                  >
                    {negativeText}
                  </button>
                  <button
                    className="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700"
                    onClick={() => {
                      onPositive?.();
                      handleClose();
                    }}
                  >
                    {positiveText}
                  </button>
                </>
              ) : (
                <button
                  className="px-4 py-2 rounded bg-blue-600 text-white hover:bg-blue-700"
                  onClick={() => {
                    onButtonClick?.();
                    handleClose();
                  }}
                >
                  {buttonText}
                </button>
              )}
            </div>
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    modalRoot
  );
};