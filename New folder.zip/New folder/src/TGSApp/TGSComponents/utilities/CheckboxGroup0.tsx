import React, { useEffect, useState } from "react";

interface Option {
  label: string;
  value: string;
}

interface CheckboxGroupProps {
  label: string;
  dataSourceUrl?: string;
  options?: Option[];
  selected: string[];
  onChange: (selected: string[]) => void;
  required?: boolean;
  onError?: (hasError: boolean) => void;
}

const CheckboxGroup: React.FC<CheckboxGroupProps> = ({
  label,
  dataSourceUrl,
  options = [],
  selected,
  onChange,
  required = false,
  onError,
}) => {
  const [internalOptions, setInternalOptions] = useState<Option[]>([]);
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (dataSourceUrl) {
      fetch(dataSourceUrl)
        .then((res) => res.json())
        .then((data) =>
          setInternalOptions(
            data.map((item: any) => ({
              label: item.label ?? item.name ?? item.value,
              value: item.value ?? item.id ?? item.code,
            }))
          )
        )
        .catch((err) => {
          console.error("Checkbox data load error:", err);
        });
    } else {
      setInternalOptions(options);
    }
  }, [dataSourceUrl, options]);

  useEffect(() => {
  if (!touched) return;

  let errorMessage = null;

  if (required && selected.length === 0) {
    errorMessage = "Please select at least one option.";
  }

  setError(errorMessage);
  if (onError) onError(!!errorMessage);
}, [selected, required, touched]);


  const toggle = (val: string) => {
    onChange(
      selected.includes(val)
        ? selected.filter((v) => v !== val)
        : [...selected, val]
    );
  };

  return (
    <div>
      <label className="font-medium text-sm block mb-1">{label}</label>
      <div className="space-y-2">
        {internalOptions.map((opt) => (
          <label key={opt.value} className="flex items-center space-x-2">
            <input
              type="checkbox"
              checked={selected.includes(opt.value)}
              onChange={() => {
                toggle(opt.value);
                setTouched(true);
              }}
              className="accent-blue-600"
            />
            <span>{opt.label}</span>
          </label>
        ))}
      </div>
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
};

export default CheckboxGroup;
