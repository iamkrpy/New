import React, { useState, useEffect } from "react";

interface ValidatedTextInputProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  required?: boolean;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  disabled?: boolean;
  onErrorChange?: (hasError: boolean, message?: string) => void;
}

const ValidatedTextInput: React.FC<ValidatedTextInputProps> = ({
  label,
  value,
  onChange,
  placeholder = "",
  required = false,
  minLength,
  maxLength,
  pattern,
  disabled = false,
  onErrorChange,
}) => {
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const validate = (): string | null => {
    if (required && value.trim() === "") {
      return "This field is required.";
    } else if (minLength && value.length < minLength) {
      return `Minimum ${minLength} characters required.`;
    } else if (maxLength && value.length > maxLength) {
      return `Maximum ${maxLength} characters allowed.`;
    } else if (pattern && !pattern.test(value)) {
      return "Invalid format.";
    }
    return null;
  };

  useEffect(() => {
    if (!touched) return;

    const err = validate();
    setError(err);
    onErrorChange?.(!!err, err ?? undefined);
  }, [value, touched]);

  return (
    <div className="w-full">
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>
      <input
        type="text"
        value={value}
        disabled={disabled}
        onChange={(e) => onChange(e.target.value)}
        onBlur={() => setTouched(true)}
        placeholder={placeholder}
        className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 ${
          error ? "border-red-500 ring-red-200" : "border-gray-300 focus:ring-blue-300"
        } ${disabled ? "bg-gray-100 cursor-not-allowed" : "bg-white"}`}
      />
      {error && <p className="text-sm text-red-600 mt-1">{error}</p>}
    </div>
  );
};

export default ValidatedTextInput;
