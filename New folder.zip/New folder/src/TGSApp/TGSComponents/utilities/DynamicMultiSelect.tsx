import { useState, useEffect } from "react";
import { motion, AnimatePresence } from "framer-motion";

interface DynamicMultiSelectProps<T> {
  label: string;
  fetchOptions: (query: string) => Promise<T[]>; // API function
  getOptionLabel: (option: T) => string; // display text extractor
  onChange: (selected: T[]) => void; // callback for parent
  selected: T[];
}

export function DynamicMultiSelect<T>({
  label,
  fetchOptions,
  getOptionLabel,
  onChange,
  selected,
}: DynamicMultiSelectProps<T>) {
  const [query, setQuery] = useState("");
  const [options, setOptions] = useState<T[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query) {
      setOptions([]);
      return;
    }
    setLoading(true);
    fetchOptions(query).then((res) => {
      setOptions(res);
      setLoading(false);
    });
  }, [query]);

  const addOption = (option: T) => {
    if (!selected.includes(option)) {
      onChange([...selected, option]);
      setQuery(""); // reset search after selection
      setOptions([]);
    }
  };

  const removeOption = (option: T) => {
    onChange(selected.filter((s) => s !== option));
  };

  return (
    <div className="space-y-2">
      <label className="block text-sm font-semibold">{label}</label>
      <input
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder={`Search ${label}`}
        className="border p-2 rounded w-full"
      />
      <AnimatePresence>
        {query && options.length > 0 && (
          <motion.ul
            initial={{ opacity: 0, y: -5 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -5 }}
            className="border rounded bg-white max-h-40 overflow-y-auto shadow-lg"
          >
            {options.map((option, index) => (
              <li
                key={index}
                onClick={() => addOption(option)}
                className="p-2 hover:bg-emerald-100 cursor-pointer"
              >
                {getOptionLabel(option)}
              </li>
            ))}
          </motion.ul>
        )}
      </AnimatePresence>

      {selected.length > 0 && (
        <ul className="space-y-1">
          {selected.map((option, index) => (
            <li
              key={index}
              className="flex justify-between items-center bg-emerald-50 p-2 rounded"
            >
              {getOptionLabel(option)}
              <button
                className="text-red-500 hover:underline"
                onClick={() => removeOption(option)}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}
      {loading && <p className="text-sm text-gray-500">Loading...</p>}
    </div>
  );
}
