import React, { useMemo, useReducer, useRef, useEffect, useState } from "react";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { motion, AnimatePresence } from "framer-motion";
import {
  ExpandIcon,
  CollapseIcon,
  DeleteIcon,
  RefreshIcon,
  SearchIcon,
  ColumnsIcon,
  ExportIcon,
  PointerIcon,
  EditIcon,
} from "./icons";
import EditRowModal from "../Modals/EditRowModal15";
import UploadModal from "../Modals/UploadModalBulk";

interface TableColumnsConfig {
  Header: string;
  accessor: string;
  parentHeader?: string;
  filter?: boolean;
  editable?: boolean;
  headerStyle?: React.CSSProperties;
  rowStyle?: React.CSSProperties;
  cellStyle?: (value: any, row: any) => React.CSSProperties;
  cellRender?: (value: any, row: any) => React.ReactNode;
}
interface EditColumnsConfig {
  accessor: string;
  label: string;
  type: string;
  labelkey?: string;
  dataSourceUrl?: string;
  selectionMode?: "single" | "multiple";
  options?: { label: string; value: string }[];
  placeholder?: string;
  required?: boolean;
  editable?: boolean;
}
interface BulkEditColumnsConfig {
  Header: string;
  accessor: string;
  editable?: boolean;
  required?: boolean;
  type?: "string" | "number" | "date";
  allowedValues?: string[];
  maxLength?: number;
  format?: RegExp;
}

interface TableProps {
  columns: TableColumnsConfig[];
  data: any[];
  commonHeader?: string;
  editable?: boolean;
  selectable?: boolean;
  visibleColumnCount?: number;
  collapsable?: boolean;
  uniqueKeys?: string[];
  editColumnsConfig?: EditColumnsConfig[];
  onSave: (updatedRows: any[]) => void;
  rowsSelected?: (selectedRowsForTable: any[]) => void;
  isRowSelectable?: (row: any) => boolean;
  BulkUpdatePayloadMapper?: (row: any) => any;
  BulkUpdateEditColumnConfig?: BulkEditColumnsConfig[];
  apiURL?: string;
}

type TableState = {
  search: string;
  filters: Record<string, string>;
  selectionFilter: "all" | "selected" | "unselected";
  currentPage: number;
  rowsPerPage: number;
  selectedRows: Set<string>;
  visibleColumns: Set<string>;
  sortConfig: { key: string; direction: "asc" | "desc" } | null;
  showUtilities: boolean;
  showColumnSelector: boolean;
  expanded: boolean;
};

type Action =
  | { type: "SET_SEARCH"; payload: string }
  | { type: "SET_FILTER"; payload: { key: string; value: string } }
  | { type: "SET_SELECTION_FILTER"; payload: "all" | "selected" | "unselected" }
  | { type: "SET_CURRENT_PAGE"; payload: number }
  | { type: "SET_ROWS_PER_PAGE"; payload: number }
  | { type: "TOGGLE_SELECT_ROW"; payload: string }
  | { type: "SELECT_ALL_ROWS"; payload: string[] }
  | { type: "DESELECT_ALL_ROWS"; payload: string[] }
  | { type: "RESET_SELECTION" }
  | { type: "TOGGLE_COLUMN"; payload: string }
  | { type: "SET_VISIBLE_COLUMNS"; payload: Set<string> }
  | { type: "TOGGLE_SORT"; payload: string }
  | { type: "TOGGLE_UTILITIES" }
  | { type: "TOGGLE_COLUMN_SELECTOR" }
  | { type: "TOGGLE_EXPANDED" }
  | { type: "RESET_ALL"; payload: Set<string> }
  | { type: "SET_COLUMN_SELECTOR"; payload: boolean }
  | { type: "SET_UTILITIES"; payload: boolean };

const initialState = (columns: TableColumnsConfig[]): TableState => ({
  search: "",
  filters: {},
  selectionFilter: "all",
  currentPage: 1,
  rowsPerPage: 10,
  selectedRows: new Set(),
  visibleColumns: new Set(columns.map((c) => c.accessor)),
  sortConfig: null,
  showUtilities: false,
  showColumnSelector: false,
  expanded: true,
});

const reducer = (state: TableState, action: Action): TableState => {
  switch (action.type) {
    case "SET_SEARCH":
      return { ...state, search: action.payload, currentPage: 1 };
    case "SET_FILTER":
      return {
        ...state,
        filters: {
          ...state.filters,
          [action.payload.key]: action.payload.value,
        },
        currentPage: 1,
      };
    case "SET_SELECTION_FILTER":
      return { ...state, selectionFilter: action.payload, currentPage: 1 };
    case "SET_CURRENT_PAGE":
      return { ...state, currentPage: action.payload };
    case "SET_ROWS_PER_PAGE":
      return { ...state, rowsPerPage: action.payload, currentPage: 1 };
    case "TOGGLE_SELECT_ROW": {
      const selected = new Set(state.selectedRows);
      selected.has(action.payload)
        ? selected.delete(action.payload)
        : selected.add(action.payload);
      return { ...state, selectedRows: selected };
    }
    case "SELECT_ALL_ROWS": {
      const selected = new Set(state.selectedRows);
      action.payload.forEach((k) => selected.add(k));
      return { ...state, selectedRows: selected };
    }
    case "DESELECT_ALL_ROWS": {
      const selected = new Set(state.selectedRows);
      action.payload.forEach((k) => selected.delete(k));
      return { ...state, selectedRows: selected };
    }
    case "RESET_SELECTION":
      return { ...state, selectedRows: new Set() };
    case "TOGGLE_COLUMN": {
      const visible = new Set(state.visibleColumns);
      if (visible.has(action.payload)) {
        if (visible.size > 1) visible.delete(action.payload);
      } else {
        visible.add(action.payload);
      }
      return { ...state, visibleColumns: visible };
    }
    case "SET_VISIBLE_COLUMNS":
      return { ...state, visibleColumns: action.payload };
    case "TOGGLE_SORT": {
      const { sortConfig } = state;
      if (!sortConfig || sortConfig.key !== action.payload) {
        return {
          ...state,
          sortConfig: { key: action.payload, direction: "asc" },
        };
      } else if (sortConfig.direction === "asc") {
        return {
          ...state,
          sortConfig: { key: action.payload, direction: "desc" },
        };
      } else {
        return { ...state, sortConfig: null };
      }
    }
    case "TOGGLE_UTILITIES":
      return { ...state, showUtilities: !state.showUtilities };
    case "SET_UTILITIES":
      return { ...state, showUtilities: action.payload };
    case "TOGGLE_COLUMN_SELECTOR":
      return { ...state, showColumnSelector: !state.showColumnSelector };
    case "SET_COLUMN_SELECTOR":
      return { ...state, showColumnSelector: action.payload };
    case "TOGGLE_EXPANDED":
      return { ...state, expanded: !state.expanded };
    case "RESET_ALL":
      return {
        ...initialState([]),
        visibleColumns: action.payload,
        expanded: true,
      };
    default:
      return state;
  }
};

const DynamicTableData: React.FC<TableProps> = ({
  columns,
  data,
  selectable = false,
  editable = false,
  visibleColumnCount,
  collapsable = false,
  uniqueKeys,
  editColumnsConfig,
  onSave,
  rowsSelected,
  isRowSelectable: isRowSelectableProp,
  BulkUpdateEditColumnConfig,
  BulkUpdatePayloadMapper,
  apiURL,
}) => {
  if (selectable && (!uniqueKeys || uniqueKeys.length === 0)) {
    throw new Error(
      '[DynamicTableData]: "uniqueKeys" must be provided when "selectable" is true.'
    );
  }
  const isRowSelectable = (row: any) => {
    return typeof isRowSelectableProp === "function" ? isRowSelectableProp(row) : true;
  }

  const getRowKey = useMemo(() => {
    if (selectable && (!uniqueKeys || uniqueKeys.length === 0)) {
      throw new Error("When selectable=true, uniqueKeys must be provided.");
    }
    return (row: any): string => {
      if (typeof row !== "object" || row === null) {
        console.warn("Invalid row passed to getRowKey:", row);
        return "__invalid_row__";
      }
      return uniqueKeys.map((key) => String(row[key])).join("||");
    };
  }, [uniqueKeys, selectable]);
  const [tableData, setTableData] = useState(data);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [rowsToEdit, setRowsToEdit] = useState<any[]>([]);
  const handleEditSelectedRows = () => {
    const selected = data.filter((row) => selectedRows.has(getRowKey(row)));
    if (selected.length === 0) {
      alert("Please select at least one row to edit.");
      return;
    }

    if (selected.length > 10) {
      alert("You can only edit up to 10 rows at once.");
      return;
    }

    setRowsToEdit(selected);
    setEditModalOpen(true);
  };

  // const handleSaveEditedRows = (updatedRows: any[]) => {
  //   setTableData((prevData) =>
  //     prevData.map((row) => {
  //       const updated = updatedRows.find(
  //         (r) => getRowKey(r) === getRowKey(row)
  //       );
  //       return updated ? updated : row;
  //     })
  //   );
  //   setEditModalOpen(false); // Close the modal
  // };
  const handleSaveEditedRows = async (updatedRows: any[]) => {
    // try {
    //   const response = await axios.post('http://localhost:57730/api/smartprocTGS/updateSubcategoryBuyerMapping', updatedRows);

    //   if (response.data?.isSuccess) {
    //     setEditModalOpen(false); // Close modal
    //     if (onDataRefresh) onDataRefresh(); // Ask parent to reload latest data
    //   } else {
    //     alert(`Update failed: ${response.data?.message || 'Unknown error'}`);
    //   }
    // } catch (error: any) {
    //   alert(`API Error: ${error.message}`);
    // }
    onSave(updatedRows);
  };

  const [state, dispatch] = useReducer(reducer, columns, initialState);
  const {
    search,
    filters,
    selectionFilter,
    selectedRows,
    visibleColumns,
    sortConfig,
    currentPage,
    rowsPerPage,
  } = state;
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const handleUploadResult = (result: {
    message: string;
    successCount: number;
    failureCount: number;
    excelBlobUrl: string;
  }) => {
    alert(
      `${result.message}\n✅ Success: ${result.successCount}\n❌ Failed: ${result.failureCount}`
    );
    if (result.excelBlobUrl) {
      const link = document.createElement("a");
      link.href = result.excelBlobUrl;
      link.download = "upload-result.xlsx";
      link.click();
    }
  };
  const filteredData = useMemo(() => {
    return tableData.filter((row) => {
      const matchesGlobal =
        !search ||
        Object.values(row).some((val) =>
          String(val).toLowerCase().includes(search.toLowerCase())
        );
      const matchesFilters = Object.entries(filters).every(
        ([key, val]) =>
          val === "" ||
          String(row[key]).toLowerCase().includes(val.toLowerCase())
      );
      const rowId = getRowKey(row);
      const matchesSelection =
        selectionFilter === "all"
          ? true
          : selectionFilter === "selected"
            ? selectedRows.has(rowId)
            : !selectedRows.has(rowId);
      return matchesGlobal && matchesFilters && matchesSelection;
    });
  }, [search, filters, data, selectionFilter, selectedRows, getRowKey]);

  const selectAllRef = useRef<HTMLInputElement>(null);
  const columnBoxRef = useRef<HTMLDivElement>(null);
  const exportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    setTableData(data);
  }, [data]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        columnBoxRef.current &&
        !columnBoxRef.current.contains(event.target as Node)
      ) {
        dispatch({ type: "SET_COLUMN_SELECTOR", payload: false });
      }
      if (
        exportRef.current &&
        !exportRef.current.contains(event.target as Node)
      ) {
        dispatch({ type: "SET_UTILITIES", payload: false });
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  useEffect(() => {
    handleRowSelected();
  }, [selectedRows]);

  const shouldScroll =
    state.visibleColumns.size > (visibleColumnCount ?? Number.MAX_SAFE_INTEGER);

  const sortedData = useMemo(() => {
    if (!sortConfig) return filteredData;
    return [...filteredData].sort((a, b) => {
      const valA = a[sortConfig.key];
      const valB = b[sortConfig.key];
      return valA < valB
        ? sortConfig.direction === "asc"
          ? -1
          : 1
        : valA > valB
          ? sortConfig.direction === "asc"
            ? 1
            : -1
          : 0;
    });
  }, [filteredData, sortConfig]);

  const totalPages = useMemo(
    () => Math.ceil(sortedData.length / rowsPerPage),
    [sortedData.length, rowsPerPage]
  );

  const paginatedData = useMemo(
    () =>
      sortedData.slice(
        (currentPage - 1) * rowsPerPage,
        currentPage * rowsPerPage
      ),
    [sortedData, currentPage, rowsPerPage]
  );
  const selectableKeysOnPage = useMemo(
    () => paginatedData.filter(isRowSelectable).map((row) => getRowKey(row)),
    [paginatedData, isRowSelectable, getRowKey]
  );

  const isAllCurrentPageSelected =
    selectableKeysOnPage.length > 0 &&
    selectableKeysOnPage.every((k) => selectedRows.has(k));

  const isAnyCurrentPageSelected =
    selectableKeysOnPage.some((k) => selectedRows.has(k));

  // const isAllCurrentPageSelected = paginatedData.every((row) =>
  //   selectedRows.has(getRowKey(row))
  // );
  // const isAnyCurrentPageSelected = paginatedData.some((row) =>
  //   selectedRows.has(getRowKey(row))
  // );

  useEffect(() => {
    if (selectAllRef.current) {
      selectAllRef.current.indeterminate =
        isAnyCurrentPageSelected && !isAllCurrentPageSelected;
    }
  }, [isAllCurrentPageSelected, isAnyCurrentPageSelected]);

  const handleSelectRow = (row: any) => {
    const key = getRowKey(row);
    dispatch({ type: "TOGGLE_SELECT_ROW", payload: key });
  };
  const handleRowSelected = () => {
    const selected = tableData.filter((row) => selectedRows.has(getRowKey(row)));
    if(selectable){
      rowsSelected(selected);
    }
    
  };
  // const handleSelectAll = () => {
  //   console.log(isAllCurrentPageSelected)
  //   const keys = paginatedData
  //     .filter(isRowSelectable)
  //     .map((row) => getRowKey(row));
  //   dispatch({
  //     type: isAnyCurrentPageSelected ? "DESELECT_ALL_ROWS" : "SELECT_ALL_ROWS",
  //     payload: keys,
  //   });
  // };
  const handleSelectAll = () => {
    if (selectableKeysOnPage.length === 0) return;

    dispatch({
      type: isAllCurrentPageSelected ? "DESELECT_ALL_ROWS" : "SELECT_ALL_ROWS",
      payload: selectableKeysOnPage,
    });
  };


  const handleDelete = () => {
    const toRemove = new Set(state.selectedRows);
    const remainingRows = tableData.filter((row) => !toRemove.has(getRowKey(row)))
    setTableData((prev) => prev.filter((row) => !toRemove.has(getRowKey(row))));
    dispatch({ type: "RESET_SELECTION" });
  };

  const handleExport = (type: "csv" | "excel") => {
    // var tdata = tableData;
    // if (selectionFilter == "all") {
    //   tdata = tableData;
    // } else {
    //   tdata = paginatedData;
    // }
    var tdata = paginatedData;
    const exportData = tdata.map((row) => {
      const newRow: any = {};
      columns.forEach(
        (col) =>
          (newRow[col.Header] = col.cellRender
            ? col.cellRender(row[col.accessor], row)
            : row[col.accessor])
      );
      return newRow;
    });
    if (type === "csv") {
      const csv = Papa.unparse(exportData);
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      saveAs(blob, "table-data.csv");
    } else {
      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
      XLSX.writeFile(wb, "table-data.xlsx");
    }
  };

  const toggleSort = (accessor: string) => {
    dispatch({ type: "TOGGLE_SORT", payload: accessor });
  };

  // const toggleColumn = (accessor: string) => {
  //   dispatch({ type: "TOGGLE_COLUMN", payload: accessor });
  // };

  const groupedHeaders = useMemo(() => {
    const groups: Record<string, TableColumnsConfig[]> = {};
    columns.forEach((col) => {
      const group = col.parentHeader || "";
      if (!groups[group]) groups[group] = [];
      groups[group].push(col);
    });
    return groups;
  }, [columns]);

  const getPaginationNumbers = () => {
    const pageNumbers: (number | string)[] = [];
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || Math.abs(i - currentPage) <= 1) {
        pageNumbers.push(i);
      } else if (
        (i === currentPage - 2 && !pageNumbers.includes("...")) ||
        (i === currentPage + 2 && !pageNumbers.includes("..."))
      ) {
        pageNumbers.push("...");
      }
    }
    return pageNumbers;
  };
  const handleRefresh = () => {
    setTableData(data); // Resets table data to original
    dispatch({
      type: "RESET_ALL",
      payload: new Set(columns.map((c) => c.accessor)),
    });
  };

  const hasGroupHeaders = useMemo(
    () => Object.keys(groupedHeaders).some((key) => key !== ""),
    [groupedHeaders]
  );
  const activeFilterAccessors = Object.entries(filters)
    .filter(([_, value]) => value && value.trim() !== "")
    .map(([accessor]) => accessor);

  const hasGlobalSearch = search.trim() !== "";
  const filteredColumnHeaders = columns
    .filter((col) => activeFilterAccessors.includes(col.accessor))
    .map((col) => col.Header);
  const isCheckBoxFiltered = selectionFilter !== "all";
  const isActiveFilters = hasGlobalSearch || activeFilterAccessors.length > 0;
  const isFiltered =
    hasGlobalSearch || activeFilterAccessors.length > 0 || isCheckBoxFiltered;

  const tooltipText =
    (isCheckBoxFiltered ? "CheckBox Filter is not 'All' ;" : "") +
    (isActiveFilters
      ? "Column/s having filters: " +
      [
        ...(hasGlobalSearch ? ["Global Search"] : []),
        ...filteredColumnHeaders,
      ].join(", ")
      : "");
  const filteredSelectedCount = filteredData.filter((row) => {
    const key = getRowKey(row);
    return selectedRows.has(key);
  }).length;
  const selectedCount = tableData.filter((row) => {
    const key = getRowKey(row);
    return selectedRows.has(key);
  }).length;
  return (
    <div className="p-4">
      <div className="flex items-center justify-between flex-wrap gap-2 mb-4 ">
        <div className="bg-white border-2 border-lime-400 flex flex-wrap items-center justify-between w-full p-3 rounded-2xl">
          <div className="flex gap-2 items-center ">
            {!state.expanded && (
              <span className="font-bold text-yellow-700 p-2 h-15 flex items-center text-2xl">
                <span className="p-2">
                  Table is in Collapsed state. Click to expand
                </span>
                <PointerIcon fill="#cc1e1e" />
              </span>
            )}

            {collapsable && (
              <button
                onClick={() => dispatch({ type: "TOGGLE_EXPANDED" })}
                className="w-15 h-10 hover:cursor-pointer"
                title="Expand/Collapse"
              >
                {state.expanded ? <CollapseIcon /> : <ExpandIcon />}
              </button>
            )}

            {editable && state.expanded && state.selectedRows.size > 0 && (
              <button
                onClick={handleDelete}
                title="Delete Selected"
                className="w-15 h-10 hover:bg-red-300 hover:cursor-pointer rounded-2xl"
              >
                <DeleteIcon />
              </button>
            )}
            {editable && state.expanded && state.selectedRows.size > 0 && (
              <>
                <button
                  className="w-15 h-10 hover:bg-emerald-100 rounded-2xl hover:cursor-pointer"
                  title="Edit Selected Rows"
                  onClick={handleEditSelectedRows}
                >
                  <EditIcon />
                </button>
                <EditRowModal
                  isOpen={editModalOpen}
                  onClose={() => setEditModalOpen(false)}
                  onSave={handleSaveEditedRows}
                  getRowKey={getRowKey}
                  rows={rowsToEdit}
                  columns={editColumnsConfig}
                />
              </>
            )}
            {editable && state.expanded && (
              <>
                <button
                  onClick={() => setIsUploadModalOpen(true)}
                  className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
                >
                  📤 Upload Excel
                </button>

      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        columns={BulkUpdateEditColumnConfig}
        uniqueKeys={["tcs_catsubcat_desc"]}
        existingData={[]}
        apiUrl={apiURL}
        payloadMapper={BulkUpdatePayloadMapper}
        onResult={handleUploadResult}
      />

            </>
          )}


          {state.expanded && (
            <button
              onClick={handleRefresh}
              title="Refresh"
              className="w-15 h-10 hover:bg-yellow-300 hover:cursor-pointer rounded-2xl"
            >
              <RefreshIcon />
            </button>
          )}
        </div>

          {state.expanded && (
            <div className="mx-auto">
              <div className="flex items-center align-middle gap-2 text-md text-gray-700">
                {isFiltered ? (
                  <span className="bg-yellow-100 text-yellow-800 px-2 py-1 rounded font-bold h-10">
                    FILTER is applied inside the table view
                    <button
                      title={tooltipText}
                      className="ml-2 w-10 border rounded-2xl bg-white text-blue-500 hover:text-blue-700 cursor-pointer font-extrabold"
                    >
                      i
                    </button>
                  </span>
                ) : (
                  <span className="bg-green-100 text-green-800 px-2 py-1 rounded font-bold h-10">
                    NO Filter is applied inside the table view
                  </span>
                )}
                <span></span>
              </div>
            </div>
          )}

        {state.expanded && (
          <div className="flex items-center gap-3 ml-auto relative">
            <div className="flex items-center gap-0.5 border rounded">
              <label className="w-10 h-10">
                <SearchIcon fill="#d97c54" />
              </label>
              <input
                type="text"
                title="Search in Table"
                value={state.search}
                onChange={(e) =>
                  dispatch({ type: "SET_SEARCH", payload: e.target.value })
                }
                placeholder="Table Search"
                className="px-3 w-48 h-10 border-0 focus:outline-0"
              />
            </div>
            <div className="relative" ref={columnBoxRef}>
              <button
                onClick={() => dispatch({ type: "TOGGLE_COLUMN_SELECTOR" })}
                title="Column Visibility"
                className="w-10 h-8 hover:bg-blue-100 hover:cursor-pointer align-middle"
              >
                <ColumnsIcon fill1="#7DD2F0" fill2="#78C9E6" />
              </button>
              {state.showColumnSelector && (
                <div className="absolute right-0 z-20 mt-1 w-64 max-h-60 overflow-y-auto border bg-white p-2 shadow rounded">
                  <label className="block mb-2">
                    <input
                      type="checkbox"
                      className="hover:cursor-pointer"
                      checked={state.visibleColumns.size === columns.length}
                      onChange={(e) =>
                        dispatch({
                          type: "SET_VISIBLE_COLUMNS",
                          payload: e.target.checked
                            ? new Set(columns.map((c) => c.accessor))
                            : new Set([columns[0].accessor]),
                        })
                      }
                    />{" "}
                    Select All
                  </label>
                  {columns.map((col) => (
                    <label key={col.accessor} className="block text-sm">
                      <input
                        type="checkbox"
                        className="hover:cursor-pointer"
                        checked={state.visibleColumns.has(col.accessor)}
                        onChange={() =>
                          dispatch({
                            type: "TOGGLE_COLUMN",
                            payload: col.accessor,
                          })
                        }
                        disabled={
                          state.visibleColumns.size === 1 &&
                          state.visibleColumns.has(col.accessor)
                        }
                      />{" "}
                      {col.Header}
                    </label>
                  ))}
                </div>
              )}
            </div>
            <div className="relative" ref={exportRef}>
              <button
                onClick={() => dispatch({ type: "TOGGLE_UTILITIES" })}
                title="Utilities"
                className="w-15 h-8 flex align-middle items-center hover:cursor-pointer"
              >
                <ExportIcon stroke2="#054217" stroke1="#4acb3a" />
                <span>{state.showUtilities ? "▲" : "▼"}</span>
              </button>

                <AnimatePresence>
                  {state.showUtilities && (
                    <motion.div
                      initial={{ opacity: 0, y: -8 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, y: -8 }}
                      transition={{ duration: 0.2 }}
                      className="absolute right-0 mt-2 w-56 bg-white border rounded shadow-lg z-40 p-2 flex flex-col gap-2"
                    >
                      <button
                        onClick={() => handleExport("csv")}
                        className="w-full text-left px-3 py-1 hover:bg-gray-100 rounded"
                      >
                        Export CSV
                      </button>
                      <button
                        onClick={() => handleExport("excel")}
                        className="w-full text-left px-3 py-1 hover:bg-gray-100 rounded"
                      >
                        Export Excel
                      </button>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            </div>
          )}
        </div>

        <AnimatePresence initial={false}>
          {(!collapsable || state.expanded) && (
            <motion.div
              key="table-content"
              initial={{ height: 0, opacity: 0 }}
              animate={{ height: "auto", opacity: 1 }}
              exit={{ height: 0, opacity: 0 }}
              transition={{ duration: 0.3, ease: "easeInOut" }}
              style={{ overflow: "hidden", width: "100%" }}
            >
              <div
                className={`max-h-[60vh] overflow-y-auto rounded-4xl border-2 border-lime-400 ${shouldScroll ? "overflow-x-auto" : "w-full"
                  }`}
              >
                <table
                  className="border-separate border-spacing-0 bg-white text-2xl"
                  style={shouldScroll ? { minWidth: "max-content" } : {width:"100%"}}
                >
                  <thead className="sticky top-0 z-10 bg-white">
                    {hasGroupHeaders && (
                      <tr>
                        {selectable && (
                          <th className="p-2 sticky left-0 bg-white z-20" />
                        )}
                        {Object.entries(groupedHeaders).map(([group, cols]) => {
                          const visibleCount = cols.filter((c) =>
                            visibleColumns.has(c.accessor)
                          ).length;
                          if (visibleCount === 0) return null;
                          return (
                            <th
                              key={group}
                              colSpan={visibleCount}
                              className="border text-center px-2 py-1 bg-gray-100 font-bold"
                            >
                              {group}
                            </th>
                          );
                        })}
                      </tr>
                    )}
                    <tr>
                      {selectable && (
                        <th className="p-2 border text-center sticky left-0 bg-blue-100 z-20">
                          <input
                            ref={selectAllRef}
                            type="checkbox"
                            title="Select All"
                            className="w-5 h-5 align-middle hover:cursor-pointer"
                            onChange={handleSelectAll}
                            checked={isAllCurrentPageSelected}
                          />
                        </th>
                      )}
                      {columns
                        .filter((c) => visibleColumns.has(c.accessor))
                        .map((col) => (
                          <th
                            key={col.accessor}
                            className={`border px-2 py-1 cursor-pointer text-left bg-white`}
                            onClick={() => toggleSort(col.accessor)}
                            title={"Sort " + col.Header}
                            style={col.headerStyle}
                          >
                            <div className="flex items-center justify-center">
                              <span>{col.Header}</span>
                              <span className="w-10">
                                {sortConfig?.key === col.accessor && (
                                  <span>
                                    {sortConfig.direction === "asc" ? "▲" : "▼"}
                                  </span>
                                )}
                              </span>
                            </div>
                          </th>
                        ))}
                    </tr>
                    <tr>
                      {selectable && (
                        <th className="p-2 border text-center sticky left-0 z-20 bg-white">
                          <select
                            value={state.selectionFilter}
                            onChange={(e) =>
                              dispatch({
                                type: "SET_SELECTION_FILTER",
                                payload: e.target.value as
                                  | "all"
                                  | "selected"
                                  | "unselected",
                              })
                            }
                            title="Select Checkbox Type"
                            className="text-xs py-1 w-full rounded border hover:cursor-pointer"
                          >
                            <option value="all">All</option>
                            <option value="selected">Selected</option>
                            <option value="unselected">Unselected</option>
                          </select>
                        </th>
                      )}

                      {columns
                        .filter((c) => visibleColumns.has(c.accessor))
                        .map((col) => (
                          <th
                            key={col.accessor}
                            // className="border px-2 py-1 bg-gray-50"
                            className={`border px-2 py-1 bg-gray-50`}
                          >
                            {col.filter && (
                              <input
                                type="text"
                                value={state.filters[col.accessor] || ""}
                                onClick={(e) => e.stopPropagation()}
                                onChange={(e) =>
                                  dispatch({
                                    type: "SET_FILTER",
                                    payload: {
                                      key: col.accessor,
                                      value: e.target.value,
                                    },
                                  })
                                }
                                className="w-full text-xs border rounded px-2 py-1"
                                placeholder="Filter"
                              />
                            )}
                          </th>
                        ))}
                    </tr>
                  </thead>
                  <tbody>
                    {paginatedData.map((row) => {
                      const rowId = getRowKey(row);
                      const rowSelectable = isRowSelectable(row);

                      return (
                        <tr
                          key={rowId}
                          className={`${selectedRows.has(rowId)
                              ? "bg-emerald-100 hover:bg-emerald-100"
                              : "hover:bg-gray-200"
                            }`}
                        >
                          {selectable && (
                            <td className="p-2 border text-center sticky left-0 bg-blue-300">
                              <input
                                type="checkbox"
                                disabled={!rowSelectable}
                                title={rowSelectable ? "Click to Check/Uncheck" : "Row is not selectable"}
                                className={`w-5 h-5 align-middle ${rowSelectable ? "hover:cursor-pointer" : "cursor-not-allowed"}`}
                                checked={selectedRows.has(rowId)}
                                onChange={() => rowSelectable && handleSelectRow(row)}
                              />
                            </td>
                          )}
                          {columns
                            .filter((c) => visibleColumns.has(c.accessor))
                            .map((col) => (
                              <td
                                key={col.accessor}
                                className="p-2 border"
                                title={
                                  col.cellRender
                                    ? col.cellRender(row[col.accessor], row)
                                    : row[col.accessor]
                                }
                                style={{
                                  ...col.rowStyle,
                                  ...(col.cellStyle ? col.cellStyle(row[col.accessor], row) : {}),
                                }}
                              >
                                {col.cellRender
                                  ? col.cellRender(row[col.accessor], row)
                                  : row[col.accessor]}
                              </td>
                            ))}
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
              <div className="flex flex-col sm:flex-row justify-between items-center mt-4 gap-4">
                <div className="flex items-center gap-2">
                  <span>Rows per page:</span>
                  <input
                    type="number"
                    className="border rounded px-2 py-1 w-20"
                    value={state.rowsPerPage}
                    onChange={(e) => {
                      const value = Math.max(1, parseInt(e.target.value) || 10);
                      dispatch({ type: "SET_ROWS_PER_PAGE", payload: value });
                    }}
                  />
                </div>
                {selectable && selectionFilter == "all" && (
                  <div className="text-sm text-gray-600">
                    Selected {selectedCount} of {tableData.length}{" "}
                    records
                  </div>
                )}
                <div className="text-sm text-gray-600">
                  Showing {paginatedData.length} of {tableData.length}{" "}
                  records
                </div>
                <div className="flex items-center gap-1 flex-wrap">
                  <button
                    onClick={() =>
                      dispatch({
                        type: "SET_CURRENT_PAGE",
                        payload: Math.max(1, state.currentPage - 1),
                      })
                    }
                    disabled={state.currentPage === 1}
                    className="px-3 py-1 rounded border bg-gray-200 disabled:opacity-50 hover:cursor-pointer"
                  >
                    Prev
                  </button>
                  {getPaginationNumbers().map((page, idx) =>
                    typeof page === "number" ? (
                      <button
                        key={idx}
                        onClick={() =>
                          dispatch({ type: "SET_CURRENT_PAGE", payload: page })
                        }
                        className={`px-3 py-1 rounded border hover:cursor-pointer ${state.currentPage === page
                            ? "bg-blue-600 text-white"
                            : "bg-white text-blue-600"
                          }`}
                      >
                        {page}
                      </button>
                    ) : (
                      <span key={idx} className="px-2">
                        ...
                      </span>
                    )
                  )}

                  <button
                    onClick={() =>
                      dispatch({
                        type: "SET_CURRENT_PAGE",
                        payload: Math.min(totalPages, state.currentPage + 1),
                      })
                    }
                    disabled={state.currentPage === totalPages}
                    className="px-3 py-1 rounded border bg-gray-200 disabled:opacity-50 hover:cursor-pointer"
                  >
                    Next
                  </button>
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  );
};

export default DynamicTableData;
