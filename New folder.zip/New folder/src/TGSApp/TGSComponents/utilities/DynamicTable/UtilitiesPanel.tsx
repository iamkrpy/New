import React from "react";
import { motion, AnimatePresence } from "framer-motion";
import { ColumnsIcon, ExportIcon } from "../icons";

const UtilitiesPanel = ({
  state,
  dispatch,
  columns,
  exportRef,
  columnBoxRef,
  handleExport
}) => {
  return (
    <div className="flex items-center gap-2 mt-4 justify-between">
      <div className="relative" ref={columnBoxRef}>
        <button
          onClick={() => dispatch({ type: "TOGGLE_COLUMN_BOX" })}
          className="bg-gray-200 hover:bg-gray-300 border border-gray-500 rounded-xl px-2 py-1"
        >
          <ColumnsIcon /> Columns
        </button>

        <AnimatePresence>
          {state.columnBoxVisible && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              transition={{ duration: 0.2 }}
              className="absolute z-10 top-full mt-2 left-0 bg-white border border-gray-300 rounded shadow-md p-2 grid grid-cols-2 gap-2 max-h-60 overflow-y-auto"
            >
              {columns.map((column, index) => (
                <label key={index} className="inline-flex items-center">
                  <input
                    type="checkbox"
                    checked={column.visible}
                    onChange={() =>
                      dispatch({ type: "TOGGLE_COLUMN_VISIBILITY", payload: column.key })
                    }
                    className="mr-2"
                  />
                  {column.label}
                </label>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      <div className="relative" ref={exportRef}>
        <button
          onClick={handleExport}
          className="bg-gray-200 hover:bg-gray-300 border border-gray-500 rounded-xl px-2 py-1"
        >
          <ExportIcon /> Export
        </button>
      </div>
    </div>
  );
};

export default UtilitiesPanel;