import React from "react";

const TableWrapper = ({
  columns,
  paginatedData,
  visibleColumns,
  getRowKey,
  selectable,
  selectedRows,
  dispatch,
  filters,
  sortConfig,
  state,
  toggleSort,
  shouldScroll,
  hasGroupHeaders,
  groupedHeaders,
  selectAllRef,
  isRowSelectable
}) => {
  return (
    <div
      className="max-h-[60vh] overflow-y-auto border border-gray-200 rounded-xl shadow-sm mt-4"
      ref={shouldScroll ? state.scrollRef : null}
    >
      <table className="min-w-full divide-y divide-gray-200 table-auto">
        <thead className="bg-gray-100 sticky top-0 z-10">
          {hasGroupHeaders && (
            <tr>
              {selectable && <th className="px-4 py-2"></th>}
              {groupedHeaders.map((group, index) => (
                <th
                  key={index}
                  colSpan={group.colSpan}
                  className="px-4 py-2 text-left text-sm font-semibold text-gray-700 border-b border-gray-300"
                >
                  {group.label}
                </th>
              ))}
            </tr>
          )}
          <tr>
            {selectable && (
              <th className="px-4 py-2 text-left">
                <input
                  type="checkbox"
                  ref={selectAllRef}
                  onChange={(e) => dispatch({ type: "TOGGLE_SELECT_ALL", payload: e.target.checked })}
                />
              </th>
            )}
            {columns.map((column, index) => (
              column.visible && (
                <th
                  key={index}
                  className="px-4 py-2 text-left text-sm font-medium text-gray-700 cursor-pointer select-none"
                  onClick={() => toggleSort(column.key)}
                >
                  {column.label}
                  {sortConfig.key === column.key && (
                    <span className="ml-1 text-xs">
                      {sortConfig.direction === "asc" ? "▲" : "▼"}
                    </span>
                  )}
                </th>
              )
            ))}
          </tr>
          <tr>
            {selectable && <th className="px-4 py-2"></th>}
            {columns.map((column, index) => (
              column.visible ? (
                <th key={index} className="px-4 py-1">
                  {column.filterable ? (
                    <input
                      type="text"
                      value={filters[column.key] || ""}
                      onChange={(e) =>
                        dispatch({
                          type: "SET_FILTER",
                          payload: { key: column.key, value: e.target.value },
                        })
                      }
                      className="w-full px-2 py-1 border rounded"
                    />
                  ) : null}
                </th>
              ) : null
            ))}
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {paginatedData.map((row, rowIndex) => {
            const rowKey = getRowKey(row);
            return (
              <tr key={rowKey} className="hover:bg-gray-50">
                {selectable && (
                  <td className="px-4 py-2">
                    <input
                      type="checkbox"
                      checked={selectedRows.includes(rowKey)}
                      onChange={() => dispatch({ type: "TOGGLE_SELECT_ROW", payload: rowKey })}
                      disabled={isRowSelectable && !isRowSelectable(row)}
                    />
                  </td>
                )}
                {columns.map((column, colIndex) => (
                  column.visible && (
                    <td key={colIndex} className="px-4 py-2 text-sm text-gray-800">
                      {column.render ? column.render(row[column.key], row) : row[column.key]}
                    </td>
                  )
                ))}
              </tr>
            );
          })}
        </tbody>
      </table>
    </div>
  );
};

export default TableWrapper;