import React from "react";

const PaginationControls = ({
  currentPage,
  totalPages,
  dispatch
}) => {
  const handlePrevious = () => {
    if (currentPage > 1) {
      dispatch({ type: "SET_PAGE", payload: currentPage - 1 });
    }
  };

  const handleNext = () => {
    if (currentPage < totalPages) {
      dispatch({ type: "SET_PAGE", payload: currentPage + 1 });
    }
  };

  return (
    <div className="flex justify-between items-center mt-4">
      <button
        onClick={handlePrevious}
        disabled={currentPage === 1}
        className="px-4 py-2 bg-gray-200 hover:bg-gray-300 border border-gray-400 rounded disabled:opacity-50"
      >
        Previous
      </button>

      <span className="text-sm text-gray-700">
        Page {currentPage} of {totalPages}
      </span>

      <button
        onClick={handleNext}
        disabled={currentPage === totalPages}
        className="px-4 py-2 bg-gray-200 hover:bg-gray-300 border border-gray-400 rounded disabled:opacity-50"
      >
        Next
      </button>
    </div>
  );
};

export default PaginationControls;