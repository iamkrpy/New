interface TableColumnsConfig {
    Header: string;
    accessor: string;
    parentHeader?: string;
    filter?: boolean;
    editable?:boolean;
    headerStyle?: React.CSSProperties;
    rowStyle?: React.CSSProperties;
    cellStyle?: (value: any, row: any) => React.CSSProperties;
    cellRender?: (value: any, row: any) => React.ReactNode;
  }
type TableState = {
    search: string;
    filters: Record<string, string>;
    selectionFilter: "all" | "selected" | "unselected";
    currentPage: number;
    rowsPerPage: number;
    selectedRows: Set<string>;
    visibleColumns: Set<string>;
    sortConfig: { key: string; direction: "asc" | "desc" } | null;
    showUtilities: boolean;
    showColumnSelector: boolean;
    expanded: boolean;
  };
  
  type Action =
    | { type: "SET_SEARCH"; payload: string }
    | { type: "SET_FILTER"; payload: { key: string; value: string } }
    | { type: "SET_SELECTION_FILTER"; payload: "all" | "selected" | "unselected" }
    | { type: "SET_CURRENT_PAGE"; payload: number }
    | { type: "SET_ROWS_PER_PAGE"; payload: number }
    | { type: "TOGGLE_SELECT_ROW"; payload: string }
    | { type: "SELECT_ALL_ROWS"; payload: string[] }
    | { type: "DESELECT_ALL_ROWS"; payload: string[] }
    | { type: "RESET_SELECTION" }
    | { type: "TOGGLE_COLUMN"; payload: string }
    | { type: "SET_VISIBLE_COLUMNS"; payload: Set<string> }
    | { type: "TOGGLE_SORT"; payload: string }
    | { type: "TOGGLE_UTILITIES" }
    | { type: "TOGGLE_COLUMN_SELECTOR" }
    | { type: "TOGGLE_EXPANDED" }
    | { type: "RESET_ALL"; payload: Set<string> }
    | { type: "SET_COLUMN_SELECTOR"; payload: boolean }
    | { type: "SET_UTILITIES"; payload: boolean };
  
  const initialState = (columns: TableColumnsConfig[]): TableState => ({
    search: "",
    filters: {},
    selectionFilter: "all",
    currentPage: 1,
    rowsPerPage: 10,
    selectedRows: new Set(),
    visibleColumns: new Set(columns.map((c) => c.accessor)),
    sortConfig: null,
    showUtilities: false,
    showColumnSelector: false,
    expanded: true,
  });
  
  const reducer = (state: TableState, action: Action): TableState => {
    switch (action.type) {
      case "SET_SEARCH":
        return { ...state, search: action.payload, currentPage: 1 };
      case "SET_FILTER":
        return {
          ...state,
          filters: {
            ...state.filters,
            [action.payload.key]: action.payload.value,
          },
          currentPage: 1,
        };
      case "SET_SELECTION_FILTER":
        return { ...state, selectionFilter: action.payload, currentPage: 1 };
      case "SET_CURRENT_PAGE":
        return { ...state, currentPage: action.payload };
      case "SET_ROWS_PER_PAGE":
        return { ...state, rowsPerPage: action.payload, currentPage: 1 };
      case "TOGGLE_SELECT_ROW": {
        const selected = new Set(state.selectedRows);
        selected.has(action.payload)
          ? selected.delete(action.payload)
          : selected.add(action.payload);
        return { ...state, selectedRows: selected };
      }
      case "SELECT_ALL_ROWS": {
        const selected = new Set(state.selectedRows);
        action.payload.forEach((k) => selected.add(k));
        return { ...state, selectedRows: selected };
      }
      case "DESELECT_ALL_ROWS": {
        const selected = new Set(state.selectedRows);
        action.payload.forEach((k) => selected.delete(k));
        return { ...state, selectedRows: selected };
      }
      case "RESET_SELECTION":
        return { ...state, selectedRows: new Set() };
      case "TOGGLE_COLUMN": {
        const visible = new Set(state.visibleColumns);
        if (visible.has(action.payload)) {
          if (visible.size > 1) visible.delete(action.payload);
        } else {
          visible.add(action.payload);
        }
        return { ...state, visibleColumns: visible };
      }
      case "SET_VISIBLE_COLUMNS":
        return { ...state, visibleColumns: action.payload };
      case "TOGGLE_SORT": {
        const { sortConfig } = state;
        if (!sortConfig || sortConfig.key !== action.payload) {
          return {
            ...state,
            sortConfig: { key: action.payload, direction: "asc" },
          };
        } else if (sortConfig.direction === "asc") {
          return {
            ...state,
            sortConfig: { key: action.payload, direction: "desc" },
          };
        } else {
          return { ...state, sortConfig: null };
        }
      }
      case "TOGGLE_UTILITIES":
        return { ...state, showUtilities: !state.showUtilities };
      case "SET_UTILITIES":
        return { ...state, showUtilities: action.payload };
      case "TOGGLE_COLUMN_SELECTOR":
        return { ...state, showColumnSelector: !state.showColumnSelector };
      case "SET_COLUMN_SELECTOR":
        return { ...state, showColumnSelector: action.payload };
      case "TOGGLE_EXPANDED":
        return { ...state, expanded: !state.expanded };
      case "RESET_ALL":
        return {
          ...initialState([]),
          visibleColumns: action.payload,
          expanded: true,
        };
      default:
        return state;
    }
  };
  
  export { initialState, reducer };