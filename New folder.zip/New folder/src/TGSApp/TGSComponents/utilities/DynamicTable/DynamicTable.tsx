// This assumes you've already extracted the subcomponents
import React, { useReducer, useRef, useEffect, useMemo } from "react";
import HeaderBar from "./HeaderBar";
import UtilitiesPanel from "./UtilitiesPanel";
import TableWrapper from "./TableWrapper";
import PaginationControls from "./PaginationControls";
// import BulkEditModal from "./BulkEditModal";
// import UploadModal from "./UploadModal";

import { initialState, reducer } from "./TableReducer";

const DynamicTableData = ({
  columns,
  data,
  selectable,
  collapsable,
  getRowKey,
  handleDelete,
  handleEditSelectedRows,
  editModalOpen,
  setEditModalOpen,
  setIsUploadModalOpen,
  handleExport,
  isRowSelectable
}) => {
  const [state, dispatch] = useReducer(reducer,columns, initialState);

  const exportRef = useRef(null);
  const columnBoxRef = useRef(null);
  const selectAllRef = useRef(null);

  const visibleColumns = useMemo(() => columns.filter((col) => col.visible), [columns]);

  const filteredData = useMemo(() => {
    return data.filter((row) =>
      columns.every((col) => {
        if (!col.filterable || !state.filters[col.key]) return true;
        return String(row[col.key])
          .toLowerCase()
          .includes(state.filters[col.key].toLowerCase());
      })
    );
  }, [data, columns, state.filters]);

  const sortedData = useMemo(() => {
    if (!sortConfig) return filteredData;
    return [...filteredData].sort((a, b) => {
        const aVal = a[sortConfig.key];
        const bVal = b[sortConfig.key];
      if (aVal < bVal) return sortConfig.direction === "asc" ? -1 : 1;
      if (aVal > bVal) return sortConfig.direction === "asc" ? 1 : -1;
      return 0;
    });
  }, [filteredData, state.sortConfig]);
  const sortedData = useMemo(() => {
    if (!sortConfig) return filteredData;
    return [...filteredData].sort((a, b) => {
      const valA = a[sortConfig.key];
      const valB = b[sortConfig.key];
      return valA < valB
        ? sortConfig.direction === "asc"
          ? -1
          : 1
        : valA > valB
        ? sortConfig.direction === "asc"
          ? 1
          : -1
        : 0;
    });
  }, [filteredData, sortConfig]);

  const paginatedData = useMemo(() => {
    return sortedData.slice(
      (state.currentPage - 1) * state.rowsPerPage,
      state.currentPage * state.rowsPerPage
    );
  }, [sortedData, state.currentPage, state.rowsPerPage]);

  const totalPages = useMemo(() => {
    return Math.ceil(sortedData.length / state.rowsPerPage);
  }, [sortedData.length, state.rowsPerPage]);

  const hasGroupHeaders = useMemo(() => columns.some((col) => col.group), [columns]);

  const groupedHeaders = useMemo(() => {
    if (!hasGroupHeaders) return [];

    const headers = [];
    let currentGroup = null;

    for (const col of visibleColumns) {
      if (!col.group) continue;
      if (!currentGroup || currentGroup.label !== col.group) {
        currentGroup = { label: col.group, colSpan: 1 };
        headers.push(currentGroup);
      } else {
        currentGroup.colSpan++;
      }
    }

    return headers;
  }, [visibleColumns, hasGroupHeaders]);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (
        state.columnBoxVisible &&
        columnBoxRef.current &&
        !columnBoxRef.current.contains(e.target)
      ) {
        dispatch({ type: "HIDE_COLUMN_BOX" });
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [state.columnBoxVisible]);

  const toggleSort = (key) => {
    if (state.sortConfig.key === key) {
      dispatch({
        type: "SET_SORT",
        payload: {
          key,
          direction: state.sortConfig.direction === "asc" ? "desc" : "asc"
        }
      });
    } else {
      dispatch({ type: "SET_SORT", payload: { key, direction: "asc" } });
    }
  };

  return (
    <div>
      <HeaderBar
        state={state}
        dispatch={dispatch}
        collapsable={collapsable}
        selectable={selectable}
        handleDelete={handleDelete}
        handleEditSelectedRows={handleEditSelectedRows}
        editModalOpen={editModalOpen}
        setEditModalOpen={setEditModalOpen}
        search={state.search}
        setSearch={(value) => dispatch({ type: "SET_SEARCH", payload: value })}
        selectedRows={state.selectedRows}
        setIsUploadModalOpen={setIsUploadModalOpen}
      />

      <UtilitiesPanel
        state={state}
        dispatch={dispatch}
        columns={columns}
        exportRef={exportRef}
        columnBoxRef={columnBoxRef}
        handleExport={handleExport}
      />

      <TableWrapper
        columns={columns}
        paginatedData={paginatedData}
        visibleColumns={visibleColumns}
        getRowKey={getRowKey}
        selectable={selectable}
        selectedRows={state.selectedRows}
        dispatch={dispatch}
        filters={state.filters}
        sortConfig={state.sortConfig}
        state={state}
        toggleSort={toggleSort}
        shouldScroll={true}
        hasGroupHeaders={hasGroupHeaders}
        groupedHeaders={groupedHeaders}
        selectAllRef={selectAllRef}
        isRowSelectable={isRowSelectable}
      />

      <PaginationControls
        currentPage={state.currentPage}
        totalPages={totalPages}
        dispatch={dispatch}
      />

      {/* <BulkEditModal
        open={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        selectedRows={state.selectedRows}
      />

      <UploadModal onClose={() => setIsUploadModalOpen(false)} /> */}
    </div>
  );
};

export default DynamicTableData;