import React from "react";
import {
  ExpandIcon,
  CollapseIcon,
  DeleteIcon,
  RefreshIcon,
  SearchIcon,
  ColumnsIcon,
  ExportIcon,
  PointerIcon,
  EditIcon,
} from "../icons";

const HeaderBar = ({
  state,
  dispatch,
  collapsable,
  selectable,
  handleDelete,
  handleEditSelectedRows,
  editModalOpen,
  setEditModalOpen,
  search,
  setSearch,
  selectedRows,
  setIsUploadModalOpen
}) => {
  return (
    <div className="bg-white border-2 border-lime-400 flex justify-between w-full p-3 rounded-2xl">
      <div className="flex items-center gap-2">
        {collapsable && (
          <button
            onClick={() => dispatch({ type: "TOGGLE_COLLAPSE" })}
            className="bg-lime-200 border border-lime-500 hover:bg-lime-300 rounded-xl px-2 py-1"
          >
            {state.collapsed ? <ExpandIcon /> : <CollapseIcon />}
          </button>
        )}

        {selectable && (
          <>
            <button
              onClick={handleDelete}
              className="bg-red-200 hover:bg-red-300 border border-red-500 rounded-xl px-2 py-1"
            >
              <DeleteIcon /> Delete
            </button>
            <button
              onClick={() => setIsUploadModalOpen(true)}
              className="bg-blue-200 hover:bg-blue-300 border border-blue-500 rounded-xl px-2 py-1"
            >
              <PointerIcon /> Upload
            </button>
            <button
              onClick={() => setEditModalOpen(true)}
              className="bg-yellow-200 hover:bg-yellow-300 border border-yellow-500 rounded-xl px-2 py-1"
            >
              <EditIcon /> Edit
            </button>
          </>
        )}
      </div>

      <div className="flex items-center gap-2">
        <button
          onClick={() => dispatch({ type: "REFRESH" })}
          className="bg-gray-200 hover:bg-gray-300 border border-gray-500 rounded-xl px-2 py-1"
        >
          <RefreshIcon />
        </button>

        <div className="relative">
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search..."
            className="pl-8 pr-2 py-1 border border-gray-300 rounded-xl w-64"
          />
          <div className="absolute left-2 top-1.5">
            <SearchIcon />
          </div>
        </div>
      </div>
    </div>
  );
};

export default HeaderBar;
