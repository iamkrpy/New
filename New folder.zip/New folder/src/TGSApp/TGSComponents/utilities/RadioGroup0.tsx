import React, { useEffect, useState } from "react";

interface Option {
  label: string;
  value: string;
}

interface RadioGroupProps {
  label: string;
  dataSourceUrl?: string;
  options?: Option[];
  selected: string;
  onChange: (value: string) => void;
  required?: boolean;
  onError?: (hasError: boolean) => void;
}

const RadioGroup: React.FC<RadioGroupProps> = ({
  label,
  dataSourceUrl,
  options = [],
  selected,
  onChange,
  required = false,
}) => {
  const [internalOptions, setInternalOptions] = useState<Option[]>([]);
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (dataSourceUrl) {
      fetch(dataSourceUrl)
        .then((res) => res.json())
        .then((data) =>
          setInternalOptions(
            data.map((item: any) => ({
              label: item.label ?? item.name ?? item.value,
              value: item.value ?? item.id ?? item.code,
            }))
          )
        )
        .catch((err) => {
          console.error("Radio data load error:", err);
        });
    } else {
      setInternalOptions(options);
    }
  }, [dataSourceUrl, options]);

  useEffect(() => {
    if (!touched) return;
    if (required && !selected) {
      setError("Please select an option.");
    } else {
      setError(null);
    }
  }, [selected, required, touched]);

  return (
    <div>
      <label className="font-medium text-sm block mb-1">{label}</label>
      <div className="space-y-2">
        {internalOptions.map((opt) => (
          <label key={opt.value} className="flex items-center space-x-2">
            <input
              type="radio"
              value={opt.value}
              checked={selected === opt.value}
              onChange={() => {
                onChange(opt.value);
                setTouched(true);
              }}
              className="accent-blue-600"
            />
            <span>{opt.label}</span>
          </label>
        ))}
      </div>
      {error && <p className="text-xs text-red-600 mt-1">{error}</p>}
    </div>
  );
};

export default RadioGroup;
