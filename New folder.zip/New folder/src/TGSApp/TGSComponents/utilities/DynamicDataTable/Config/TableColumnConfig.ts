export interface TableColumnsConfig {
    Header: string;
    accessor: string;
    parentHeader?: string;
    filter?: boolean;
    editable?: boolean;
    headerStyle?: React.CSSProperties;
    rowStyle?: React.CSSProperties;
    cellStyle?: (value: any, row: any) => React.CSSProperties;
    cellRender?: (value: any, row: any) => React.ReactNode;
  }
  