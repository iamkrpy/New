export type SortConfig = {
    key: string;
    direction: "asc" | "desc";
  };