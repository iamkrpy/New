export interface BulkEditColumnsConfig {
    Header: string;
    accessor: string;
    editable?: boolean;
    required?: boolean;
    type?: "string" | "number" | "date";
    allowedValues?: string[];
    maxLength?: number;
    format?: RegExp;
  }