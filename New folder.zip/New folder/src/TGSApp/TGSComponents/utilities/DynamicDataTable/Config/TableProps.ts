import type { TableColumnsConfig } from "./TableColumnConfig";
import type { EditColumnsConfig } from "./EditColumnsConfig";
import type { BulkEditColumnsConfig } from "./BulkEditColumnConfig";

export interface TableProps {
  columns: TableColumnsConfig[];
  data: any[];
  commonHeader?: string;
  editable?: boolean;
  selectable?: boolean;
  visibleColumnCount?: number;
  collapsable?: boolean;
  uniqueKeys?: string[];
  editColumnsConfig?: EditColumnsConfig[];
  onSave: (updatedRows: any[]) => void;
  isRowSelectable?: (row: any) => boolean;
  BulkUpdatePayloadMapper?: (row: any) => any;
  BulkUpdateEditColumnConfig?: BulkEditColumnsConfig[];
  apiURL?: string;
}
