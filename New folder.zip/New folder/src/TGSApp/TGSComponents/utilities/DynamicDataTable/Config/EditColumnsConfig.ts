export interface EditColumnsConfig {
    accessor: string;
    label: string;
    type: string;
    labelkey?: string;
    dataSourceUrl?: string;
    selectionMode?: "single" | "multiple";
    options?: { label: string; value: string }[];
    placeholder?: string;
    required?: boolean;
    editable?: boolean;
  }
  