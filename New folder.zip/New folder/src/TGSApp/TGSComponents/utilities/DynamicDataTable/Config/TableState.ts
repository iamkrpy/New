import type { SortConfig } from "./SortConfig";

export type TableState = {
    search: string;
    filters: Record<string, string>;
    selectionFilter: "all" | "selected" | "unselected";
    currentPage: number;
    rowsPerPage: number;
    selectedRows: Set<string>;
    visibleColumns: Set<string>;
    sortConfig: SortConfig | null;
    showUtilities: boolean;
    showColumnSelector: boolean;
    expanded: boolean;
  };