import React, { useRef, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import {
  SearchIcon,
  ColumnsIcon,
  ExportIcon,
} from "../../../../MainApp/MainAppUtilities/icons";

interface ToolbarProps {
  expanded: boolean;
  collapsable: boolean;
  selectable: boolean;
  selectedCount: number;
  onDelete: () => void;
  onEdit: () => void;
  editModalOpen: boolean;
  setEditModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
  rowsToEdit: any[];
  editColumnsConfig: any[];
  onSave: (updatedRows: any[], type?: string) => void;
  onUploadOpen: () => void;
  BulkUpdateEditColumnConfig?: any[];
  apiURL?: string;
  BulkUpdatePayloadMapper?: (row: any) => any;
  onRefresh: () => void;
  state: any;
  dispatch: React.Dispatch<any>;
  PointerIcon: React.FC<any>;
  ExpandIcon: React.FC<any>;
  CollapseIcon: React.FC<any>;
  DeleteIcon: React.FC<any>;
  EditIcon: React.FC<any>;
  RefreshIcon: React.FC<any>;
  BulkUpdateModalComponent?: React.FC<{
    open: boolean;
    onClose: () => void;
    rowsToEdit: any[];
    editColumnsConfig: any[];
    apiURL?: string;
    BulkUpdatePayloadMapper?: (row: any) => any;
    onSave: (updatedRows: any[]) => void;
  }>;
  bulkUpdateModalOpen: boolean;
  setBulkUpdateModalOpen: React.Dispatch<React.SetStateAction<boolean>>;
}

const Toolbar: React.FC<ToolbarProps> = ({
  expanded,
  collapsable,
  selectable,
  selectedCount,
  onDelete,
  onEdit,
  editModalOpen,
  setEditModalOpen,
  rowsToEdit,
  editColumnsConfig,
  onSave,
  onUploadOpen,
  BulkUpdateEditColumnConfig,
  apiURL,
  BulkUpdatePayloadMapper,
  onRefresh,
  state,
  dispatch,
  PointerIcon,
  ExpandIcon,
  CollapseIcon,
  DeleteIcon,
  EditIcon,
  RefreshIcon,
  BulkUpdateModalComponent,
  bulkUpdateModalOpen,
  setBulkUpdateModalOpen,
}) => {
  const columnBoxRef = useRef<HTMLDivElement>(null);
  const exportRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (
        columnBoxRef.current &&
        !columnBoxRef.current.contains(event.target as Node)
      ) {
        dispatch({ type: "SET_COLUMN_SELECTOR", payload: false });
      }
      if (
        exportRef.current &&
        !exportRef.current.contains(event.target as Node)
      ) {
        dispatch({ type: "SET_UTILITIES", payload: false });
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, [dispatch]);

  return (
    <div className="bg-white border-2 border-lime-400 flex justify-between w-full p-3 rounded-2xl">
      <div className="flex gap-2 items-center ">
        {!expanded && (
          <span className="font-bold text-yellow-700 p-2 h-15 flex items-center text-2xl">
            <span className="p-2">Table is in Collapsed state. Click to expand</span>
            <PointerIcon fill="#cc1e1e" />
          </span>
        )}

        {collapsable && (
          <button
            onClick={() => dispatch({ type: "TOGGLE_EXPANDED" })}
            className="w-15 h-10 hover:cursor-pointer"
            title="Expand/Collapse"
          >
            {expanded ? <CollapseIcon /> : <ExpandIcon />}
          </button>
        )}

        {selectable && expanded && selectedCount > 0 && (
          <button
            onClick={onDelete}
            title="Delete Selected"
            className="w-15 h-10 hover:bg-red-300 hover:cursor-pointer rounded-2xl"
          >
            <DeleteIcon />
          </button>
        )}
        {selectable && expanded && selectedCount > 0 && (
          <>
            <button
              className="w-15 h-10 hover:bg-emerald-100 rounded-2xl hover:cursor-pointer"
              title="Edit Selected Rows"
              onClick={onEdit}
            >
              <EditIcon />
            </button>
          </>
        )}
        {selectable && expanded && BulkUpdateEditColumnConfig && selectedCount > 0 && (
          <button
            onClick={() => setBulkUpdateModalOpen(true)}
            className="w-15 h-10 hover:bg-blue-300 rounded-2xl hover:cursor-pointer"
            title="Bulk Update Selected"
          >
            Bulk Update
          </button>
        )}

        {selectable && expanded && (
          <>
            <button
              onClick={onUploadOpen}
              className="px-4 py-2 bg-indigo-600 text-white rounded hover:bg-indigo-700"
            >
              📤 Upload Excel
            </button>
          </>
        )}

        {expanded && (
          <button
            onClick={onRefresh}
            title="Refresh"
            className="w-15 h-10 hover:bg-yellow-300 hover:cursor-pointer rounded-2xl"
          >
            <RefreshIcon />
          </button>
        )}
      </div>

      {expanded && (
        <div className="mx-auto">
          <div className="flex items-center align-middle gap-2 text-md text-gray-700">
            {/* You can add filter status indicators here if needed */}
          </div>
        </div>
      )}

      {expanded && (
        <div className="flex items-center gap-3 ml-auto relative">
          <div className="flex items-center gap-0.5 border rounded">
            <label className="w-10 h-10">
              <SearchIcon fill="#d97c54" />
            </label>
            <input
              type="text"
              title="Search in Table"
              value={state.search}
              onChange={(e) =>
                dispatch({ type: "SET_SEARCH", payload: e.target.value })
              }
              placeholder="Table Search"
              className="px-3 w-48 h-10 border-0 focus:outline-0"
            />
          </div>
          <div className="relative" ref={columnBoxRef}>
            <button
              onClick={() => dispatch({ type: "TOGGLE_COLUMN_SELECTOR" })}
              title="Column Visibility"
              className="w-10 h-8 hover:bg-blue-100 hover:cursor-pointer align-middle"
            >
              <ColumnsIcon fill1="#7DD2F0" fill2="#78C9E6" />
            </button>
            {state.showColumnSelector && (
              <div className="absolute right-0 z-20 mt-1 w-64 max-h-60 overflow-y-auto border bg-white p-2 shadow rounded">
                {/* Assuming columns is part of state or passed down */}
                <label className="block mb-2">
                  <input
                    type="checkbox"
                    className="hover:cursor-pointer"
                    checked={state.visibleColumns.size === state.columns.length}
                    onChange={(e) =>
                      dispatch({
                        type: "SET_VISIBLE_COLUMNS",
                        payload: e.target.checked
                          ? new Set(state.columns.map((c: any) => c.accessor))
                          : new Set([state.columns[0].accessor]),
                      })
                    }
                  />{" "}
                  Select All
                </label>
                {state.columns.map((col: any) => (
                  <label key={col.accessor} className="block text-sm">
                    <input
                      type="checkbox"
                      className="hover:cursor-pointer"
                      checked={state.visibleColumns.has(col.accessor)}
                      onChange={() =>
                        dispatch({
                          type: "TOGGLE_COLUMN",
                          payload: col.accessor,
                        })
                      }
                      disabled={
                        state.visibleColumns.size === 1 &&
                        state.visibleColumns.has(col.accessor)
                      }
                    />{" "}
                    {col.Header}
                  </label>
                ))}
              </div>
            )}
          </div>
          <div className="relative" ref={exportRef}>
            <button
              onClick={() => dispatch({ type: "TOGGLE_UTILITIES" })}
              title="Utilities"
              className="w-15 h-8 flex align-middle items-center hover:cursor-pointer"
            >
              <ExportIcon stroke2="#054217" stroke1="#4acb3a" />
              <span>{state.showUtilities ? "▲" : "▼"}</span>
            </button>

            <AnimatePresence>
              {state.showUtilities && (
                <motion.div
                  initial={{ opacity: 0, y: -8 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -8 }}
                  transition={{ duration: 0.2 }}
                  className="absolute right-0 mt-2 w-56 bg-white border rounded shadow-lg z-40 p-2 flex flex-col gap-2"
                >
                  <button
                    onClick={() => onSave([], "csv")}
                    className="w-full text-left px-3 py-1 hover:bg-gray-100 rounded"
                  >
                    Export CSV
                  </button>
                  <button
                    onClick={() => onSave([], "excel")}
                    className="w-full text-left px-3 py-1 hover:bg-gray-100 rounded"
                  >
                    Export Excel
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      )}

      {/* Edit Modal call */}
      <AnimatePresence>
        {editModalOpen && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 20 }}
            transition={{ duration: 0.3 }}
          >
            {/* Replace with your actual EditModal component */}
            {/* Example: */}
            {/* <EditModal
              open={editModalOpen}
              onClose={() => setEditModalOpen(false)}
              rowsToEdit={rowsToEdit}
              editColumnsConfig={editColumnsConfig}
              onSave={onSave}
            /> */}
            {/* Placeholder */}
            <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <div className="bg-white p-4 rounded shadow-lg max-w-lg w-full">
                <h2 className="text-lg font-bold mb-4">Edit Modal Placeholder</h2>
                <button
                  onClick={() => setEditModalOpen(false)}
                  className="mt-4 px-4 py-2 bg-blue-500 text-white rounded"
                >
                  Close
                </button>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>

      {/* Bulk Update Modal call */}
      <AnimatePresence>
        {bulkUpdateModalOpen && BulkUpdateModalComponent && (
          <BulkUpdateModalComponent
            open={bulkUpdateModalOpen}
            onClose={() => setBulkUpdateModalOpen(false)}
            rowsToEdit={rowsToEdit} // or selected rows data
            editColumnsConfig={BulkUpdateEditColumnConfig || []}
            apiURL={apiURL}
            BulkUpdatePayloadMapper={BulkUpdatePayloadMapper}
            onSave={(updatedRows) => {
              // You can call your API or handle save here or inside modal
              setBulkUpdateModalOpen(false);
              onRefresh();
            }}
          />
        )}
      </AnimatePresence>
    </div>
  );
};

export default Toolbar;
