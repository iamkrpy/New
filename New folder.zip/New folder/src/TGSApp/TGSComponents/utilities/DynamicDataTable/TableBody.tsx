import React from "react";
import { type TableColumnsConfig } from "./Config/TableColumnConfig";

interface TableBodyProps {
  paginatedData: any[];
  columns: TableColumnsConfig[];
  visibleColumns: Set<string>;
  selectable: boolean;
  selectedRows: Set<string>;
  isRowSelectable: (row: any) => boolean;
  handleSelectRow: (row: any) => void;
}

const TableBody: React.FC<TableBodyProps> = ({
  paginatedData,
  columns,
  visibleColumns,
  selectable,
  selectedRows,
  isRowSelectable,
  handleSelectRow,
}) => {
  const getRowKey = React.useCallback((row: any) => {
    // Since getRowKey is defined outside, pass as prop or recompute here if needed.
    // For now, assume it is passed down or accessible.
    return ""; // Implement properly in main or lift up the logic.
  }, []);

  return (
    <tbody>
      {paginatedData.map((row) => {
        const rowId = getRowKey(row);
        return (
          <tr
            key={rowId}
            className={`${
              selectedRows.has(rowId)
                ? "bg-emerald-100 hover:bg-emerald-100"
                : "hover:bg-gray-200"
            }`}
          >
            {selectable && (
              <td className="p-2 border text-center sticky left-0 bg-blue-300">
                <input
                  type="checkbox"
                  disabled={!isRowSelectable(row)}
                  title="Click to Check/Uncheck"
                  className="w-5 h-5 align-middle hover:cursor-pointer"
                  checked={selectedRows.has(rowId)}
                  onChange={() => handleSelectRow(row)}
                />
              </td>
            )}
            {columns
              .filter((c) => visibleColumns.has(c.accessor))
              .map((col) => (
                <td
                  key={col.accessor}
                  className={`p-2 border`}
                  title={
                    col.cellRender
                      ? col.cellRender(row[col.accessor], row)
                      : row[col.accessor]
                  }
                  style={{
                    ...col.rowStyle,
                    ...(col.cellStyle
                      ? col.cellStyle(row[col.accessor], row)
                      : {}),
                  }}
                >
                  {col.cellRender
                    ? col.cellRender(row[col.accessor], row)
                    : row[col.accessor]}
                </td>
              ))}
          </tr>
        );
      })}
    </tbody>
  );
};

export default TableBody;
