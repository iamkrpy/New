import React, { useMemo, useReducer, useRef, useEffect, useState } from "react";
import * as XLSX from "xlsx";
import { saveAs } from "file-saver";
import Papa from "papaparse";
import { motion, AnimatePresence } from "framer-motion";
import {type TableColumnsConfig } from "./Config/TableColumnConfig";
import {
  ExpandIcon,
  CollapseIcon,
  DeleteIcon,
  RefreshIcon,
  SearchIcon,
  ColumnsIcon,
  ExportIcon,
  PointerIcon,
  EditIcon,
} from "../../../../MainApp/MainAppUtilities/icons";

import TableHeader from "./TableHeader";
import TableBody from "./TableBody";
import TableFooter from "./TableFooter";
import Toolbar from "./Toolbar";
import type { TableState } from "./Config/TableState";
import type { TableProps } from "./Config/TableProps";
import EditRowModal from "../../Modals/EditRowModal15";
import UploadModal from "../../Modals/UploadModalBulk";


type Action =
  | { type: "SET_SEARCH"; payload: string }
  | { type: "SET_FILTER"; payload: { key: string; value: string } }
  | { type: "SET_SELECTION_FILTER"; payload: "all" | "selected" | "unselected" }
  | { type: "SET_CURRENT_PAGE"; payload: number }
  | { type: "SET_ROWS_PER_PAGE"; payload: number }
  | { type: "TOGGLE_SELECT_ROW"; payload: string }
  | { type: "SELECT_ALL_ROWS"; payload: string[] }
  | { type: "DESELECT_ALL_ROWS"; payload: string[] }
  | { type: "RESET_SELECTION" }
  | { type: "TOGGLE_COLUMN"; payload: string }
  | { type: "SET_VISIBLE_COLUMNS"; payload: Set<string> }
  | { type: "TOGGLE_SORT"; payload: string }
  | { type: "TOGGLE_UTILITIES" }
  | { type: "TOGGLE_COLUMN_SELECTOR" }
  | { type: "TOGGLE_EXPANDED" }
  | { type: "RESET_ALL"; payload: Set<string> }
  | { type: "SET_COLUMN_SELECTOR"; payload: boolean }
  | { type: "SET_UTILITIES"; payload: boolean };


const initialState = (columns: TableColumnsConfig[]): TableState => ({
  search: "",
  filters: {},
  selectionFilter: "all",
  currentPage: 1,
  rowsPerPage: 10,
  selectedRows: new Set(),
  visibleColumns: new Set(columns.map((c) => c.accessor)),
  sortConfig: null,
  showUtilities: false,
  showColumnSelector: false,
  expanded: true,
});

const reducer = (state: TableState, action: Action): TableState => {
    switch (action.type) {
      case "SET_SEARCH":
        return { ...state, search: action.payload, currentPage: 1 };
      case "SET_FILTER":
        return {
          ...state,
          filters: {
            ...state.filters,
            [action.payload.key]: action.payload.value,
          },
          currentPage: 1,
        };
      case "SET_SELECTION_FILTER":
        return { ...state, selectionFilter: action.payload, currentPage: 1 };
      case "SET_CURRENT_PAGE":
        return { ...state, currentPage: action.payload };
      case "SET_ROWS_PER_PAGE":
        return { ...state, rowsPerPage: action.payload, currentPage: 1 };
      case "TOGGLE_SELECT_ROW": {
        const selected = new Set(state.selectedRows);
        selected.has(action.payload)
          ? selected.delete(action.payload)
          : selected.add(action.payload);
        return { ...state, selectedRows: selected };
      }
      case "SELECT_ALL_ROWS": {
        const selected = new Set(state.selectedRows);
        action.payload.forEach((k: string) => selected.add(k));
        return { ...state, selectedRows: selected };
      }
      case "DESELECT_ALL_ROWS": {
        const selected = new Set(state.selectedRows);
        action.payload.forEach((k: string) => selected.delete(k));
        return { ...state, selectedRows: selected };
      }
      case "RESET_SELECTION":
        return { ...state, selectedRows: new Set() };
      case "TOGGLE_COLUMN": {
        const visible = new Set(state.visibleColumns);
        if (visible.has(action.payload)) {
          if (visible.size > 1) visible.delete(action.payload);
        } else {
          visible.add(action.payload);
        }
        return { ...state, visibleColumns: visible };
      }
      case "SET_VISIBLE_COLUMNS":
        return { ...state, visibleColumns: action.payload };
      case "TOGGLE_SORT": {
        const { sortConfig } = state;
        if (!sortConfig || sortConfig.key !== action.payload) {
          return {
            ...state,
            sortConfig: { key: action.payload, direction: "asc" },
          };
        } else if (sortConfig.direction === "asc") {
          return {
            ...state,
            sortConfig: { key: action.payload, direction: "desc" },
          };
        } else {
          return { ...state, sortConfig: null };
        }
      }
      case "TOGGLE_UTILITIES":
        return { ...state, showUtilities: !state.showUtilities };
      case "SET_UTILITIES":
        return { ...state, showUtilities: action.payload };
      case "TOGGLE_COLUMN_SELECTOR":
        return { ...state, showColumnSelector: !state.showColumnSelector };
      case "SET_COLUMN_SELECTOR":
        return { ...state, showColumnSelector: action.payload };
      case "TOGGLE_EXPANDED":
        return { ...state, expanded: !state.expanded };
      case "RESET_ALL":
        return {
          ...initialState([]),
          visibleColumns: action.payload,
          expanded: true,
        };
      default:
        return state;
    }
  };

const DynamicTableData: React.FC<TableProps> = ({
  columns,
  data,
  selectable = false,
  visibleColumnCount,
  collapsable = false,
  uniqueKeys,
  editColumnsConfig,
  onSave,
  isRowSelectable: isRowSelectableProp,
  BulkUpdateEditColumnConfig,
  BulkUpdatePayloadMapper,
  apiURL,
}) => {
  if (selectable && (!uniqueKeys || uniqueKeys.length === 0)) {
    throw new Error(
      '[DynamicTableData]: "uniqueKeys" must be provided when "selectable" is true.'
    );
  }
  const isRowSelectable = (row: any) =>
    typeof isRowSelectableProp === "function" ? isRowSelectableProp(row) : true;
  const getRowKey = useMemo(() => {
    if (!selectable || !uniqueKeys || uniqueKeys.length === 0) {
      throw new Error("When selectable=true, uniqueKeys must be provided.");
    }
    return (row: any): string => {
      if (typeof row !== "object" || row === null) {
        console.warn("Invalid row passed to getRowKey:", row);
        return "__invalid_row__";
      }
      return uniqueKeys.map((key) => String(row[key])).join("||");
    };
  }, [uniqueKeys, selectable]);
  const [tableData, setTableData] = useState(data);
  const [editModalOpen, setEditModalOpen] = useState(false);
  const [rowsToEdit, setRowsToEdit] = useState<any[]>([]);

  const handleEditSelectedRows = () => {
    const selected = data.filter((row) => selectedRows.has(getRowKey(row)));
    if (selected.length === 0) {
      alert("Please select at least one row to edit.");
      return;
    }

    if (selected.length > 10) {
      alert("You can only edit up to 10 rows at once.");
      return;
    }

    setRowsToEdit(selected);
    setEditModalOpen(true);
  };

  const handleSaveEditedRows = async (updatedRows: any[]) => {
    onSave(updatedRows);
  };

  const [state, dispatch] = useReducer(reducer, initialState(columns));
  const {
    search,
    filters,
    selectionFilter,
    selectedRows,
    visibleColumns,
    sortConfig,
    currentPage,
    rowsPerPage,
    showColumnSelector,
    showUtilities,
    expanded,
  } = state;

  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const handleUploadResult = (result: {
    message: string;
    successCount: number;
    failureCount: number;
    excelBlobUrl: string;
  }) => {
    alert(`${result.message}\n✅ Success: ${result.successCount}\n❌ Failed: ${result.failureCount}`);
    if (result.excelBlobUrl) {
      const link = document.createElement("a");
      link.href = result.excelBlobUrl;
      link.download = "upload-result.xlsx";
      link.click();
    }
  };

  const filteredData = useMemo(() => {
    return tableData.filter((row) => {
      const matchesGlobal =
        !search ||
        Object.values(row).some((val) =>
          String(val).toLowerCase().includes(search.toLowerCase())
        );
      const matchesFilters = Object.entries(filters).every(
        ([key, val]) =>
          val === "" ||
          String(row[key]).toLowerCase().includes(val.toLowerCase())
      );
      const rowId = getRowKey(row);
      const matchesSelection =
        selectionFilter === "all"
          ? true
          : selectionFilter === "selected"
          ? selectedRows.has(rowId)
          : !selectedRows.has(rowId);
      return matchesGlobal && matchesFilters && matchesSelection;
    });
  }, [search, filters, data, selectionFilter, selectedRows, getRowKey]);

  const shouldScroll =
    state.visibleColumns.size > (visibleColumnCount ?? Number.MAX_SAFE_INTEGER);

  const sortedData = useMemo(() => {
    if (!sortConfig) return filteredData;
    return [...filteredData].sort((a, b) => {
      const valA = a[sortConfig.key];
      const valB = b[sortConfig.key];
      return valA < valB
        ? sortConfig.direction === "asc"
          ? -1
          : 1
        : valA > valB
        ? sortConfig.direction === "asc"
          ? 1
          : -1
        : 0;
    });
  }, [filteredData, sortConfig]);

  const totalPages = useMemo(
    () => Math.ceil(sortedData.length / rowsPerPage),
    [sortedData.length, rowsPerPage]
  );

  const paginatedData = useMemo(
    () =>
      sortedData.slice(
        (currentPage - 1) * rowsPerPage,
        currentPage * rowsPerPage
      ),
    [sortedData, currentPage, rowsPerPage]
  );

  const isAllCurrentPageSelected = paginatedData.every((row) =>
    selectedRows.has(getRowKey(row))
  );
  const isAnyCurrentPageSelected = paginatedData.some((row) =>
    selectedRows.has(getRowKey(row))
  );

  const selectAllRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (selectAllRef.current) {
      selectAllRef.current.indeterminate =
        isAnyCurrentPageSelected && !isAllCurrentPageSelected;
    }
  }, [isAllCurrentPageSelected, isAnyCurrentPageSelected]);

  const handleSelectRow = (row: any) => {
    const key = getRowKey(row);
    dispatch({ type: "TOGGLE_SELECT_ROW", payload: key });
  };

  const handleSelectAll = () => {
    const keys = paginatedData
      .filter(isRowSelectable)
      .map((row) => getRowKey(row));
    dispatch({
      type: isAllCurrentPageSelected ? "DESELECT_ALL_ROWS" : "SELECT_ALL_ROWS",
      payload: keys,
    });
  };

  const handleDelete = () => {
    const toRemove = new Set(state.selectedRows);
    setTableData((prev) => prev.filter((row) => !toRemove.has(getRowKey(row))));
    dispatch({ type: "RESET_SELECTION" });
  };

  const handleExport = (type: "csv" | "excel") => {
    var tdata = paginatedData;
    const exportData = tdata.map((row) => {
      const newRow: any = {};
      columns.forEach((col) => (newRow[col.Header] = row[col.accessor]));
      return newRow;
    });
    if (type === "csv") {
      const csv = Papa.unparse(exportData);
      const blob = new Blob([csv], { type: "text/csv;charset=utf-8;" });
      saveAs(blob, "table-data.csv");
    } else {
      const ws = XLSX.utils.json_to_sheet(exportData);
      const wb = XLSX.utils.book_new();
      XLSX.utils.book_append_sheet(wb, ws, "Sheet1");
      XLSX.writeFile(wb, "table-data.xlsx");
    }
  };

  const toggleSort = (accessor: string) => {
    dispatch({ type: "TOGGLE_SORT", payload: accessor });
  };

  const groupedHeaders = useMemo(() => {
    const groups: Record<string, TableColumnsConfig[]> = {};
    columns.forEach((col) => {
      const group = col.parentHeader || "";
      if (!groups[group]) groups[group] = [];
      groups[group].push(col);
    });
    return groups;
  }, [columns]);

  const getPaginationNumbers = () => {
    const pageNumbers: (number | string)[] = [];
    for (let i = 1; i <= totalPages; i++) {
      if (i === 1 || i === totalPages || Math.abs(i - currentPage) <= 1) {
        pageNumbers.push(i);
      } else if (
        (i === currentPage - 2 && !pageNumbers.includes("...")) ||
        (i === currentPage + 2 && !pageNumbers.includes("..."))
      ) {
        pageNumbers.push("...");
      }
    }
    return pageNumbers;
  };

  const handleRefresh = () => {
    setTableData(data);
    dispatch({
      type: "RESET_ALL",
      payload: new Set(columns.map((c) => c.accessor)),
    });
  };

  const hasGroupHeaders = useMemo(
    () => Object.keys(groupedHeaders).some((key) => key !== ""),
    [groupedHeaders]
  );

  const filteredSelectedCount = filteredData.filter((row) => {
    const key = getRowKey(row);
    return selectedRows.has(key);
  }).length;

  return (
    <div className="p-4">
      <div className="flex items-center justify-between flex-wrap gap-2 mb-4 ">
        <Toolbar
          expanded={expanded}
          collapsable={collapsable}
          selectable={selectable}
          selectedCount={state.selectedRows.size}
          onDelete={handleDelete}
          onEdit={handleEditSelectedRows}
          editModalOpen={editModalOpen}
          setEditModalOpen={setEditModalOpen}
          rowsToEdit={rowsToEdit}
          editColumnsConfig={editColumnsConfig}
          onSave={handleSaveEditedRows}
          onUploadOpen={() => setIsUploadModalOpen(true)}
          BulkUpdateEditColumnConfig={BulkUpdateEditColumnConfig}
          apiURL={apiURL}
          BulkUpdatePayloadMapper={BulkUpdatePayloadMapper}
          onRefresh={handleRefresh}
          state={state}
          dispatch={dispatch}
          PointerIcon={PointerIcon}
          ExpandIcon={ExpandIcon}
          CollapseIcon={CollapseIcon}
          DeleteIcon={DeleteIcon}
          EditIcon={EditIcon}
          RefreshIcon={RefreshIcon}
        />
      </div>

      {expanded && (
        <TableHeader
          selectable={selectable}
          selectAllRef={selectAllRef}
          isAllCurrentPageSelected={isAllCurrentPageSelected}
          selectionFilter={selectionFilter}
          dispatch={dispatch}
          columns={columns}
          visibleColumns={visibleColumns}
          groupedHeaders={groupedHeaders}
          toggleSort={toggleSort}
          sortConfig={sortConfig}
          filters={filters}
        />
      )}

      <TableBody
        paginatedData={paginatedData}
        columns={columns}
        visibleColumns={visibleColumns}
        selectable={selectable}
        selectedRows={selectedRows}
        isRowSelectable={isRowSelectable}
        handleSelectRow={handleSelectRow}
      />

      <TableFooter
        rowsPerPage={rowsPerPage}
        currentPage={currentPage}
        totalPages={totalPages}
        dispatch={dispatch}
        filteredSelectedCount={filteredSelectedCount}
        filteredDataLength={filteredData.length}
        paginatedDataLength={paginatedData.length}
        selectionFilter={selectionFilter}
        getPaginationNumbers={getPaginationNumbers}
      />

      <EditRowModal
        isOpen={editModalOpen}
        onClose={() => setEditModalOpen(false)}
        onSave={handleSaveEditedRows}
        getRowKey={getRowKey}
        rows={rowsToEdit}
        columns={editColumnsConfig}
      />
      <UploadModal
        isOpen={isUploadModalOpen}
        onClose={() => setIsUploadModalOpen(false)}
        columns={BulkUpdateEditColumnConfig}
        uniqueKeys={["tcs_catsubcat_desc"]}
        existingData={[]}
        apiUrl={apiURL}
        payloadMapper={BulkUpdatePayloadMapper}
        onResult={handleUploadResult}
      />
    </div>
  );
};

export default DynamicTableData;
