import React from "react";
import { type TableColumnsConfig } from "./Config/TableColumnConfig";
import { type SortConfig } from "./Config/SortConfig";

interface TableHeaderProps {
  selectable: boolean;
  selectAllRef: React.RefObject<HTMLInputElement>;
  isAllCurrentPageSelected: boolean;
  selectionFilter: string;
  dispatch: React.Dispatch<any>;
  columns: TableColumnsConfig[];
  visibleColumns: Set<string>;
  groupedHeaders: Record<string, TableColumnsConfig[]>;
  toggleSort: (accessor: string) => void;
  sortConfig: SortConfig | null;
  filters: Record<string, string>;
}

const TableHeader: React.FC<TableHeaderProps> = ({
  selectable,
  selectAllRef,
  isAllCurrentPageSelected,
  selectionFilter,
  dispatch,
  columns,
  visibleColumns,
  groupedHeaders,
  toggleSort,
  sortConfig,
  filters,
}) => {
  const hasGroupHeaders = Object.keys(groupedHeaders).some((key) => key !== "");

  return (
    <thead className="sticky top-0 z-10 bg-white">
      {hasGroupHeaders && (
        <tr>
          {selectable && <th className="p-2 sticky left-0 bg-white z-20" />}
          {Object.entries(groupedHeaders).map(([group, cols]) => {
            const visibleCount = cols.filter((c) =>
              visibleColumns.has(c.accessor)
            ).length;
            if (visibleCount === 0) return null;
            return (
              <th
                key={group}
                colSpan={visibleCount}
                className="border text-center px-2 py-1 bg-gray-100 font-bold"
              >
                {group}
              </th>
            );
          })}
        </tr>
      )}
      <tr>
        {selectable && (
          <th className="p-2 border text-center sticky left-0 bg-blue-100 z-20">
            <input
              ref={selectAllRef}
              type="checkbox"
              title="Select All"
              className="w-5 h-5 align-middle hover:cursor-pointer"
              onChange={() =>
                dispatch({ type: "TOGGLE_SELECT_ALL_CURRENT_PAGE" })
              }
              checked={isAllCurrentPageSelected}
            />
          </th>
        )}
        {columns
          .filter((c) => visibleColumns.has(c.accessor))
          .map((col) => (
            <th
              key={col.accessor}
              className={`border px-2 py-1 cursor-pointer text-left bg-white`}
              onClick={() => toggleSort(col.accessor)}
              title={"Sort " + col.Header}
              style={col.headerStyle}
            >
              <div className="flex items-center justify-center">
                <span>{col.Header}</span>
                <span className="w-10">
                  {sortConfig?.key === col.accessor && (
                    <span>{sortConfig.direction === "asc" ? "▲" : "▼"}</span>
                  )}
                </span>
              </div>
            </th>
          ))}
      </tr>
      <tr>
        {selectable && (
          <th className="p-2 border text-center sticky left-0 z-20 bg-white">
            <select
              value={selectionFilter}
              onChange={(e) =>
                dispatch({
                  type: "SET_SELECTION_FILTER",
                  payload: e.target.value,
                })
              }
              title="Select Checkbox Type"
              className="text-xs py-1 w-full rounded border hover:cursor-pointer"
            >
              <option value="all">All</option>
              <option value="selected">Selected</option>
              <option value="unselected">Unselected</option>
            </select>
          </th>
        )}

        {columns
          .filter((c) => visibleColumns.has(c.accessor))
          .map((col) => (
            <th
              key={col.accessor}
              className={`border px-2 py-1 bg-gray-50`}
            >
              {col.filter && (
                <input
                  type="text"
                  value={filters[col.accessor] || ""}
                  onClick={(e) => e.stopPropagation()}
                  onChange={(e) =>
                    dispatch({
                      type: "SET_FILTER",
                      payload: {
                        key: col.accessor,
                        value: e.target.value,
                      },
                    })
                  }
                  className="w-full text-xs border rounded px-2 py-1"
                  placeholder="Filter"
                />
              )}
            </th>
          ))}
      </tr>
    </thead>
  );
};

export default TableHeader;
