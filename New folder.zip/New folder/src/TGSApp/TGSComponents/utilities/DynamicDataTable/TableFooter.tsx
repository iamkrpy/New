import React from "react";

interface TableFooterProps {
  rowsPerPage: number;
  currentPage: number;
  totalPages: number;
  dispatch: React.Dispatch<any>;
  filteredSelectedCount: number;
  filteredDataLength: number;
  paginatedDataLength: number;
  selectionFilter: string;
  getPaginationNumbers: () => (number | string)[];
}

const TableFooter: React.FC<TableFooterProps> = ({
  rowsPerPage,
  currentPage,
  totalPages,
  dispatch,
  filteredSelectedCount,
  filteredDataLength,
  paginatedDataLength,
  selectionFilter,
  getPaginationNumbers,
}) => {
  return (
    <div className="flex flex-col sm:flex-row justify-between items-center mt-4 gap-4">
      <div className="flex items-center gap-2">
        <span>Rows per page:</span>
        <input
          type="number"
          className="border rounded px-2 py-1 w-20"
          value={rowsPerPage}
          onChange={(e) => {
            const value = Math.max(1, parseInt(e.target.value) || 10);
            dispatch({ type: "SET_ROWS_PER_PAGE", payload: value });
          }}
        />
      </div>
      {selectionFilter === "all" && (
        <div className="text-sm text-gray-600">
          Selected {filteredSelectedCount} of {filteredDataLength} records
        </div>
      )}
      <div className="text-sm text-gray-600">
        Showing {paginatedDataLength} of {filteredDataLength} records
      </div>
      <div className="flex items-center gap-1 flex-wrap">
        <button
          onClick={() =>
            dispatch({
              type: "SET_CURRENT_PAGE",
              payload: Math.max(1, currentPage - 1),
            })
          }
          disabled={currentPage === 1}
          className="px-3 py-1 rounded border bg-gray-200 disabled:opacity-50"
        >
          Prev
        </button>
        {getPaginationNumbers().map((page, idx) =>
          typeof page === "number" ? (
            <button
              key={idx}
              onClick={() => dispatch({ type: "SET_CURRENT_PAGE", payload: page })}
              className={`px-3 py-1 rounded border ${
                currentPage === page
                  ? "bg-blue-600 text-white"
                  : "bg-white text-blue-600"
              }`}
            >
              {page}
            </button>
          ) : (
            <span key={idx} className="px-2">
              ...
            </span>
          )
        )}

        <button
          onClick={() =>
            dispatch({
              type: "SET_CURRENT_PAGE",
              payload: Math.min(totalPages, currentPage + 1),
            })
          }
          disabled={currentPage === totalPages}
          className="px-3 py-1 rounded border bg-gray-200 disabled:opacity-50"
        >
          Next
        </button>
      </div>
    </div>
  );
};

export default TableFooter;
