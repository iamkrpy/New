import React, { useState, useEffect, useRef, useLayoutEffect } from "react";
import { createPortal } from "react-dom";

interface SuggestionBoxProps {
  inputRef: React.RefObject<HTMLInputElement>;
  fetchSuggestions: (query: string) => Promise<{ label: string; value: any }[]>;
  onSelect: (value: any) => void;
  containerRef?: React.RefObject<HTMLElement>; // unused now, since we're using portal
}

export const SuggestionBox: React.FC<SuggestionBoxProps> = ({
  inputRef,
  fetchSuggestions,
  onSelect,
}) => {
  const [suggestions, setSuggestions] = useState<{ label: string; value: any }[]>([]);
  const [visible, setVisible] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(-1);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const updatePosition = () => {
    const input = inputRef?.current;
    const dropdown = dropdownRef.current;

    if (input && dropdown) {
      const rect = input.getBoundingClientRect();
      dropdown.style.position = "absolute";
      dropdown.style.top = `${rect.bottom + window.scrollY}px`;
      dropdown.style.left = `${rect.left + window.scrollX}px`;
      dropdown.style.width = `${rect.width}px`;
      dropdown.style.zIndex = "9999";
    }
  };

  useEffect(() => {
    const input = inputRef?.current;
    if (!input) return;

    const handleInput = async () => {
      const value = input.value.trim();
      if (value.length === 0) {
        setSuggestions([]);
        setVisible(false);
        return;
      }

      try {
        const results = await fetchSuggestions(value);
        setSuggestions(results);
        setVisible(true);
        setSelectedIndex(-1);
      } catch (error) {
        console.error("Suggestion fetch failed:", error);
        setSuggestions([]);
        setVisible(false);
      }
    };

    const handleKeyDown = (e: KeyboardEvent) => {
      if (!visible) return;

      if (e.key === "ArrowDown") {
        setSelectedIndex((prev) => Math.min(prev + 1, suggestions.length - 1));
        e.preventDefault();
      } else if (e.key === "ArrowUp") {
        setSelectedIndex((prev) => Math.max(prev - 1, 0));
        e.preventDefault();
      } else if (e.key === "Enter") {
        if (selectedIndex >= 0 && selectedIndex < suggestions.length) {
          onSelect(suggestions[selectedIndex].value);
          setVisible(false);
        }
        e.preventDefault();
      }
    };

    const handleClickOutside = (e: MouseEvent) => {
      if (
        dropdownRef.current &&
        !dropdownRef.current.contains(e.target as Node) &&
        !input.contains(e.target as Node)
      ) {
        setVisible(false);
      }
    };

    input.addEventListener("input", handleInput);
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleClickOutside);

    return () => {
      input.removeEventListener("input", handleInput);
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [inputRef, suggestions, visible]);

  useLayoutEffect(() => {
    if (visible && suggestions.length > 0) {
      updatePosition();
    }
  }, [visible, suggestions]);

  if (!visible || suggestions.length === 0) return null;

  return createPortal(
    <div
      ref={dropdownRef}
      className="z-50 border border-gray-300 bg-white rounded shadow max-h-60 overflow-auto"
    >
      {suggestions.map((item, idx) => (
        <div
          key={idx}
          className={`px-4 py-2 cursor-pointer ${
            idx === selectedIndex ? "bg-blue-100" : ""
          }`}
          onMouseDown={() => {
            onSelect(item.value);
            setVisible(false);
          }}
        >
          {item.label}
        </div>
      ))}
    </div>,
    document.body
  );
};
