import React, { useRef, useState } from "react";
import ExcelJS from "exceljs";
import axios from "axios";
import { payloadMapper } from "../../TGSConfig/PayLoadColumnsConfig/CatSubCatBuyer";

interface ColumnConfig {
  Header: string;
  accessor: string;
  editable?: boolean;
  required?: boolean;
  type?: "string" | "number" | "date";
  allowedValues?: string[];
  maxLength?: number;
  format?: RegExp;
}

interface BulkEditUploaderProps {
  columns: ColumnConfig[];
  uniqueKeys: string[];
  existingData: any[];
  apiUrl: string;
  payloadMapper: (row: any) => any;
  onResult: (result: {
    message: string;
    successCount: number;
    failureCount: number;
    excelBlobUrl: string;
  }) => void;
}

const BulkEditUploader: React.FC<BulkEditUploaderProps> = ({
  columns,
  uniqueKeys,
  existingData,
  apiUrl,
  onResult,
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [loading, setLoading] = useState(false);

  const downloadTemplate = async () => {
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Template");

    const editableColumns = columns.filter((col) => col.editable);
    worksheet.columns = editableColumns.map((col) => ({
      header: col.Header,
      key: col.accessor,
      width: 25,
    }));
    worksheet.views = [{ state: "frozen", ySplit: 1 }]; 
    for (let i = 0; i < 50; i++) worksheet.addRow({});

    editableColumns.forEach((col, colIndex) => {
      for (let row = 2; row <= 51; row++) {
        const cell = worksheet.getCell(row, colIndex + 1);
        
        if (col.type === "date") cell.numFmt = "@";
    if (col.allowedValues?.length) {
          cell.dataValidation = {
            type: "list",
            allowBlank: !col.required,
            formulae: [`"${col.allowedValues.join(",")}"`],
            showErrorMessage: true,
            errorTitle: "Invalid value",
            error: `Choose from: ${col.allowedValues.join(", ")}`,
          };
        }
      }
      

      const headerCell = worksheet.getCell(1, colIndex + 1);
      headerCell.font = { bold: true };
      if (col.required) {
        headerCell.fill = {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FFFFC7CE" }, // light red
        };
      }
let notes: string[] = [];
if (col.required) notes.push("Required field");
if (col.type === "date") notes.push("Format: YYYY-MM-DD");
if (col.maxLength) notes.push(`Max length: ${col.maxLength}`);
if (col.allowedValues) notes.push(`Allowed: ${col.allowedValues.join(", ")}`);
headerCell.note = notes.join("\n");

    });

    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], {
      type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "bulk-edit-template.xlsx";
    a.click();
  };

  const validateRow = (row: any, rowIndex: number): string[] => {
    const errors: string[] = [];

    for (const col of columns) {
      if (!col.editable) continue;
      const value = row[col.accessor];

      if (col.required && (value === undefined || value === null || value === "")) {
        errors.push(`Row ${rowIndex + 1}: "${col.Header}" is required.`);
        continue;
      }

      if (value && col.type === "number" && isNaN(Number(value))) {
        errors.push(`Row ${rowIndex + 1}: "${col.Header}" must be a number.`);
      }

      if (typeof value === "number" && col.type === "date") {
        const excelEpoch = new Date(1899, 11, 30);
        const date = new Date(excelEpoch.getTime() + value * 86400000);
        row[col.accessor] = date.toISOString().split("T")[0];
      } else if (col.type === "date" && typeof value === "string") {
        if (!/^\d{4}-\d{2}-\d{2}$/.test(value)) {
          errors.push(`Row ${rowIndex + 1}: "${col.Header}" must be in format YYYY-MM-DD.`);
        }
      }

      if (value && col.allowedValues && !col.allowedValues.includes(value)) {
        errors.push(`Row ${rowIndex + 1}: "${col.Header}" must be one of ${col.allowedValues.join(", ")}.`);
      }

      if (value && col.maxLength && value.length > col.maxLength) {
        errors.push(`Row ${rowIndex + 1}: "${col.Header}" exceeds max length ${col.maxLength}.`);
      }
    }

    return errors;
  };

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = async (evt) => {
      try {
        const buffer = evt.target?.result as ArrayBuffer;
        const workbook = new ExcelJS.Workbook();
        await workbook.xlsx.load(buffer);
        const worksheet = workbook.worksheets[0];

        const uploadedRows: any[] = [];
        worksheet.eachRow((row, rowIndex) => {
          if (rowIndex === 1) return;
          const obj: any = {};
          columns.forEach((col, idx) => {
            if (!col.editable) return;
            const cellValue = row.getCell(idx + 1).value;
            obj[col.accessor] = cellValue?.toString().trim();
          });
          console.log(obj)
          uploadedRows.push(obj);
        });

        const allErrors = uploadedRows.flatMap((row, idx) => validateRow(row, idx));
        if (allErrors.length > 0) {
          alert("Validation Errors:\n" + allErrors.join("\n"));
          return;
        }

        const merged = mergeData(existingData, uploadedRows, uniqueKeys);
        await sendToApiAndExport(merged);
      } catch (err) {
        console.error("Error processing file:", err);
      }
    };

    reader.readAsArrayBuffer(file);
    e.target.value = "";
  };

  const mergeData = (existing: any[], uploaded: any[], keys: string[]): any[] => {
    const updated = [...existing];
    uploaded.forEach((row) => {
      const matchIndex = updated.findIndex((item) => keys.every((key) => item[key] === row[key]));
      if (matchIndex !== -1) {
        updated[matchIndex] = { ...updated[matchIndex], ...row };
      } else {
        updated.push(row);
      }
    });
    return updated;
  };

  const sendToApiAndExport = async (rows: any[]) => {
    setLoading(true);
    let successRows: any[] = [];
    let failedRows: { [key: string]: any }[] = [];
    console.log(rows)
    const payload = rows.map(payloadMapper);

    try {
        console.log(payload)
      const response = await axios.post(apiUrl, payload);
      const apiResponse = response.data;

      if (apiResponse.isSuccess && Array.isArray(apiResponse.data)) {
        for (const result of apiResponse.data) {
          const row = result.row;
          if (result.isSuccess) successRows.push(row);
          else failedRows.push({ ...row, __ERROR__: result.errorMessage });
        }
      } else {
        failedRows = rows.map((row) => ({ ...row, __ERROR__: apiResponse.message || "Unknown failure" }));
      }
    } catch (err: any) {
      failedRows = rows.map((row) => ({ ...row, __ERROR__: err?.message || "Request failed" }));
    }

    const excelBlobUrl = await createResultExcel(successRows, failedRows);
    const message =
      failedRows.length === 0
        ? "All rows updated successfully."
        : successRows.length === 0
        ? "All rows failed to update."
        : "Partial success: some rows failed.";

    setLoading(false);
    onResult({
      message,
      successCount: successRows.length,
      failureCount: failedRows.length,
      excelBlobUrl,
    });
  };

  const createResultExcel = async (success: any[], failed: { [key: string]: any }[]): Promise<string> => {
    const workbook = new ExcelJS.Workbook();
    if (success.length > 0) {
      const wsSuccess = workbook.addWorksheet("Success");
      wsSuccess.columns = columns.map((col) => ({ header: col.Header, key: col.accessor }));
      wsSuccess.addRows(success);
    }
    if (failed.length > 0) {
      const wsFailed = workbook.addWorksheet("Failed");
      const keys = [...new Set(failed.flatMap(Object.keys))];
      wsFailed.columns = keys.map((key) => ({ header: key, key }));
      wsFailed.addRows(failed);
    }
    const buffer = await workbook.xlsx.writeBuffer();
    const blob = new Blob([buffer], { type: "application/octet-stream" });
    return URL.createObjectURL(blob);
  };

  return (
    <div className="flex items-center gap-4 mt-4">
      <button
        onClick={downloadTemplate}
        className="px-4 py-2 bg-blue-600 text-white rounded hover:bg-blue-700 transition"
      >
        Download Template
      </button>
      <button
        onClick={() => fileInputRef.current?.click()}
        className="px-4 py-2 bg-green-600 text-white rounded hover:bg-green-700 transition disabled:opacity-50"
        disabled={loading}
      >
        {loading ? "Uploading..." : "Upload Excel"}
      </button>
      <input
        type="file"
        accept=".xlsx, .xls"
        ref={fileInputRef}
        className="hidden"
        onChange={handleFileUpload}
      />
    </div>
  );
};

export default BulkEditUploader;