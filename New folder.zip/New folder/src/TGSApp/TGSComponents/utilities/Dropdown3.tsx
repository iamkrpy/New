import axios from "axios";
import React, { useEffect, useRef, useState } from "react";

interface Option {
  label: string;
  value: string;
}

interface DropdownMenuProps {
  label: string;
  dataSourceUrl?: string;
  selectionMode?: "single" | "multiple";
  selected: string[];
  onChange: (selected: string[]) => void;
  placeholder?: string;
  labelKey?: string;
  valueKey?: string;
  disabled?: boolean;
  required?: boolean;
  onError?: (hasError: boolean, message?: string) => void;
}

const DropdownMenu: React.FC<DropdownMenuProps> = ({
  label,
  dataSourceUrl,
  selectionMode = "single",
  selected,
  onChange,
  placeholder = "Select option(s)...",
  labelKey = "label",
  valueKey = "value",
  disabled = false,
  required = false,
  onError,
}) => {
  const [options, setOptions] = useState<Option[]>([]);
  const [searchText, setSearchText] = useState("");
  const [isOpen, setIsOpen] = useState(false);
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [openUpward, setOpenUpward] = useState(false);

  const menuRef = useRef<HTMLDivElement>(null);

  const fetchData = async () => {
    // try {
    //   if(dataSourceUrl){
    //     const response = await axios.get(dataSourceUrl);
    //   const apiResult = response.data.Data;
    //   const mapped = apiResult.map((item: any) => ({
    //     label: item[labelKey] ?? item[valueKey],
    //     value: item[valueKey] ?? "",
    //   }));
    //   setOptions(mapped);
    //   onChange([]);
    //   }
    //   else{

    //   }
    // } catch (err) {
    //   console.error("Failed to fetch dropdown data:", err);
    // }
    setOptions([]);
    onChange([]);
  };

  useEffect(() => {
    fetchData();
  }, [dataSourceUrl, labelKey, valueKey]);

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) {
        setIsOpen(false);
        setTouched(true);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  // Validation
  useEffect(() => {
    if (!touched) return;
    if (required && selected.length === 0) {
      setError("Selection is required.");
      onError?.(true, "Selection is required.");
    } else {
      setError(null);
      onError?.(false);
    }
  }, [selected, touched, required]);

  // Positioning on open
  useEffect(() => {
    if (!isOpen || !menuRef.current) return;

    requestAnimationFrame(() => {
      const rect = menuRef.current!.getBoundingClientRect();
      const dropdownHeight = 250;
      const spaceBelow = window.innerHeight - rect.bottom;
      const spaceAbove = rect.top;
      setOpenUpward(spaceBelow < dropdownHeight && spaceAbove > dropdownHeight);
    });
  }, [isOpen]);

  const toggleOption = (value: string) => {
    setTouched(true);
    if (selectionMode === "single") {
      onChange([value]);
      setIsOpen(false);
    } else {
      if (selected.includes(value)) {
        onChange(selected.filter((v) => v !== value));
      } else {
        onChange([...selected, value]);
      }
    }
  };

  const isSelected = (value: string) => selected.includes(value);

 const filtered = options.filter((opt) =>
  (opt.label ?? "").toString().toLowerCase().includes(searchText.toLowerCase())
  );

  return (
    <div className="relative w-full" ref={menuRef}>
      <label className="font-medium text-lg block mb-1">{label}</label>

      {/* Trigger */}
      <div
        className={`w-full border px-4 py-2 rounded-lg overflow-x-auto bg-white ring-1 ring-emerald-500 shadow cursor-pointer ${
          disabled ? "opacity-50 cursor-not-allowed" : "hover:border-blue-400"
        } ${error ? "border-red-500" : "border-gray-300"}`}
        onClick={() => {
          if (!disabled) {
            setIsOpen((prev) => !prev);
            setTouched(true);
          }
        }}
      >
        {selected.length === 0
          ? placeholder
          : options
              .filter((opt) => selected.includes(opt.value))
              .map((opt) => opt.label)
              .join(", ")}
      </div>

      {error && <div className="text-sm text-red-600 mt-1">{error}</div>}

      {/* Dropdown */}
      {isOpen && !disabled && (
        <div
          className={`absolute z-50 w-full ${
            openUpward ? "bottom-full mb-1" : "top-full mt-1"
          } bg-white border rounded shadow-lg max-h-64 overflow-auto`}
        >
          {/* Search + Refresh */}
          <div className="p-2 flex items-center gap-2 sticky top-0 bg-white z-10">
            <input
              type="text"
              className="flex-1 px-3 py-1 border rounded focus:outline-none focus:ring-2 focus:ring-blue-300"
              placeholder="Search..."
              value={searchText}
              onChange={(e) => setSearchText(e.target.value)}
            />
            <button
              onClick={(e) => {
                e.stopPropagation();
                fetchData();
              }}
              title="Refresh"
              className="px-2 py-1 text-sm bg-gray-200 hover:bg-gray-300 border rounded"
            >
              🔁
            </button>
          </div>

          {/* Options */}
          <ul>
            {filtered.length > 0 ? (
              filtered.map((opt) => (
                <li
                  key={opt.value}
                  className={`px-4 py-2 cursor-pointer hover:bg-blue-100 flex items-center gap-2 ${
                    isSelected(opt.value) ? "bg-blue-50 font-semibold" : ""
                  }`}
                  onClick={() => toggleOption(opt.value)}
                >
                  {selectionMode === "multiple" && (
                    <input
                      type="checkbox"
                      checked={isSelected(opt.value)}
                      onChange={() => toggleOption(opt.value)}
                      onClick={(e) => e.stopPropagation()}
                    />
                  )}
                  {opt.label}
                </li>
              ))
            ) : (
              <li className="px-4 py-2 text-gray-400">No options found</li>
            )}
          </ul>
        </div>
      )}
    </div>
  );
};

export default DropdownMenu;
