// import React, { useState, useEffect } from "react";

// interface SingleDatePickerProps {
//   label: string;
//   value: string;
//   onChange: (value: string) => void;
//   onError?: (error: string | null) => void;
//   placeholder?: string;
//   required?: boolean;
//   min?: string; // format: YYYY-MM-DD
//   max?: string;
//   disabled?: boolean;
//   displayFormat?:
//     | "YYYY-MM-DD"
//     | "DD/MM/YYYY"
//     | "MM-DD-YYYY"
//     | "DD-MM-YY"
//     | "DD-MON-YYYY"
//     | "DD-MON-YY"
//     | "DD-MONTH-YYYY"
//     | "DD-MONTH-YY";
// }

// const monthShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
// const monthFull = [
//   "January", "February", "March", "April", "May", "June",
//   "July", "August", "September", "October", "November", "December"
// ];

// const formatDate = (dateStr: string, format: string): string => {
//   if (!dateStr || !/\d{4}-\d{2}-\d{2}/.test(dateStr)) return dateStr;
//   const [yyyy, mm, dd] = dateStr.split("-");
//   const monthIndex = parseInt(mm, 10) - 1;
//   const monShort = monthShort[monthIndex];
//   const monFull = monthFull[monthIndex];
//   const yy = yyyy.slice(-2);

//   switch (format) {
//     case "DD/MM/YYYY":
//       return `${dd}/${mm}/${yyyy}`;
//     case "MM-DD-YYYY":
//       return `${mm}-${dd}-${yyyy}`;
//     case "DD-MM-YY":
//       return `${dd}-${mm}-${yy}`;
//     case "DD-MON-YYYY":
//       return `${dd}-${monShort}-${yyyy}`;
//     case "DD-MON-YY":
//       return `${dd}-${monShort}-${yy}`;
//     case "DD-MONTH-YYYY":
//       return `${dd}-${monFull}-${yyyy}`;
//     case "DD-MONTH-YY":
//       return `${dd}-${monFull}-${yy}`;
//     default:
//       return dateStr;
//   }
// };

// const SingleDatePicker: React.FC<SingleDatePickerProps> = ({
//   label,
//   value,
//   onChange,
//   onError,
//   placeholder = "",
//   required = false,
//   min,
//   max,
//   disabled = false,
//   displayFormat = "YYYY-MM-DD",
// }) => {
//   const [touched, setTouched] = useState(false);
//   const [error, setError] = useState<string | null>(null);
//   const [showCalendar, setShowCalendar] = useState(false);

//   const validate = (iso: string | null) => {
//     let err = null;
//     if (required && (!iso || iso.trim() === "")) {
//       err = "This field is required.";
//     } else if (iso && isNaN(new Date(iso).getTime())) {
//       err = "Invalid date.";
//     } else if (min && iso && iso < min) {
//       err = `Date must be after ${formatDate(min, displayFormat)}`;
//     } else if (max && iso && iso > max) {
//       err = `Date must be before ${formatDate(max, displayFormat)}`;
//     }
//     setError(err);
//     if (onError) onError(err);
//     return err;
//   };

//   const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
//     const iso = e.target.value;
//     setTouched(true);
//     setShowCalendar(false);
//     onChange(iso);
//     validate(iso);
//   };

//   return (
//     <div className="w-full relative">
//       <label className="block text-sm font-medium text-gray-700 mb-1">
//         {label}
//       </label>
//       <input
//         type="text"
//         value={value ? formatDate(value, displayFormat) : ""}
//         readOnly
//         onClick={() => !disabled && setShowCalendar(true)}
//         placeholder={placeholder || displayFormat}
//         className={`w-full px-3 py-2 border rounded-md focus:outline-none focus:ring-2 ${
//           error ? "border-red-500 ring-red-200" : "border-gray-300 focus:ring-blue-300"
//         } ${disabled ? "bg-gray-100 cursor-not-allowed" : "bg-white"}`}
//       />

//       {showCalendar && (
//         <input
//           type="date"
//           className="absolute top-full left-0 mt-2 w-full border px-3 py-2 rounded-md shadow z-50"
//           value={value}
//           onChange={handleChange}
//           min={min}
//           max={max}
//           onBlur={() => setShowCalendar(false)}
//         />
//       )}

//       {value && !error && (
//         <div className="mt-1 text-sm text-gray-600">
//           Selected: {formatDate(value, displayFormat)}
//         </div>
//       )}
//       {error && <p className="text-sm text-red-600 mt-1">{error}</p>}
//     </div>
//   );
// };

// export default SingleDatePicker;
import React, { useState, useEffect, useRef } from "react";

interface SingleDatePickerProps {
  label: string;
  value: string;
  onChange: (value: string) => void;
  onError?: (error: string | null) => void;
  placeholder?: string;
  required?: boolean;
  min?: string; // format: YYYY-MM-DD
  max?: string;
  disabled?: boolean;
  displayFormat?:
    | "YYYY-MM-DD"
    | "DD/MM/YYYY"
    | "MM-DD-YYYY"
    | "DD-MM-YY"
    | "DD-MON-YYYY"
    | "DD-MON-YY"
    | "DD-MONTH-YYYY"
    | "DD-MONTH-YY";
}

const monthShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const monthFull = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const formatDate = (dateStr: string, format: string): string => {
  if (!dateStr || !/\d{4}-\d{2}-\d{2}/.test(dateStr)) return dateStr;
  const [yyyy, mm, dd] = dateStr.split("-");
  const monthIndex = parseInt(mm, 10) - 1;
  const monShort = monthShort[monthIndex];
  const monFull = monthFull[monthIndex];
  const yy = yyyy.slice(-2);

  switch (format) {
    case "DD/MM/YYYY":
      return `${dd}/${mm}/${yyyy}`;
    case "MM-DD-YYYY":
      return `${mm}-${dd}-${yyyy}`;
    case "DD-MM-YY":
      return `${dd}-${mm}-${yy}`;
    case "DD-MON-YYYY":
      return `${dd}-${monShort}-${yyyy}`;
    case "DD-MON-YY":
      return `${dd}-${monShort}-${yy}`;
    case "DD-MONTH-YYYY":
      return `${dd}-${monFull}-${yyyy}`;
    case "DD-MONTH-YY":
      return `${dd}-${monFull}-${yy}`;
    default:
      return dateStr;
  }
};

const SingleDatePicker: React.FC<SingleDatePickerProps> = ({
  label,
  value,
  onChange,
  onError,
  placeholder = "",
  required = false,
  min,
  max,
  disabled = false,
  displayFormat = "YYYY-MM-DD",
}) => {
  const [touched, setTouched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const validate = (iso: string | null) => {
    let err = null;
    if (required && (!iso || iso.trim() === "")) {
      err = "This field is required.";
    } else if (iso && isNaN(new Date(iso).getTime())) {
      err = "Invalid date.";
    } else if (min && iso && iso < min) {
      err = `Date must be after ${formatDate(min, displayFormat)}`;
    } else if (max && iso && iso > max) {
      err = `Date must be before ${formatDate(max, displayFormat)}`;
    }
    setError(err);
    if (onError) onError(err);
    return err;
  };

  const handleDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const iso = e.target.value;
    setTouched(true);
    onChange(iso);
    validate(iso);
  };

  const triggerNativeCalendar = () => {
    if (inputRef.current) {
      inputRef.current.showPicker?.(); // for modern browsers
      inputRef.current.click(); // fallback for older ones
    }
  };

  return (
    <div className="w-full relative">
      <label className="block text-sm font-medium text-gray-700 mb-1">
        {label}
      </label>

      {/* Display input */}
      <div
        className={`w-full px-3 py-2 border rounded-md focus-within:ring-2 relative ${
          error ? "border-red-500 ring-red-200" : "border-gray-300 focus-within:ring-blue-300"
        } ${disabled ? "bg-gray-100 cursor-not-allowed" : "bg-white"}`}
        onClick={() => !disabled && triggerNativeCalendar()}
      >
        <span className="text-gray-800">
          {value ? formatDate(value, displayFormat) : placeholder || displayFormat}
        </span>

        {/* Transparent native input */}
        <input
          type="date"
          ref={inputRef}
          value={value}
          min={min}
          max={max}
          onChange={handleDateChange}
          disabled={disabled}
          className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
          onBlur={() => setTouched(true)}
        />
      </div>

      {value && !error && (
        <div className="mt-1 text-sm text-gray-600">
          Selected: {formatDate(value, displayFormat)}
        </div>
      )}
      {error && <p className="text-sm text-red-600 mt-1">{error}</p>}
    </div>
  );
};

export default SingleDatePicker;
