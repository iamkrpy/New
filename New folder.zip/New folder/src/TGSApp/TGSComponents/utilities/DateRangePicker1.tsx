import React, { useState, useEffect, useRef } from "react";

interface DateRangePickerProps {
  label?: string;
  startDate: string;
  endDate: string;
  onChange: (start: string, end: string) => void;
  onError?: (error: string | null) => void;
  required?: boolean;
  min?: string;
  max?: string;
  disabled?: boolean;
  displayFormat?:
    | "YYYY-MM-DD"
    | "DD/MM/YYYY"
    | "MM-DD-YYYY"
    | "DD-MM-YY"
    | "DD-MON-YYYY"
    | "DD-MON-YY"
    | "DD-MONTH-YYYY"
    | "DD-MONTH-YY";
}

const monthShort = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
const monthFull = [
  "January", "February", "March", "April", "May", "June",
  "July", "August", "September", "October", "November", "December"
];

const formatDate = (dateStr: string, format: string): string => {
  if (!dateStr || !/\d{4}-\d{2}-\d{2}/.test(dateStr)) return dateStr;
  const [yyyy, mm, dd] = dateStr.split("-");
  const monthIndex = parseInt(mm, 10) - 1;
  const monShort = monthShort[monthIndex];
  const monFull = monthFull[monthIndex];
  const yy = yyyy.slice(-2);

  switch (format) {
    case "DD/MM/YYYY": return `${dd}/${mm}/${yyyy}`;
    case "MM-DD-YYYY": return `${mm}-${dd}-${yyyy}`;
    case "DD-MM-YY": return `${dd}-${mm}-${yy}`;
    case "DD-MON-YYYY": return `${dd}-${monShort}-${yyyy}`;
    case "DD-MON-YY": return `${dd}-${monShort}-${yy}`;
    case "DD-MONTH-YYYY": return `${dd}-${monFull}-${yyyy}`;
    case "DD-MONTH-YY": return `${dd}-${monFull}-${yy}`;
    default: return dateStr;
  }
};

const DateRangePicker: React.FC<DateRangePickerProps> = ({
  label = "Date Range",
  startDate,
  endDate,
  onChange,
  onError,
  required = false,
  min,
  max,
  disabled = false,
  displayFormat = "YYYY-MM-DD",
}) => {
  const [startTouched, setStartTouched] = useState(false);
  const [endTouched, setEndTouched] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const startRef = useRef<HTMLInputElement>(null);
  const endRef = useRef<HTMLInputElement>(null);

  const validate = (start: string, end: string) => {
    let err = null;
    if (required && (!start || !end)) {
      err = "Both start and end dates are required.";
    } else if (start && end && start > end) {
      err = "Start date cannot be after end date.";
    } else if ((min && start < min) || (min && end < min)) {
      err = `Dates must be after ${formatDate(min, displayFormat)}`;
    } else if ((max && start > max) || (max && end > max)) {
      err = `Dates must be before ${formatDate(max, displayFormat)}`;
    }
    setError(err);
    if (onError) onError(err);
    return err;
  };

  const triggerStart = () => !disabled && startRef.current?.showPicker?.();
  const triggerEnd = () => !disabled && endRef.current?.showPicker?.();

  const handleStartChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newStart = e.target.value;
    setStartTouched(true);
    onChange(newStart, endDate);
    validate(newStart, endDate);
  };

  const handleEndChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newEnd = e.target.value;
    setEndTouched(true);
    onChange(startDate, newEnd);
    validate(startDate, newEnd);
  };

  return (
    <div className="w-full relative">
      <label className="block text-sm font-medium text-gray-700 mb-1">{label}</label>

      {/* Display */}
      <div className="flex gap-4">
        {/* Start Date */}
        <div
          className={`w-1/2 px-3 py-2 border rounded-md focus-within:ring-2 relative ${
            error ? "border-red-500 ring-red-200" : "border-gray-300 focus-within:ring-blue-300"
          } ${disabled ? "bg-gray-100 cursor-not-allowed" : "bg-white"}`}
          onClick={triggerStart}
        >
          <span>{startDate ? formatDate(startDate, displayFormat) : "Start Date"}</span>
          <input
            type="date"
            ref={startRef}
            value={startDate}
            min={min}
            max={max}
            disabled={disabled}
            onChange={handleStartChange}
            onBlur={() => setStartTouched(true)}
            className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
          />
        </div>

        {/* End Date */}
        <div
          className={`w-1/2 px-3 py-2 border rounded-md focus-within:ring-2 relative ${
            error ? "border-red-500 ring-red-200" : "border-gray-300 focus-within:ring-blue-300"
          } ${disabled ? "bg-gray-100 cursor-not-allowed" : "bg-white"}`}
          onClick={triggerEnd}
        >
          <span>{endDate ? formatDate(endDate, displayFormat) : "End Date"}</span>
          <input
            type="date"
            ref={endRef}
            value={endDate}
            min={min}
            max={max}
            disabled={disabled}
            onChange={handleEndChange}
            onBlur={() => setEndTouched(true)}
            className="absolute top-0 left-0 w-full h-full opacity-0 cursor-pointer"
          />
        </div>
      </div>

      {startDate && endDate && !error && (
        <p className="text-sm text-gray-600 mt-1">
          Selected: {formatDate(startDate, displayFormat)} → {formatDate(endDate, displayFormat)}
        </p>
      )}
      {error && <p className="text-sm text-red-600 mt-1">{error}</p>}
    </div>
  );
};

export default DateRangePicker;
