export function getCurrentFinancialYear(): string {
    const today = new Date();
    let year = today.getFullYear();
    let month = today.getMonth() + 1;

    let fyStart: number, fyEnd: number;
    if (month >= 4) {
      fyStart = year % 100;
      fyEnd = (year + 1) % 100;
    } else {
      fyStart = (year - 1) % 100;
      fyEnd = year % 100;
    }
    return `${fyStart}-${fyEnd}`;
  }