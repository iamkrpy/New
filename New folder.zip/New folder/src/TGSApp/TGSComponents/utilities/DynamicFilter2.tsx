import React, { useState } from "react";
import ValidatedTextInput from "../utilities/ValidationInput0";
import SingleDatePicker from "../utilities/SingleDateRangePicker2";
import DateRangePicker from "../utilities/DateRangePicker1";
import RadioGroup from "../utilities/RadioGroup0";
import CheckboxGroup from "../utilities/CheckboxGroup0";
import DropdownMenu from "./Dropdown3";

interface FilterColumn {
  labelkey?: string;
  accessor: string;
  label: string;
  type: string;
  required?: boolean;
  placeholder?: string;
  minLength?: number;
  maxLength?: number;
  pattern?: RegExp;
  dataSourceUrl?: string;
  displayFormat?: string;
  min?: string;
  max?: string;
  selectionMode?: "single" | "multiple";
  options?: { label: string; value: string }[];
}

interface Props {
  filterColumns: FilterColumn[];
  onFilterApply: (payload: Record<string, string[]>) => void;
}

const DynamicFilter: React.FC<Props> = ({ filterColumns, onFilterApply }) => {
  const [values, setValues] = useState<Record<string, any>>({});
  const [errors, setErrors] = useState<Record<string, boolean>>({});
  const [expanded, setExpanded] = useState<boolean>(true);

  const handleChange = (formKey: string, value: any) => {
    setValues((prev) => ({ ...prev, [formKey]: value }));
  };

  const handleError = (formKey: string, hasError: boolean) => {
    setErrors((prev) => ({ ...prev, [formKey]: hasError }));
  };

  const handleSubmit = () => {
    const hasErrors = Object.values(errors).some((e) => e);
    if (hasErrors) return alert("Please correct validation errors before applying filter.");

    const payload: Record<string, string[]> = {};
    filterColumns.forEach((col) => {
      const formKey = `${col.labelkey || col.accessor}__${col.accessor}`;
      const val = values[formKey];
      const payloadKey = col.labelkey || col.accessor;

      if (val == null || val === "") {
        payload[payloadKey] = [];
      } else if (Array.isArray(val)) {
        payload[payloadKey] = val;
      } else if (typeof val === "object" && val.start && val.end) {
        payload[payloadKey] = [val.start, val.end];
      } else {
        payload[payloadKey] = [val];
      }
    });
    onFilterApply(payload);
  };

  return (
    <div className="border border-gray-200 bg-white rounded-xl shadow-md shadow-green-200 p-4 mb-10">
      {/* Expand / Collapse Button */}
      <div className="flex items-center justify-between mb-10 ">
        <h2 className="text-lg font-semibold rounded-3xl bg-teal-600 text-white p-2 px-6 w-30">Filters
           <span className="font-bold text-sm"> {expanded ? "" : ` - "Hidden"`}</span>
        </h2>
        <button
          className="text-sm px-3 py-1 w-40 bg-blue-100 text-blue-700 rounded hover:bg-blue-200 hover:cursor-pointer transition"
          onClick={() => setExpanded((prev) => !prev)}
        >
          {expanded ? "Hide Filters ▲" : "Show Filters ▼"}
        </button>
      </div>

      {/* Collapsible Filter Grid */}
      <div
        className={`transition-all duration-300 ease-in-out ${
          expanded ? "max-h-[2000px]" : "max-h-0 overflow-hidden"
        }`}
      >
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-6 pb-4">
          {filterColumns.map((col) => {
            const formKey = `${col.labelkey || col.accessor}__${col.accessor}`;
            const commonProps = {
              label: col.label,
              required: col.required,
              placeholder: col.placeholder,
            };

            switch (col.type) {
              case "text":
                return (
                  <ValidatedTextInput
                    key={formKey}
                    {...commonProps}
                    value={values[formKey] || ""}
                    onChange={(val) => handleChange(formKey, val)}
                    minLength={col.minLength}
                    maxLength={col.maxLength}
                    pattern={col.pattern}
                    onErrorChange={(err) => handleError(formKey, err)}
                  />
                );
              case "singledate":
                return (
                  <SingleDatePicker
                    key={formKey}
                    {...commonProps}
                    value={values[formKey] || ""}
                    onChange={(val) => handleChange(formKey, val)}
                    min={col.min}
                    max={col.max}
                    displayFormat={col.displayFormat as any}
                    onError={(err) => handleError(formKey, !!err)}
                  />
                );
              case "daterange":
                return (
                  <DateRangePicker
                    key={formKey}
                    label={col.label}
                    startDate={values[formKey]?.start || ""}
                    endDate={values[formKey]?.end || ""}
                    onChange={(start, end) => handleChange(formKey, { start, end })}
                    min={col.min}
                    max={col.max}
                    displayFormat={col.displayFormat as any}
                    required={col.required}
                    onError={(err) => handleError(formKey, !!err)}
                  />
                );
              case "radio":
                return (
                  <RadioGroup
                    key={formKey}
                    label={col.label}
                    dataSourceUrl={col.dataSourceUrl}
                    options={col.options}
                    selected={values[formKey] || ""}
                    onChange={(val) => handleChange(formKey, val)}
                    required={col.required}
                    onError={(err) => handleError(formKey, err)}
                  />
                );
              case "checkbox":
                return (
                  <CheckboxGroup
                    key={formKey}
                    label={col.label}
                    dataSourceUrl={col.dataSourceUrl}
                    options={col.options}
                    selected={values[formKey] || []}
                    onChange={(val) => handleChange(formKey, val)}
                    required={col.required}
                    onError={(err) => handleError(formKey, err)}
                  />
                );
              case "dropdown":
                return (
                  <DropdownMenu
                    key={formKey}
                    label={col.label}
                    valueKey={col.accessor}
                    labelKey={col.labelkey}
                    dataSourceUrl={col.dataSourceUrl}
                    selectionMode={col.selectionMode}
                    selected={values[formKey] || (col.selectionMode === "multiple" ? [] : "")}
                    onChange={(val) => handleChange(formKey, val)}
                    required={col.required}
                    onError={(err: boolean) => handleError(formKey, err)}
                    placeholder={col.placeholder}
                  />
                );
              default:
                return null;
            }
          })}
        </div>

        {/* Apply Button */}
        <div className="flex justify-end mt-4">
          <button
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition hover:cursor-pointer"
            onClick={handleSubmit}
          >
            Search Data
          </button>
        </div>
      </div>
    </div>
  );
};

export default DynamicFilter;
