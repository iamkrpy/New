import { useState } from "react";
import ConfirmationModal from "../../../MainApp/MainAppComponents/MainAppUtilities/ConfirmationModal";

export default function ExamplePage() {
  const [modalType, setModalType] = useState<"info" | "warning" | "error" | "confirmation" | null>(null);

  return (
    <div className="p-6 space-x-4">
      <button
        className="px-4 py-2 bg-blue-500 text-white rounded"
        onClick={() => setModalType("info")}
      >
        Show Info
      </button>
      <button
        className="px-4 py-2 bg-yellow-500 text-white rounded"
        onClick={() => setModalType("warning")}
      >
        Show Warning
      </button>
      <button
        className="px-4 py-2 bg-red-500 text-white rounded"
        onClick={() => setModalType("error")}
      >
        Show Error
      </button>
      <button
        className="px-4 py-2 bg-gray-700 text-white rounded"
        onClick={() => setModalType("confirmation")}
      >
        Show Confirmation
      </button>

      {modalType && (
        <ConfirmationModal
          isOpen={!!modalType}
          type={modalType}
          message={
            modalType === "info"
              ? "This is just some information."
              : modalType === "warning"
              ? "This is a warning. Please be careful!"
              : modalType === "error"
              ? "An unexpected error occurred."
              : "Are you sure you want to proceed with this action?"
          }
          onClose={() => setModalType(null)}
          onConfirm={() => alert("Confirmed! ✅")}
          height={"auto"}
          width={"20vw"}
          positiveLabel="Approve"
          negativeLabel="Cancel"
        />
      )}
    </div>
  );
}
