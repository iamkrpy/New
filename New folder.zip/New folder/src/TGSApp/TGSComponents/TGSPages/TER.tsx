import { useEffect, useState } from "react";
import axios from "axios";
import { usePageTitle } from "../../../MainApp/MainAppContexts/PageTitleContext";
import DynamicTableData from "../utilities/DynamicTableData25";
// import DynamicFilter from "../utilities/DynamicFilter2";
import { filterColumnsConfig } from "../../TGSConfig/FilterColumnsConfig/DemandPR";
import { tableColumnsConfig } from "../../TGSConfig/TableColumnsConfig/DemandPR";
import AlertDialogue from "../../../MainApp/MainAppUtilities/AlertDialogue";

const TER = () => {
  const { setTitle } = usePageTitle();
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [data, setData] = useState([]);
  const [demandedPRs, setDemandedPRs] = useState<any[]>([]);
  const [showAlert, setShowAlert] = useState(false);
  const [alertProps, setAlertProps] = useState<{
    Head: string;
    Type: string;
    Message: React.ReactNode;
    BtnPos?: string;
    BtnNeg?: string;
    Ret?: (value: string) => string;
  } | null>(null);

  const fetchData = async () => {
    setLoading(true);
    try {
      const response = await axios.post(
        `${import.meta.env.VITE_API_BASE_URL_TGS}/getPRItemsToDemand`,
        {
          procMgr: "500271",
        }
      );
      if (response.data.IsSuccess && Array.isArray(response.data.Data)) {
        setData(response.data.Data);
      } else {
        throw new Error(
          response.data.message || "Invalid data format received."
        );
      }
    } catch (err: any) {
      console.error("API fetch error:", err);
      setError("Failed to load data. Please try again later.");
    } finally {
      setLoading(false);
    }
  };

  const handleAlert = (
    head: string,
    type: string,
    message: React.ReactNode,
    btnPos?: string,
    btnNeg?: string,
    ret?: (value: string) => string
  ) => {
    setAlertProps({
      Head: head,
      Type: type,
      Message: message,
      BtnPos: btnPos,
      BtnNeg: btnNeg,
      Ret: ret,
    });
    setShowAlert(true);
  };

  const handleTransacConfirmation = (value: string): string => {
    if (value === "Ok") {
      setShowAlert(false);
    }
  };

  const handleSelectedRows = (rows: any[]) => {
    setDemandedPRs(rows);
  };

  const handleInsertDemand = async (
    filterPayload: Record<string, any>[] = []
  ) => {
    setLoading(true);
    try {
      const payload = filterPayload.map((row) => ({
        SPR_IND: row.SPR_IND ?? null,
        SPR_IND_ITEM: row.SPR_IND_ITEM ?? null,
        SPR_FY_YR: row.SPR_FY_YR ?? null,
        SDT_LABEL: "D",
        SDT_SENDER: "808316",
        SPR_PROC_MGR: "808345",
        SDT_REMARKS: null,
        SDT_ACTIVE: "Y",
        SDT_CREATED_BY: "808316",
      }));

      const res = await axios.post(
        `${import.meta.env.VITE_API_BASE_URL_TGS}/insertDemandPR`,
        payload
      );
      if (res.data?.IsSuccess) {
        setLoading(false);
        handleAlert(
          "DemandPR",
          "Success",
          <p>
            Selected PRs successfully sent for demand to respective buyers.
          </p>,
          "Ok",
          "",
          handleTransacConfirmation
        );
        await fetchData(); // Refresh full data
      } else {
        setLoading(false);
        handleAlert(
          "DemandPR",
          "Failed",
          <p>
            Selected PRs successfully sent for demand to respective buyers.
          </p>,
          "Ok",
          "",
          handleTransacConfirmation
        );
        console.error("Update failed:", res.data?.message);
      }
    } catch (error) {
      setLoading(false);
      handleAlert(
        "DemandPR",
        "Failed",
        <p>Selected PRs sending for demand to respective buyers failed.</p>,
        "Ok",
        "",
        handleTransacConfirmation
      );
      console.error("API error:", error);
    }
  };

  const handleInsertAlertResponse = (value: string): string => {
    if (value === "Ok") {
      setShowAlert(false);
      handleInsertDemand(demandedPRs);
    }
    if (value === "Cancel") {
      setShowAlert(false);
    }
    console.log(value);
  };

  useEffect(() => {
    setTitle("Techno-Commerical Offer Stage");
    fetchData();
  }, []);

  return (
    <div className="p-4">
      {loading && <p className="text-gray-600">Loading data...</p>}
      {error && <p className="text-red-500">{error}</p>}

      {!loading && !error && (
        <div className="flex-col">
          <DynamicTableData
            columns={tableColumnsConfig}
            data={data}
            selectable={true}
            // visibleColumnCount={6}
            collapsable={true}
            uniqueKeys={["SPR_IND", "SPR_IND_ITEM", "SPR_FY_YR"]}
            editable={false}
            rowsSelected={handleSelectedRows}
            isRowSelectable={(row: { ActiveStatus: string }) =>
              row.ActiveStatus !== "Y"
            }
          />
          <div className="flex justify-end">
            <button
              className="bg-emerald-300 p-2 rounded-xl"
              onClick={() => {
                handleAlert(
                  "DemandPR",
                  "Warning",
                  <p>
                    Selected PRs will be sent for demand to respective buyers.
                    <br />
                    Do you wish to proceed?
                  </p>,
                  "Ok",
                  "Cancel",
                  handleInsertAlertResponse
                );
              }}
            >
              Demand
            </button>
          </div>

          {showAlert && alertProps && (
            <AlertDialogue
              Head={alertProps.Head}
              Type={alertProps.Type}
              Message={alertProps.Message}
              BtnPos={alertProps.BtnPos}
              BtnNeg={alertProps.BtnNeg}
              Ret={alertProps.Ret}
            />
          )}
        </div>
      )}
    </div>
  );
};

export default TER;
