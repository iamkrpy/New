import { useEffect, useState } from "react";
import axios from "axios";
import { usePageTitle } from "../../../MainApp/MainAppContexts/PageTitleContext";
import DynamicTableData from "../utilities/DynamicTableData25";
import DynamicFilter from "../utilities/DynamicFilter2";
import { editColumnsConfig } from "../../TGSConfig/EditColumnsConfig/CatSubCatBuyer";
import { filterColumnsConfig } from "../../TGSConfig/FilterColumnsConfig/CatSubCatBuyer"
import { tableColumnsConfig } from "../../TGSConfig/TableColumnsConfig/CatSubCatBuyer";
import { payloadMapper } from "../../TGSConfig/PayLoadColumnsConfig/CatSubCatBuyer";
import { bulkEditColumnsConfig } from "../../TGSConfig/BulkEditColumnsConfig/CatSubCatBuyer";

const Orders = () => {
  const { setTitle } = usePageTitle();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [filters, setFilters] = useState<any>({});

  useEffect(() => {
    setTitle("Category SubCategory Buyer Data");
    fetchData();
  }, []);

  const fetchData = async (filterPayload: Record<string, any> = {}) => {
    setLoading(true);
    setError("");

    const payload = {
      tcs_catsubcat_id: filterPayload.Code || [],
      tcs_catsubcat_desc: filterPayload.CategorySubCategory || [],
      tcs_ini_proc_mgr: filterPayload.CommercialManager || [],
      tcs_ini_proc_head: filterPayload.CommercialHead || [],
      tcs_sla_pr_po: filterPayload.SLAPRPO || [],
      tcs_sla_ter: filterPayload.SLATER || [],
      tcs_sla_po_grn: filterPayload.SLAPOGRN || [],
      tcs_sla_grn_qa: filterPayload.SLAPOGRNQA || [],
      tcs_create_id: filterPayload.CreatedBy || [],
      tcs_update_id: filterPayload.UpdatedBy || [],
      tcs_create_dt: filterPayload.CreatedDate || [],
      tcs_update_dt: filterPayload.UpdatedDate || [],
      tcs_active: filterPayload.ActiveStatus || [],
    };
    try {
      const response = await axios.post("http://localhost:57730/api/smartprocTGS/getSubcategoryBuyerMapping", payload);
      const apiResult = response.data;
      if (apiResult.IsSuccess && Array.isArray(apiResult.Data)) {
        console.log(apiResult.Data)
        setData(apiResult.Data);
      } else {
        throw new Error(apiResult.message || "Invalid data format received.");
      }
    } catch (err: any) {
      console.error("API fetch error:", err);
      setError("Failed to load data. Please try again later.");
    } finally {
      setLoading(false);
    }
  };
  const extractId = (str: string | null | undefined): string | null => {
  if (!str) return null;
  const match = str.match(/\((\d+)\)/);
  return match ? match[1] : null;
};
  const handleSaveFromChild = async (filterPayload: Record<string, any>[] = []) => {
    try {
         const payload = filterPayload.map(row => ({
      tcs_catsubcat_id: row.Code ?? null,
      tcs_catsubcat_desc: row.CategorySubCategory ?? null,
      tcs_ini_proc_mgr: extractId(row.CommercialManager) ?? null,
      tcs_ini_proc_head: extractId(row.CommercialHead) ?? null,
      tcs_sla_pr_po: row.SLAPRPO ?? null,
      tcs_sla_ter: row.SLATER ?? null,
      tcs_sla_po_grn: row.SLAPOGRN ?? null,
      tcs_sla_grn_qa: row.SLAPOGRNQA ?? null,
      tcs_create_id: extractId(row.CreatedBy) ?? null,
      tcs_update_id: extractId(row.UpdatedBy) ?? null,
      tcs_active: row.ActiveStatus ?? null,
    }));
      const res = await axios.post('http://localhost:57730/api/smartprocTGS/updateSubcategoryBuyerMapping', payload);
      await fetchData();
    //   if (res.data?.isSuccess) {
    //     await fetchData(); // Refresh full data
    //   } else {
    //     console.error("Update failed:", res.data?.message);
    //   }
    } catch (error) {
      console.error("API error:", error);
    }
  };

  return (
    <div className="p-4">
      <DynamicFilter
        filterColumns={filterColumnsConfig}
        onFilterApply={(filters: {} | undefined) => {
          setFilters(filters);
          fetchData(filters);
        }}
      />

      {loading && <p className="text-gray-600">Loading data...</p>}
      {error && <p className="text-red-500">{error}</p>}

      {!loading && !error && (
        <>
          <DynamicTableData
            columns={tableColumnsConfig}
            data={data}
            selectable={true}
            visibleColumnCount={6}
            collapsable={true}
            uniqueKeys={['Code','Version']}
            editable={true}
            onSave={handleSaveFromChild}
            editColumnsConfig = {editColumnsConfig}
            // isRowSelectable={(row: { ActiveStatus: string; }) => row.ActiveStatus !== "Y"}
            BulkUpdatePayloadMapper = {payloadMapper}
            BulkUpdateEditColumnConfig = {bulkEditColumnsConfig}
            apiURL="http://localhost:57730/api/smartprocTGS/updateSubcategoryBuyerMappingBulk"
          />
        </>
      )}
    </div>
  );
};

export default Orders;
