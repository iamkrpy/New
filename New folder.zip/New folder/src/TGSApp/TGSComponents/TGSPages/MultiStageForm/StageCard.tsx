import { Lock, Unlock, ChevronRight } from "lucide-react";
import type { Stage } from "./Stages/types";

interface StageSidebarProps {
  stages: Stage[];
  expandedStage: string | null;
  onToggle: (id: string, locked: boolean) => void;
}

export default function StageSidebar({ stages, expandedStage, onToggle }: StageSidebarProps) {
  return (
    <aside className="w-full md:w-1/4 bg-gray-100 p-4 space-y-2 border-r border-gray-200 overflow-y-auto">
      {stages.map((stage, idx) => {
        const isLocked = idx > 0 && !stages[idx - 1].submitted;
        return (
          <div
            key={stage.id}
            onClick={() => onToggle(stage.id, isLocked)}
            className={`flex items-center justify-between p-3 rounded-lg transition cursor-pointer 
              ${expandedStage === stage.id ? "bg-blue-100" : "bg-white"} 
              ${isLocked ? "opacity-50 cursor-not-allowed" : "hover:bg-blue-50"}`}
          >
            <span className="text-sm font-medium">{stage.name}</span>
            {isLocked ? (
              <Lock className="w-4 h-4 text-gray-400" />
            ) : stage.submitted ? (
              <Unlock className="w-4 h-4 text-green-500" />
            ) : (
              <ChevronRight className="w-4 h-4 text-gray-500" />
            )}
          </div>
        );
      })}
    </aside>
  );
}