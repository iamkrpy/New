import type { Stage } from "./Stages/types"

interface StageNavigationProps {
  stages: Stage[];
  currentStage: number;
  completedStages: number[];
  onStageClick: (stageId: number) => void;
}

export default function StageNavigation({
  stages,
  currentStage,
  completedStages,
  onStageClick,
}: StageNavigationProps) {
  return (
    <div className="flex justify-between items-center relative">
      {stages.map((stage, index) => {
        const isCompleted = completedStages.includes(index);
        const isActive = currentStage === index;

        return (
          <div key={stage.id} className="flex-1 text-center relative cursor-pointer">
            <div
              onClick={() => onStageClick(index)}
              className={`w-8 h-8 mx-auto rounded-full flex items-center justify-center border-2
                ${isActive ? "border-blue-600 bg-blue-100" : ""}
                ${isCompleted && !isActive ? "border-green-600 bg-green-100" : ""}
                ${!isCompleted && !isActive ? "border-gray-300 bg-gray-100 cursor-not-allowed" : ""}
              `}
            >
              {index + 1}
            </div>
            <div className="mt-2 text-sm">{stage.name}</div>

            {index < stages.length - 1 && (
              <div className="absolute top-4 left-full w-full h-1 bg-gray-300">
                <div
                  className={`h-1 bg-blue-600`}
                  style={{ width: `${isCompleted ? 100 : 0}%` }}
                />
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
