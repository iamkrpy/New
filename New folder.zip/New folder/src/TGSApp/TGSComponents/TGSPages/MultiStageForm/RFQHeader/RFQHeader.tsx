import React, { useState } from "react";
import { ChevronDown, ChevronUp } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import DynamicTableData from "../../../utilities/DynamicTableData25";
import { tableColumnsConfig } from "../../../../TGSConfig/TableColumnsConfig/RFQHeader";
import { type RFQData, type RFQItem } from "../MultiStageForm";
import { useAuth } from "../../../../../MainApp/MainAppAuth/AuthContext";

const statusColorMap: Record<string, string> = {
  "RFQ TO BE SUBMITTED": "bg-yellow-200 text-red-800",
  "RFQ APPROVED": "bg-emerald-200 text-emerald-800",
  "RFQ REJECTED": "bg-rose-200 text-rose-800",
  "RFQ IN REVIEW": "bg-blue-200 text-blue-800",
};

interface Props {
  data: RFQData;
  isLocked: boolean;
}

const formatDate = (dateString: string | null) => {
  if (!dateString) return "-";
  try {
    return new Intl.DateTimeFormat("en-US", {
      year: "numeric",
      month: "short",
      day: "2-digit",
      hour: "2-digit",
      minute: "2-digit",
    }).format(new Date(dateString));
  } catch {
    return dateString;
  }
};

export default function RFQHeader({ data, isLocked }: Props) {
  const [collapsed, setCollapsed] = useState(true);
  const { user } = useAuth();

  const getSelectedRowsFromTable = (rows: RFQItem[]) => {
    if (isLocked || !user) return;
    const payload = rows.map((row) => ({
      ...row,
      UserId: user.userId,
      Role: "CM",
    }));
  };

  return (
    <div
      className={`rounded-2xl shadow-xl border border-gray-200 bg-white p-4 space-y-4 transition-all hover:shadow-2xl ${
        isLocked ? "opacity-60 pointer-events-none" : ""
      }`}
    >
      <button
        onClick={() => setCollapsed((prev) => !prev)}
        className="flex flex-col md:flex-row justify-between items-center w-full p-4 rounded-xl border border-gray-200 hover:shadow-lg transition-all focus:outline-none focus:ring-2 focus:ring-indigo-400"
      >
        {collapsed ? (
          <div className="flex flex-wrap gap-2 items-center w-full text-sm">
            <span className="bg-black text-white rounded-full p-3 font-semibold text-3xl">
              <span className="text-xl text-yellow-100">RFQ: </span>
              {data.display}
            </span>
            <span
              className={`bg-gray-200 text-gray-800 rounded-full px-2 py-0.5 blink-bg font-semibold ${
                statusColorMap[data.status] || ""
              }`}
            >
              {`Status: ${data.status}`}
            </span>
            <span className="bg-purple-100 text-purple-700 rounded-full px-2 py-0.5 font-semibold">
              {`Pending: ${data.pendingWith}`}
            </span>
            <ChevronDown className="h-5 w-5 text-gray-700 ml-2" />
          </div>
        ) : (
          <div className="flex flex-col md:flex-row w-full justify-between gap-4">
            <div className="flex flex-col w-full md:w-2/3 gap-3">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="bg-gray-100 text-gray-700 rounded-full px-3 py-1 text-xs font-semibold uppercase">
                  RFQ Number
                </span>
                <span className="bg-black text-white rounded-full px-3 py-1 text-lg font-bold">
                  {data.display}
                </span>
              </div>
              <div className="flex flex-col gap-2 mt-2">
                <div>
                  <span className="bg-gray-100 text-gray-700 rounded-full px-3 py-1 text-xs font-semibold uppercase">
                    Status
                  </span>
                  <div
                    className={`mt-1 px-3 py-1 rounded-full text-sm font-semibold blink-bg ${
                      statusColorMap[data.status] || "bg-gray-200 text-gray-800"
                    }`}
                  >
                    {data.status}
                  </div>
                </div>
                <div>
                  <span className="bg-gray-100 text-gray-700 rounded-full px-3 py-1 text-xs font-semibold uppercase">
                    Pending With
                  </span>
                  <div className="mt-1 px-3 py-1 rounded-full text-sm font-semibold text-purple-700 bg-purple-100">
                    {data.pendingWith}
                  </div>
                </div>
              </div>
            </div>
            <div className="flex flex-col gap-2 w-full md:w-1/3 border rounded-xl p-3 bg-gray-50">
              <div className="flex flex-wrap gap-2 items-center">
                <span className="bg-gray-100 text-gray-700 rounded-full px-2 py-1 text-xs font-semibold uppercase">
                  Created By
                </span>
                <span className="bg-emerald-100 text-emerald-800 rounded-full px-2 py-1 text-sm font-bold">
                  {data.createdBy}
                </span>
              </div>
              <div className="flex flex-wrap gap-2 items-center">
                <span className="bg-gray-100 text-gray-700 rounded-full px-2 py-1 text-xs font-semibold uppercase">
                  Creation Date
                </span>
                <span className="bg-emerald-100 text-emerald-800 rounded-full px-2 py-1 text-sm font-bold">
                  {formatDate(data.createdOn)}
                </span>
              </div>
              <div className="flex flex-wrap gap-2 items-center">
                <span className="bg-gray-100 text-gray-700 rounded-full px-2 py-1 text-xs font-semibold uppercase">
                  Modified By
                </span>
                <span className="bg-blue-100 text-blue-800 rounded-full px-2 py-1 text-sm font-bold">
                  {data.modifiedBy}
                </span>
              </div>
              <div className="flex flex-wrap gap-2 items-center">
                <span className="bg-gray-100 text-gray-700 rounded-full px-2 py-1 text-xs font-semibold uppercase">
                  Modified Date
                </span>
                <span className="bg-blue-100 text-blue-800 rounded-full px-2 py-1 text-sm font-bold">
                  {formatDate(data.modifiedOn)}
                </span>
              </div>
            </div>
            <ChevronUp className="h-6 w-6 text-gray-700 mt-2 md:mt-0" />
          </div>
        )}
      </button>
      <AnimatePresence initial={false}>
        {!collapsed && (
          <motion.div
            key="content"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.35, ease: "easeInOut" }}
            className="overflow-hidden space-y-4"
          >
            {data.items.length > 0 && (
              <DynamicTableData
                columns={tableColumnsConfig}
                data={data.items}
                visibleColumnCount={6}
                collapsable
                onSave={() => {}}
                uniqueKeys={["ItemNo", "IndNo"]}
                rowsSelected={getSelectedRowsFromTable}
              />
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
