import { useState } from "react";
import { DynamicMultiSelect } from "../../../utilities/DynamicMultiSelect";
import type { Vendor } from "./types";
import TGS_API_ENDPOINTS from "../../../../TGSAPI/endPoints";
import axiosInstance from "../../../../TGSAPI/axiosLuceneConfig";

export default function RFQStage() {
  const [selectedVendors, setSelectedVendors] = useState<Vendor[]>([]);

  // POST API Call
  const fetchVendors = async (query: string): Promise<Vendor[]> => {
    if (!query) return [];
  
    try {
      const response = await axiosInstance.get(TGS_API_ENDPOINTS.SearchVendor, {
        params: { query, cnt: 10 },
      });
      return response.data;
    } catch (error) {
      console.error("Error fetching vendors:", error);
      return [];
    }
  };  

  return (
    <div className="space-y-6">
      <DynamicMultiSelect<Vendor>
        label="Vendors"
        fetchOptions={fetchVendors}
        getOptionLabel={(v) => `${v.Id} - ${v.DisplayText}`} // customize display text
        selected={selectedVendors}
        onChange={setSelectedVendors}
      />
    </div>
  );
}
