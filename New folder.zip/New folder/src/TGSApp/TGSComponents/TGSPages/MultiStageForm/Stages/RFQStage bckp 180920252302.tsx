import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { useDropzone } from "react-dropzone";
import type { RFQHeader, RFQItem, Vendor, DueDates } from "./types";
import { ChevronDown } from "lucide-react";

export default function RFQStage() {
  // --- Hardcoded Data ---
  const header: RFQHeader = {
    SP_RFQ_NO: "RFQ1",
    SP_RFQ_FY_YR: "25-26",
    SP_IS_LATEST_VERSION: "Y",
    SP_ACTIVE: "Y",
    StageCode: "RFQTOBESUBMTTD",
    StageName: "RFQ TO BE SUBMITTED",
    StageOrder: 16,
    StageStartDate: "2025-09-18 02:25:32.540",
    StageCloseDate: null,
    Age: "0M 0D 0h 24m",
    Is_Current_Stage: 1,
    Pending_With: "Satyam (912866)",
    NoOfPRs: 1,
    NoOfPRItems: 1,
  };

  const items: RFQItem[] = [
    {
      SPP_ID: 1,
      SPP_RFQ_NO: "RFQ1",
      SPP_ITEM_DESC: "LIMIT SWITCH, BCH ELECTRIC LTD., CUT OFF",
      SPP_SUB_CATEGORY: "ELECTRICAL ITEM",
      SPP_ITEM_QTY: 20,
      SPP_MES: "NOS",
      SPP_MAT_NO: "5956A5075",
      SPP_MAT_GROUP: "256",
      SPP_MAT_DESC: "INSTRUMENTATION",
    },
  ];

  const vendorOptions: Vendor[] = [
    { id: "v1", name: "ABC Electricals", email: "abc@vendor.com", contact: "9876543210" },
    { id: "v2", name: "XYZ Traders", email: "xyz@vendor.com", contact: "9123456780" },
    { id: "v3", name: "TechnoSupplies", email: "techno@vendor.com", contact: "9988776655" },
  ];

  const [selectedVendors, setSelectedVendors] = useState<Vendor[]>([]);
  const [files, setFiles] = useState<File[]>([]);
  const [dueDates, setDueDates] = useState<DueDates>({
    technicalOffer: "",
    commercialOffer: "",
    priceOffer: "",
  });

  // Dropzone
  const { getRootProps, getInputProps } = useDropzone({
    onDrop: (acceptedFiles) => setFiles(acceptedFiles),
  });

  const addVendor = (vendor: Vendor) => {
    if (!selectedVendors.find((v) => v.id === vendor.id)) {
      setSelectedVendors([...selectedVendors, vendor]);
    }
  };

  const removeVendor = (id: string) => {
    setSelectedVendors(selectedVendors.filter((v) => v.id !== id));
  };

  const removeFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="space-y-8"
    >
      {/* Header */}
      <motion.div
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.4 }}
        className="bg-emerald-500 text-white shadow-lg rounded-2xl p-6 flex flex-col sm:flex-row sm:justify-between sm:items-center"
      >
        <div>
          <h2 className="text-3xl font-bold">{header.SP_RFQ_NO}</h2>
          <p className="text-emerald-100">FY: {header.SP_RFQ_FY_YR}</p>
          <p className="text-emerald-100">Created By: {header.Pending_With}</p>
        </div>
        <div className="mt-4 sm:mt-0">
          <span className="px-4 py-2 rounded-full bg-white text-emerald-700 font-semibold shadow">
            {header.StageName}
          </span>
        </div>
      </motion.div>

      {/* PR Items Table */}
      <div className="overflow-x-auto bg-white shadow-lg rounded-2xl">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-blue-500">
            <tr>
              {["PR Item", "Item Description", "Qty", "UOM", "Material No"].map((h) => (
                <th key={h} className="px-4 py-3 text-left text-sm font-semibold text-white">
                  {h}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {items.map((item) => (
              <motion.tr
                key={item.SPP_ID}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3 }}
                className="hover:bg-emerald-50 transition"
              >
                <td className="px-4 py-3">{item.SPP_ID}</td>
                <td className="px-4 py-3">{item.SPP_ITEM_DESC}</td>
                <td className="px-4 py-3">{item.SPP_ITEM_QTY}</td>
                <td className="px-4 py-3">{item.SPP_MES}</td>
                <td className="px-4 py-3">{item.SPP_MAT_NO}</td>
              </motion.tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Vendor Panel - Dropdown + Table */}
      <div className="bg-white shadow-lg rounded-2xl p-6 space-y-4">
        <h3 className="text-lg font-semibold flex items-center gap-2">
          Vendor Panel Suggestion <ChevronDown className="h-5 w-5 text-gray-500" />
        </h3>

        {/* Dropdown */}
        <select
          onChange={(e) => {
            const vendor = vendorOptions.find((v) => v.id === e.target.value);
            if (vendor) addVendor(vendor);
          }}
          className="border p-2 rounded w-full"
        >
          <option value="">Select Vendor</option>
          {vendorOptions.map((v) => (
            <option key={v.id} value={v.id}>
              {v.name}
            </option>
          ))}
        </select>

        {/* Selected Vendors Table */}
        {selectedVendors.length > 0 && (
          <table className="min-w-full border mt-3">
            <thead className="bg-emerald-100">
              <tr>
                <th className="p-2 text-left text-sm font-medium">Vendor</th>
                <th className="p-2 text-left text-sm font-medium">Email</th>
                <th className="p-2 text-left text-sm font-medium">Contact</th>
                <th className="p-2"></th>
              </tr>
            </thead>
            <tbody>
              {selectedVendors.map((vendor) => (
                <tr key={vendor.id} className="hover:bg-emerald-50">
                  <td className="p-2">{vendor.name}</td>
                  <td className="p-2">{vendor.email}</td>
                  <td className="p-2">{vendor.contact}</td>
                  <td className="p-2">
                    <button
                      className="text-red-600 hover:underline"
                      onClick={() => removeVendor(vendor.id)}
                    >
                      Remove
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Document Upload with Remove */}
      <div
        {...getRootProps()}
        className="border-dashed border-2 border-gray-300 p-6 rounded-2xl text-center cursor-pointer bg-gray-50 hover:bg-gray-100 transition"
      >
        <input {...getInputProps()} />
        <p className="text-gray-600">Drag & drop files here, or click to select</p>
      </div>
      {files.length > 0 && (
        <ul className="space-y-2">
          {files.map((file, i) => (
            <li key={i} className="flex justify-between items-center bg-gray-100 p-2 rounded">
              <span>{file.name}</span>
              <button
                className="text-red-500 hover:underline"
                onClick={() => removeFile(i)}
              >
                Remove
              </button>
            </li>
          ))}
        </ul>
      )}

      {/* Due Dates */}
      <div className="bg-white shadow-lg rounded-2xl p-6 grid grid-cols-1 sm:grid-cols-3 gap-4">
        {["technicalOffer", "commercialOffer", "priceOffer"].map((key) => (
          <div key={key}>
            <label className="block text-sm font-medium text-gray-700 capitalize">
              {key.replace(/([A-Z])/g, " $1")} Due
            </label>
            <input
              type="datetime-local"
              value={dueDates[key as keyof DueDates]}
              onChange={(e) =>
                setDueDates({ ...dueDates, [key]: e.target.value })
              }
              className="mt-1 border p-2 rounded w-full focus:ring focus:ring-emerald-200"
            />
          </div>
        ))}
      </div>

      {/* Action Buttons */}
      <div className="flex justify-end gap-4">
        <button className="px-4 py-2 bg-gray-200 rounded-lg hover:bg-gray-300 transition">
          Save Draft
        </button>
        <button className="px-4 py-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition">
          Submit
        </button>
      </div>
    </motion.div>
  );
}
