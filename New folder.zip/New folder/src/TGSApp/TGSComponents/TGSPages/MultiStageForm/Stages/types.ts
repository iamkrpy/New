import type { JSX } from "react";

export interface Stage {
    id: number;           // unique id for the stage
    name: string;         // name to display (e.g., RFQ, PO)
    component: JSX.Element; // the React component for this stage
  }


// Header of the RFQ stage
export interface RFQHeader {
    SP_RFQ_NO: string;               // RFQ Number
    SP_RFQ_FY_YR: string;            // Fiscal Year
    SP_IS_LATEST_VERSION: string;    // 'Y' or 'N'
    SP_ACTIVE: string;                // 'Y' or 'N'
    StageCode: string;                // Current Stage Code
    StageName: string;                // Stage Name
    StageOrder: number;               // Order of the Stage
    StageStartDate: string;           // Start Date
    StageCloseDate: string | null;    // Close Date, optional
    Age: string;                      // Age of stage
    Is_Current_Stage: number;         // 1 if current
    Pending_With: string;             // User pending with
    NoOfPRs: number;                  // Number of PRs
    NoOfPRItems: number;              // Number of PR Items
  }
  
  // Single RFQ Item
  export interface RFQItem {
    SPP_ID: number;                   // Unique ID
    SPP_RFQ_NO: string;               // RFQ number
    SPP_ITEM_DESC: string;            // Item description
    SPP_SUB_CATEGORY: string;         // Sub category
    SPP_ITEM_QTY: number;             // Quantity
    SPP_MES: string;                  // Unit of Measure
    SPP_MAT_NO: string;               // Material Number
    SPP_MAT_GROUP: string;            // Material Group
    SPP_MAT_DESC: string;             // Material Description
    // You can add additional fields as required, e.g.:
    // SPP_STATUS?: string;
    // SPP_PROC_HEAD?: string;
    // ...
  }
  
  // Vendor type for the Vendor Panel
  export interface Vendor {
    Id: string;                       // Unique ID for vendor
    DisplayText: string;                     // Vendor Name
    email?: string;                   // Optional
    contact?: string;                 // Optional
  }
  
  // Due Dates for Technical/Commercial/Price offers
  export interface DueDates {
    technicalOffer: string;           // ISO Date string
    commercialOffer: string;          // ISO Date string
    priceOffer: string;               // ISO Date string
  }
  