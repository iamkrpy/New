import { ChevronDown, ChevronRight } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";
import type { Stage } from "./Stages/types";

interface StageCardProps {
  stage: Stage;
  index: number;
  previousSubmitted: boolean;
  expanded: boolean;
  onToggle: () => void;
  onSubmit: (id: string) => void;
}

export default function StageCard({
  stage,
  previousSubmitted,
  expanded,
  onToggle,
  onSubmit,
}: StageCardProps) {
  if (!previousSubmitted) return null;

  return (
    <div className="bg-white shadow-sm rounded-xl border border-gray-200">
      {/* Stage Header */}
      <div
        className="flex justify-between items-center p-4 cursor-pointer hover:bg-gray-50 transition"
        onClick={onToggle}
      >
        <h2 className="text-lg font-medium text-gray-800">{stage.name}</h2>
        {expanded ? (
          <ChevronDown className="w-5 h-5 text-gray-600" />
        ) : (
          <ChevronRight className="w-5 h-5 text-gray-600" />
        )}
      </div>

      {/* Stage Body */}
      <AnimatePresence>
        {expanded && (
          <motion.div
            className="p-4 border-t border-gray-200 space-y-4"
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.3 }}
          >
            {/* Replace with form fields / components */}
            <p className="text-sm text-gray-700">{stage.content}</p>

            <button
              onClick={() => onSubmit(stage.id)}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition"
            >
              Submit
            </button>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
