import { useState, useEffect, useCallback, useMemo } from "react";
import { getApi as getApiLucene, postApi as postApiLucene, type ApiResponse } from "../../../../TGSAPI/apiLucene";
import { getApi as getApiController, postApi as postApiController } from "../../../../TGSAPI/api";
import DynamicTable from "../../../../TGSComponents/utilities/DynamicTableData25";
import { vendorTableColumnsConfig } from "../../../../TGSConfig/TableColumnsConfig/ProposedVendorPanel";
import { AnimatePresence, motion } from "framer-motion";
import Loader from "../../../../../MainApp/MainAppComponents/MainAppUtilities/Loader";

type Vendor = {
  Code: string;
  Name: string;
  DisplayText: string;
  Id: string;
  [key: string]: any;
};

type VendorSubmitResult = {
  VendorCode: string;
  Status: "Success" | "Failed";
  Message: string;
};

type ProposedVendorPanelProps = {
  suggestionsApi: string;
  vendorDetailsApi: string;
  saveVendorApi: string;
  rfqStatus?: string; // ✅ Add RFQ status prop
  tableColumns?: any[];
  onChange?: (vendors: Vendor[]) => void;
};

export default function ProposedVendorPanel({
  suggestionsApi,
  vendorDetailsApi,
  saveVendorApi,
  rfqStatus = "RFQTOBESUBMTTD",
  tableColumns,
  onChange,
}: ProposedVendorPanelProps) {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Vendor[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [loadingVendors, setLoadingVendors] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selectedRows, setSelectedRows] = useState<Vendor[]>([]);
  const [submissionResults, setSubmissionResults] = useState<VendorSubmitResult[]>([]);

  // ✅ Attachments & Dates
  const [attachments, setAttachments] = useState<File[]>([]);
  const [technicalDate, setTechnicalDate] = useState<string>("");
  const [technicalTime, setTechnicalTime] = useState<string>("");
  const [commercialDate, setCommercialDate] = useState<string>("");
  const [commercialTime, setCommercialTime] = useState<string>("");
  const [priceDate, setPriceDate] = useState<string>("");
  const [priceTime, setPriceTime] = useState<string>("");

  const [dateError, setDateError] = useState<string>("");

  const columns = useMemo(() => vendorTableColumnsConfig, [tableColumns]);
  const rfqNo = "RFQ123", fyYear = "25-26", parameter = "TGS", role = "CM";

  // --- Fetch vendors ---
  const fetchVendors = useCallback(async () => {
    try {
      setLoadingVendors(true);
      const payload = { RFQNo: rfqNo, FYYear: fyYear, Parameter: parameter, Role: role };
      const res: ApiResponse<Vendor[]> = await postApiController(vendorDetailsApi, payload);
      setVendors(res.IsSuccess && res.Data ? res.Data : []);
      onChange?.(res.Data ?? []);
    } catch (err) {
      console.error("Failed to fetch vendor details:", err);
      setVendors([]);
    } finally {
      setLoadingVendors(false);
    }
  }, [vendorDetailsApi, rfqNo, fyYear, parameter, role, onChange]);

  useEffect(() => {
    fetchVendors();
  }, [fetchVendors]);

  // --- Validate Dates ---
  useEffect(() => {
    if (technicalDate || commercialDate || priceDate) {
      const tech = new Date(`${technicalDate}T${technicalTime || "00:00"}`);
      const comm = new Date(`${commercialDate}T${commercialTime || "00:00"}`);
      const price = new Date(`${priceDate}T${priceTime || "00:00"}`);

      if (tech > comm) {
        setDateError("⚠️ Technical Offer Due Date must be before or equal to Commercial Offer Due Date.");
      } else if (comm > price) {
        setDateError("⚠️ Commercial Offer Due Date must be before or equal to Price Offer Due Date.");
      } else {
        setDateError("");
      }
    } else {
      setDateError("");
    }
  }, [technicalDate, commercialDate, priceDate, technicalTime, commercialTime, priceTime]);

  // --- Suggestions ---
  useEffect(() => {
    if (!query.trim()) {
      setSuggestions([]);
      return;
    }
    const handler = setTimeout(async () => {
      try {
        setLoadingSuggestions(true);
        const res: ApiResponse<Vendor[]> = await getApiLucene(`${suggestionsApi}?query=${query}`);
        setSuggestions(res.IsSuccess && res.Data ? res.Data.slice(0, 10) : []);
      } catch (err) {
        console.error(err);
        setSuggestions([]);
      } finally {
        setLoadingSuggestions(false);
      }
    }, 300);

    return () => clearTimeout(handler);
  }, [query, suggestionsApi]);

  const handleSelectSuggestion = useCallback(
    (vendor: Vendor) => {
      if (rfqStatus !== "RFQTOBESUBMTTD") return; // ✅ Block selection if not allowed
      setVendors((prev) => {
        if (prev.some((v) => v.Id === vendor.Id)) return prev;
        const updated = [...prev, vendor];
        onChange?.(updated);
        return updated;
      });
      setQuery("");
      setSuggestions([]);
    },
    [onChange, rfqStatus]
  );

  const handleRemoveVendor = useCallback(
    (id: string) => {
      if (rfqStatus !== "RFQTOBESUBMTTD") return; // ✅ Block removal if not allowed
      setVendors((prev) => {
        const updated = prev.filter((v) => v.Id !== id);
        onChange?.(updated);
        return updated;
      });
      setSelectedRows((prev) => prev.filter((v) => v.Id !== id));
    },
    [onChange, rfqStatus]
  );

  const getSelectedRowsFromTable = useCallback((rows: Vendor[]) => {
    setSelectedRows(rows);
  }, []);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (rfqStatus !== "RFQTOBESUBMTTD") return; // ✅ Block file upload
    if (e.target.files) {
      setAttachments((prev) => [...prev, ...Array.from(e.target.files)]);
    }
  };
  const handleRemoveFile = (index: number) => {
    if (rfqStatus !== "RFQTOBESUBMTTD") return;
    setAttachments((prev) => prev.filter((_, i) => i !== index));
  };

  // --- Save / Submit ---
  const handleSaveOrSubmit = async (isFinal: boolean) => {
    if (rfqStatus !== "RFQTOBESUBMTTD") return; // ✅ Block save/submit
    if (vendors.length === 0) return;
    if (isFinal && (dateError || !technicalDate || !commercialDate || !priceDate)) return;

    try {
      setSaving(true);
      setSubmissionResults([]);

      const payload = {
        vendors: vendors.map((v) => ({
          VendorCode: v.Code,
          VendorName: v.Name,
          VendorEmail: v.Email || "",
          AltEmail: v.AltEmail || "",
          MobileNo: v.MobileNo || "",
          Country: v.Country || "",
          PanNo: v.PanNo || "",
          StarRating: v.StarRating || "",
          VendorScore: v.VendorScore || "",
          BlockData: v.BlockData || "",
          StageId: v.StageId || "",
          Id: v.Id,
        })),
        rfqNo,
        fyYear,
        parameter,
        currentUser: "912866",
        role,
        technicalDueDate: `${technicalDate} ${technicalTime}`,
        commercialDueDate: `${commercialDate} ${commercialTime}`,
        priceDueDate: `${priceDate} ${priceTime}`,
        isFinalSubmission: isFinal,
      };

      const res: ApiResponse<VendorSubmitResult[]> = await postApiController(saveVendorApi, payload);
      if (res.IsSuccess && res.Data) {
        setSubmissionResults(res.Data);
        await fetchVendors();
      }
    } catch (err) {
      console.error("Failed to save vendors:", err);
    } finally {
      setSaving(false);
    }
  };

  const canSubmitFinal = vendors.length > 0 && !dateError && technicalDate && commercialDate && priceDate;

  // ✅ Check if RFQ is locked
  const isLocked = rfqStatus !== "RFQTOBESUBMTTD";

  return (
    <div className="rounded-2xl border border-gray-200 bg-white shadow-lg p-6 space-y-6 max-w-full opacity-100">
      {isLocked && (
        <p className="text-red-600 font-semibold mb-2">
          ⚠️ RFQ submission is locked. Status: <strong>{rfqStatus}</strong>
        </p>
      )}

      {/* SECTION: DUE DATES */}
      <h2 className="text-lg font-semibold text-gray-700 mb-2">📅 Due Dates</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 bg-gradient-to-r from-blue-50 via-purple-50 to-pink-50 p-4 rounded-xl shadow-inner border border-gray-200">
        {["Technical", "Commercial", "Price"].map((label, idx) => {
          const date = idx === 0 ? technicalDate : idx === 1 ? commercialDate : priceDate;
          const setDate = idx === 0 ? setTechnicalDate : idx === 1 ? setCommercialDate : setPriceDate;
          const time = idx === 0 ? technicalTime : idx === 1 ? commercialTime : priceTime;
          const setTime = idx === 0 ? setTechnicalTime : idx === 1 ? setCommercialTime : setPriceTime;
          const color = idx === 0 ? "blue" : idx === 1 ? "purple" : "pink";
          return (
            <div key={label} className="flex flex-col">
              <label className={`text-xs font-semibold text-${color}-700`}>{label} Offer Due</label>
              <div className="flex gap-2">
                <input type="date" value={date} disabled={isLocked} onChange={(e) => setDate(e.target.value)} className="border rounded-lg p-2 w-2/3" />
                <input type="time" value={time} disabled={isLocked} onChange={(e) => setTime(e.target.value)} className="border rounded-lg p-2 w-1/3" />
              </div>
            </div>
          );
        })}
      </div>
      {dateError && <p className="text-red-600 text-sm">{dateError}</p>}

      {/* SECTION: ATTACHMENTS */}
      <h2 className="text-lg font-semibold text-gray-700 mb-2">📎 Attachments</h2>
      <div className="bg-gray-50 border border-dashed border-gray-300 rounded-xl p-4">
        <input type="file" multiple onChange={handleFileChange} disabled={isLocked} />
        {attachments.length > 0 && (
          <ul className="mt-2 space-y-1">
            {attachments.map((file, idx) => (
              <li key={idx} className="flex justify-between text-sm border p-2 rounded-lg bg-white opacity-100">
                {file.name}
                {!isLocked && <button className="text-red-500 text-xs" onClick={() => handleRemoveFile(idx)}>Remove</button>}
              </li>
            ))}
          </ul>
        )}
      </div>

      {/* SECTION: PROPOSED VENDOR PANEL */}
      <h2 className="text-lg font-semibold text-gray-700 mt-4">🏢 Proposed Vendor Panel</h2>

      {/* Search Input */}
      <div className="relative w-full max-w-lg mx-auto">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search vendor by code or name..."
          className="w-full rounded-2xl border border-gray-300 bg-white px-4 py-3 text-sm shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-300 outline-none transition-all duration-200 pr-12"
          disabled={isLocked}
        />
        {loadingSuggestions && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <Loader fullscreen={false} size={20} color="#4ee44e" variant="dualRing" text="" />
          </div>
        )}

        <AnimatePresence>
          {!isLocked && suggestions.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="absolute left-0 right-0 mt-1 max-h-64 overflow-y-auto rounded-xl border border-gray-200 bg-white shadow-lg z-50"
            >
              {suggestions.map((s) => (
                <motion.div
                  key={s.Id}
                  className="cursor-pointer px-4 py-2 hover:bg-blue-50 transition-all flex justify-between items-center"
                  onClick={() => handleSelectSuggestion(s)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <span className="font-medium">{s.DisplayText}</span>
                  <span className="text-gray-400 text-xs">{s.Code}</span>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Vendor Table */}
      {loadingVendors ? (
        <div className="flex justify-center py-6">
          <Loader fullscreen={false} size={30} color="#3b82f6" variant="dualRing" text="Loading vendors..." />
        </div>
      ) : vendors.length > 0 ? (
        <div className="space-y-4 w-full overflow-x-auto opacity-100">
          <DynamicTable
            key={vendors.map((v) => v.Id).join("|")}
            data={vendors}
            columns={columns}
            selectable={!isLocked}
            uniqueKeys={["Code"]}
            rowsSelected={getSelectedRowsFromTable}
            onSave={(updatedRows: Vendor[]) => {
              if (isLocked) return;
              setVendors(updatedRows);
              onChange?.(updatedRows);
            }}
          />

          {!isLocked && selectedRows.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex justify-end space-x-2 mt-2"
            >
              <button
                onClick={() => selectedRows.forEach((row) => handleRemoveVendor(row.Id))}
                className="rounded-xl bg-red-600 px-4 py-2 text-white font-semibold shadow hover:bg-red-700 transition-all duration-200 cursor-pointer"
              >
                Delete Selected ({selectedRows.length})
              </button>
            </motion.div>
          )}
        </div>
      ) : (
        <p className="text-sm text-gray-500 text-center animate-pulse">
          No vendors added yet.
        </p>
      )}

      {/* Action Buttons */}
      <div className="flex justify-end space-x-4">
        <button
          onClick={() => handleSaveOrSubmit(false)}
          disabled={saving || isLocked}
          className={`rounded-xl px-6 py-2 text-white font-semibold shadow transition-all duration-200 ${
            saving || isLocked ? "bg-gray-400 cursor-not-allowed" : "bg-yellow-500 hover:bg-yellow-600"
          }`}
        >
          {saving ? "Saving..." : "Save as Draft"}
        </button>
        <button
          onClick={() => handleSaveOrSubmit(true)}
          disabled={!canSubmitFinal || saving || isLocked}
          className={`rounded-xl px-6 py-2 text-white font-semibold shadow transition-all duration-200 ${
            !canSubmitFinal || isLocked ? "bg-gray-300 cursor-not-allowed" : "bg-green-600 hover:bg-green-700"
          }`}
        >
          {saving ? "Submitting..." : "Final Submit"}
        </button>
      </div>

      {/* Submission Results */}
      {submissionResults.length > 0 && (
        <div className="mt-4 space-y-1">
          {submissionResults.map((res) => (
            <p key={res.VendorCode} className={`text-sm ${res.Status === "Success" ? "text-green-600" : "text-red-600"}`}>
              {res.VendorCode}: {res.Message}
            </p>
          ))}
        </div>
      )}

      {/* Refresh Vendors */}
      <div className="flex justify-end">
        <button onClick={fetchVendors} className="mt-2 text-xs text-blue-600 hover:underline">
          Refresh Vendors
        </button>
      </div>
    </div>
  );
}
