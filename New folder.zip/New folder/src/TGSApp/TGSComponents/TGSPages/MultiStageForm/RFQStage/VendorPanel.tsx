// import { useState } from "react";
// import VendorSearchInput, { Vendor } from "./VendorSearchInput";
// import DynamicDataTable from "../../../../TGSComponents/utilities/DynamicTableData25";
// import { postApi } from "../../../../TGSAPI/api";

// interface VendorPanelProps {
//   onDataChange: (vendors: Vendor[]) => void; // Notify parent RFQStage
// }

// export default function VendorPanel({ onDataChange }: VendorPanelProps) {
//   const [selectedVendors, setSelectedVendors] = useState<Vendor[]>([]);
//   const [saving, setSaving] = useState(false);

//   const handleSelectVendor = (vendor: Vendor) => {
//     if (selectedVendors.some((v) => v.code === vendor.code)) return;
//     const newVendors = [...selectedVendors, vendor];
//     setSelectedVendors(newVendors);
//     onDataChange(newVendors); // notify parent
//   };

//   const handleRemoveVendor = (code: string) => {
//     const newVendors = selectedVendors.filter((v) => v.code !== code);
//     setSelectedVendors(newVendors);
//     onDataChange(newVendors); // notify parent
//   };

//   const handleSave = async () => {
//     if (selectedVendors.length === 0) return;

//     setSaving(true);
//     const result = await postApi("/api/vendors/save", { vendors: selectedVendors });
//     setSaving(false);

//     if (result.IsSuccess) {
//       alert("✅ Vendors saved successfully!");
//     } else {
//       alert("❌ Failed to save: " + result.Message);
//     }
//   };

//   return (
//     <div className="space-y-4 border rounded-xl p-4 bg-white shadow-sm">
//       <VendorSearchInput onSelect={handleSelectVendor} />

//       {selectedVendors.length > 0 && (
//         <>
//           <DynamicDataTable
//             data={selectedVendors}
//             columns={[
//               { key: "code", label: "Vendor Code" },
//               { key: "name", label: "Vendor Name" },
//               {
//                 key: "actions",
//                 label: "Actions",
//                 render: (_: any, row: Vendor) => (
//                   <button
//                     onClick={() => handleRemoveVendor(row.code)}
//                     className="text-red-600 hover:text-red-800"
//                   >
//                     Remove
//                   </button>
//                 ),
//               },
//             ]}
//           />

//           <button
//             onClick={handleSave}
//             disabled={saving}
//             className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50"
//           >
//             {saving ? "Saving..." : "Save"}
//           </button>
//         </>
//       )}
//     </div>
//   );
// }
import React, { useState, useMemo } from "react";
import * as XLSX from "xlsx";
import VendorSearchInput, { Vendor } from "./VendorSearchInput";
import { postApi } from "../../../../TGSAPI/api";

interface VendorPanelProps {
  onDataChange: (vendors: Vendor[]) => void;
}

export default function VendorPanel({ onDataChange }: VendorPanelProps) {
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [saving, setSaving] = useState(false);
  const [search, setSearch] = useState("");

  // --- Add a new vendor ---
  const handleSelectVendor = (vendor: Vendor) => {
    if (vendors.some((v) => v.code === vendor.code)) return;
    const updated = [...vendors, vendor];
    setVendors(updated);
    onDataChange(updated);
  };

  // --- Remove vendor ---
  const handleRemove = (code: string) => {
    const updated = vendors.filter((v) => v.code !== code);
    setVendors(updated);
    onDataChange(updated);
  };

  // --- Edit textbox in a row ---
  const handleInputChange = (code: string, field: keyof Vendor, value: string) => {
    const updated = vendors.map((v) =>
      v.code === code ? { ...v, [field]: value } : v
    );
    setVendors(updated);
    onDataChange(updated);
  };

  // --- Save vendors ---
  const handleSave = async () => {
    if (vendors.length === 0) return;
    setSaving(true);
    const result = await postApi("/api/vendors/save", { vendors });
    setSaving(false);

    if (result.IsSuccess) {
      alert("✅ Vendors saved successfully!");
    } else {
      alert("❌ Failed to save: " + result.Message);
    }
  };

  // --- Export to Excel ---
  const handleExport = () => {
    const worksheet = XLSX.utils.json_to_sheet(vendors);
    const workbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(workbook, worksheet, "Vendors");
    XLSX.writeFile(workbook, "vendors.xlsx");
  };

  // --- Filter vendors ---
  const filteredVendors = useMemo(() => {
    if (!search.trim()) return vendors;
    const s = search.toLowerCase();
    return vendors.filter(
      (v) =>
        v.code.toLowerCase().includes(s) ||
        v.name.toLowerCase().includes(s)
    );
  }, [vendors, search]);

  return (
    <div className="w-full space-y-4 border rounded-xl p-4 bg-white shadow-sm transition-all duration-300">
      {/* Vendor Search */}
      <VendorSearchInput onSelect={handleSelectVendor} />

      {/* Toolbar */}
      {vendors.length > 0 && (
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-2">
          <input
            type="text"
            placeholder="🔍 Search vendors..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full md:w-1/3 px-3 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
          />

          <div className="flex gap-2 justify-end">
            <button
              onClick={handleExport}
              className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition"
            >
              Export Excel
            </button>
            <button
              onClick={handleSave}
              disabled={saving}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition"
            >
              {saving ? "Saving..." : "Save"}
            </button>
          </div>
        </div>
      )}

      {/* Table */}
      {vendors.length > 0 && (
        <div className="overflow-x-auto">
          <table className="min-w-full border border-gray-200 rounded-lg overflow-hidden text-sm">
            <thead className="bg-gray-100 text-gray-700">
              <tr>
                <th className="p-3 text-left border-b">Vendor Code</th>
                <th className="p-3 text-left border-b">Vendor Name</th>
                <th className="p-3 text-left border-b">Remarks</th>
                <th className="p-3 text-center border-b">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredVendors.map((vendor) => (
                <tr
                  key={vendor.code}
                  className="hover:bg-gray-50 transition-colors"
                >
                  <td className="p-3 border-b">{vendor.code}</td>
                  <td className="p-3 border-b">{vendor.name}</td>

                  {/* Editable textbox example */}
                  <td className="p-3 border-b">
                    <input
                      type="text"
                      placeholder="Enter remarks..."
                      value={vendor.remarks || ""}
                      onChange={(e) =>
                        handleInputChange(vendor.code, "remarks", e.target.value)
                      }
                      className="w-full border px-2 py-1 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    />
                  </td>

                  <td className="p-3 text-center border-b">
                    <button
                      onClick={() => handleRemove(vendor.code)}
                      className="text-red-600 hover:text-red-800 font-medium"
                    >
                      Delete
                    </button>
                  </td>
                </tr>
              ))}

              {filteredVendors.length === 0 && (
                <tr>
                  <td
                    colSpan={4}
                    className="text-center py-4 text-gray-500 italic"
                  >
                    No vendors found.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
