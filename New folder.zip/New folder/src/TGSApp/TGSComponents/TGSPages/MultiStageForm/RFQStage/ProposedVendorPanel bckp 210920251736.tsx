// import { useState, useEffect, useCallback, useMemo } from "react";
// import { getApi, type ApiResponse } from "../../../../TGSAPI/apiLucene";
// import DynamicTable from "../../../../TGSComponents/utilities/DynamicTableData25";
// import { vendorTableColumnsConfig } from "../../../../TGSConfig/TableColumnsConfig/ProposedVendorPanel";
// import { X } from "lucide-react";
// import { AnimatePresence, motion } from "framer-motion";
// import Loader from "../../../../../MainApp/MainAppComponents/MainAppUtilities/Loader";

// type Vendor = {
//   Code: string;
//   Name: string;
//   DisplayText: string;
//   Id: string;
//   [key: string]: any;
// };

// type ProposedVendorPanelProps = {
//   suggestionsApi: string;
//   vendorDetailsApi: string;
//   tableColumns?: any[];
//   onChange?: (vendors: Vendor[]) => void;
// };

// export default function ProposedVendorPanel({
//   suggestionsApi,
//   vendorDetailsApi,
//   tableColumns,
//   onChange,
// }: ProposedVendorPanelProps) {
//   const [query, setQuery] = useState("");
//   const [suggestions, setSuggestions] = useState<Vendor[]>([]);
//   const [vendors, setVendors] = useState<Vendor[]>([]);
//   const [loadingSuggestions, setLoadingSuggestions] = useState(false);
//   const [selectedRows, setSelectedRows] = useState<Vendor[]>([]);

//   // Memoized columns to prevent re-renders
//   const columns = useMemo(() => vendorTableColumnsConfig, [tableColumns]);

//   // --- Fetch suggestions (debounced) ---
//   useEffect(() => {
//     const handler = setTimeout(async () => {
//       if (!query.trim()) {
//         setSuggestions([]);
//         return;
//       }
//       try {
//         setLoadingSuggestions(true);
//         const res: ApiResponse<Vendor[]> = await getApi(`${suggestionsApi}?query=${query}`);
//         if (res.IsSuccess && res.Data) {
//           setSuggestions(res.Data.slice(0, 10));
//         } else {
//           setSuggestions([]);
//         }
//       } catch (err) {
//         console.error("Error fetching suggestions:", err);
//         setSuggestions([]);
//       } finally {
//         setLoadingSuggestions(false);
//       }
//     }, 300);

//     return () => clearTimeout(handler);
//   }, [query, suggestionsApi]);

//   // --- Handle selecting vendor from suggestions ---
//   const handleSelectSuggestion = useCallback((vendor: Vendor) => {
//     if (vendors.some((v) => v.Id === vendor.Id)) {
//       setQuery("");
//       setSuggestions([]);
//       return;
//     }

//     setVendors((prev) => {
//       const updated = [...prev, vendor];
//       onChange?.(updated);
//       return updated;
//     });

//     setQuery("");
//     setSuggestions([]);
//   }, [vendors, onChange]);

//   // --- Handle removing vendor ---
//   const handleRemoveVendor = useCallback((id: string) => {
//     console.log(id)
//     setVendors((prev) => {
//       const updated = prev.filter((v) => v.Id !== id);
//       onChange?.(updated);
//       return updated;
//     });
//     // Remove from selected rows if it exists
//     setSelectedRows((prev) => prev.filter((v) => v.Id !== id));
//   }, [onChange]);

//   // --- Handle selected rows from table ---
//   const getSelectedRowsFromTable = useCallback((rows: Vendor[]) => {
//     setSelectedRows(rows);
//   }, []);

//   return (
//     <div className="rounded-2xl border border-gray-200 bg-white shadow-lg p-6 space-y-6">
//       {/* Search Input */}
//       <div className="relative flex justify-center items-center">
//         <span className="font-bold ">Search Vendor : &nbsp;&nbsp;&nbsp;</span>
//    <input
//     value={query}
//     onChange={(e) => setQuery(e.target.value)}
//     placeholder="Search vendor by code or name..."
//     className="w-3xl rounded-2xl border border-gray-300 bg-white px-4 py-3 text-sm shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-300 outline-none transition-all duration-200 pr-10"
//   />
  
//   {/* Loader inside input */}
//   {loadingSuggestions && (
//     <div className="absolute left-180 top-6 transform -translate-y-1/2">
//       <Loader fullscreen={false} size={30} color="#4ee44e" variant="dualRing" text="" />
//     </div>
//   )}

//   {/* Suggestions dropdown */}
//   <AnimatePresence>
//     {suggestions.length > 0 && (
//       <motion.div
//         initial={{ opacity: 0, y: -10 }}
//         animate={{ opacity: 1, y: 0 }}
//         exit={{ opacity: 0, y: -10 }}
//         className="absolute left-0 right-0 mt-1 max-h-64 overflow-y-auto rounded-xl border border-gray-200 bg-white shadow-lg z-10"
//       >
//         {suggestions.map((s) => (
//           <motion.div
//             key={s.Id}
//             className="cursor-pointer px-4 py-2 hover:bg-blue-50 transition-all flex justify-between items-center"
//             onClick={() => handleSelectSuggestion(s)}
//             whileHover={{ scale: 1.02 }}
//             whileTap={{ scale: 0.98 }}
//           >
//             <span className="font-medium">{s.DisplayText}</span>
//             <span className="text-gray-400 text-xs">{s.Code}</span>
//           </motion.div>
//         ))}
//       </motion.div>
//     )}
//   </AnimatePresence>
// </div>


//       {/* Selected Vendors Table */}
//       {vendors.length > 0 ? (
//         <div className="space-y-2 w-7xl mx-auto">
//           <DynamicTable
//           key={vendors.map(v => v.Id).join("|")}
//             data={vendors}
//             columns={columns}
//             selectable
//             uniqueKeys={["Id"]}
//             rowsSelected={getSelectedRowsFromTable}
//             onSave={(updatedRows: Vendor[]) => {
//               setVendors(updatedRows);
//               onChange?.(updatedRows);
//             }}
//           />

//           {/* Delete Selected Vendors */}
//           {selectedRows.length > 0 && (
//             <motion.div
//               initial={{ opacity: 0 }}
//               animate={{ opacity: 1 }}
//               exit={{ opacity: 0 }}
//               className="flex justify-end space-x-2 mt-2"
//             >
//               <button
//                 onClick={() =>
//                   selectedRows.forEach((row) => handleRemoveVendor(row.Id))
//                 }
//                 className="rounded-xl bg-red-600 px-4 py-2 text-white font-semibold shadow hover:bg-red-700 transition-all duration-200"
//               >
//                 Delete Selected ({selectedRows.length})
//               </button>
//             </motion.div>
//           )}
//         </div>
//       ) : (
//         <p className="text-sm text-gray-500 text-center animate-pulse">
//           No vendors added yet.
//         </p>
//       )}
//     </div>
//   );
// }

import { useState, useEffect, useCallback, useMemo } from "react";
import { getApi, type ApiResponse } from "../../../../TGSAPI/apiLucene";
import DynamicTable from "../../../../TGSComponents/utilities/DynamicTableData25";
import { vendorTableColumnsConfig } from "../../../../TGSConfig/TableColumnsConfig/ProposedVendorPanel";
import { AnimatePresence, motion } from "framer-motion";
import Loader from "../../../../../MainApp/MainAppComponents/MainAppUtilities/Loader";

type Vendor = {
  Code: string;
  Name: string;
  DisplayText: string;
  Id: string;
  [key: string]: any;
};

type ProposedVendorPanelProps = {
  suggestionsApi: string;
  vendorDetailsApi: string;
  tableColumns?: any[];
  onChange?: (vendors: Vendor[]) => void;
};

export default function ProposedVendorPanel({
  suggestionsApi,
  vendorDetailsApi,
  tableColumns,
  onChange,
}: ProposedVendorPanelProps) {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Vendor[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [selectedRows, setSelectedRows] = useState<Vendor[]>([]);

  const columns = useMemo(() => vendorTableColumnsConfig, [tableColumns]);

  // --- Fetch suggestions (debounced) ---
  useEffect(() => {
    if (!query.trim()) {
      setSuggestions([]);
      return;
    }
    const handler = setTimeout(async () => {
      try {
        setLoadingSuggestions(true);
        const res: ApiResponse<Vendor[]> = await getApi(`${suggestionsApi}?query=${query}`);
        setSuggestions(res.IsSuccess && res.Data ? res.Data.slice(0, 10) : []);
      } catch (err) {
        console.error(err);
        setSuggestions([]);
      } finally {
        setLoadingSuggestions(false);
      }
    }, 300);

    return () => clearTimeout(handler);
  }, [query, suggestionsApi]);

  // --- Handle selecting vendor from suggestions ---
  const handleSelectSuggestion = useCallback((vendor: Vendor) => {
    setVendors((prev) => {
      if (prev.some((v) => v.Id === vendor.Id)) return prev;
      const updated = [...prev, vendor];
      onChange?.(updated);
      return updated;
    });
    setQuery("");
    setSuggestions([]);
  }, [onChange]);

  // --- Handle removing vendor ---
  const handleRemoveVendor = useCallback((id: string) => {
    setVendors((prev) => {
      const updated = prev.filter((v) => v.Id !== id);
      onChange?.(updated);
      return updated;
    });
    setSelectedRows((prev) => prev.filter((v) => v.Id !== id));
  }, [onChange]);

  const getSelectedRowsFromTable = useCallback((rows: Vendor[]) => {
    setSelectedRows(rows);
  }, []);

  return (
    <div className="rounded-2xl border border-gray-200 bg-white shadow-lg p-6 space-y-6 max-w-full">
      {/* Search Input */}
      <div className="relative w-full max-w-lg mx-auto">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search vendor by code or name..."
          className="w-full rounded-2xl border border-gray-300 bg-white px-4 py-3 text-sm shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-300 outline-none transition-all duration-200 pr-12"
        />
        {/* Loader inside input */}
        {loadingSuggestions && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <Loader fullscreen={false} size={20} color="#4ee44e" variant="dualRing" text="" />
          </div>
        )}

        {/* Suggestions dropdown */}
        <AnimatePresence>
          {suggestions.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="absolute left-0 right-0 mt-1 max-h-64 overflow-y-auto rounded-xl border border-gray-200 bg-white shadow-lg z-50"
            >
              {suggestions.map((s) => (
                <motion.div
                  key={s.Id}
                  className="cursor-pointer px-4 py-2 hover:bg-blue-50 transition-all flex justify-between items-center"
                  onClick={() => handleSelectSuggestion(s)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <span className="font-medium">{s.DisplayText}</span>
                  <span className="text-gray-400 text-xs">{s.Code}</span>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Selected Vendors Table */}
      {vendors.length > 0 ? (
        <div className="space-y-2 w-full overflow-x-auto">
          <DynamicTable
          key={vendors.map(v => v.Id).join("|")}
            data={vendors}
            columns={columns}
            selectable
            uniqueKeys={["Id"]}
            rowsSelected={getSelectedRowsFromTable}
            onSave={(updatedRows: Vendor[]) => {
              setVendors(updatedRows);
              onChange?.(updatedRows);
            }}
          />

          {/* Delete Selected Vendors */}
          {selectedRows.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex justify-end space-x-2 mt-2"
            >
              <button
                onClick={() =>
                  selectedRows.forEach((row) => handleRemoveVendor(row.Id))
                }
                className="rounded-xl bg-red-600 px-4 py-2 text-white font-semibold shadow hover:bg-red-700 transition-all duration-200 cursor-pointer"
              >
                Delete Selected ({selectedRows.length})
              </button>
            </motion.div>
          )}
        </div>
      ) : (
        <p className="text-sm text-gray-500 text-center animate-pulse">
          No vendors added yet.
        </p>
      )}
    </div>
  );
}
