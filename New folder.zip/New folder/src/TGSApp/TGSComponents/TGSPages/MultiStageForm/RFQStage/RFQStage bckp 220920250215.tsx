// import React, { useState, useRef, useEffect } from "react";
// import { motion } from "framer-motion";
// import { CheckCircle, AlertCircle } from "lucide-react";

// interface FieldConfig {
//   name: string;
//   label: string;
//   type: "text" | "textarea" | "date" | "time" | "file" | "checkbox";
//   required?: boolean;
// }

// interface StageConfig {
//   id: string;
//   title: string;
//   mandatory?: boolean;
//   fields: FieldConfig[];
// }

// interface RFQStageProps {
//   stages: StageConfig[];
//   onSubmit: (formData: Record<string, any>) => void;
// }

// const RFQStage: React.FC<RFQStageProps> = ({ stages, onSubmit }) => {
//   const [currentStageIndex, setCurrentStageIndex] = useState(0);
//   const [formData, setFormData] = useState<Record<string, any>>({});
//   const [validationErrors, setValidationErrors] = useState<Record<string, string>>({});
//   const stageRefs = useRef<Record<string, HTMLDivElement | null>>({});

//   const currentStage = stages[currentStageIndex];

//   // ✅ Handle Input Changes
//   const handleChange = (field: FieldConfig, value: any) => {
//     setFormData((prev) => ({ ...prev, [field.name]: value }));
//     setValidationErrors((prev) => {
//       const updated = { ...prev };
//       delete updated[field.name];
//       return updated;
//     });
//   };

//   // ✅ Validation Function
//   const validateStage = (stage: StageConfig) => {
//     const errors: Record<string, string> = {};
//     stage.fields.forEach((field) => {
//       if (field.required && !formData[field.name]) {
//         errors[field.name] = `${field.label} is required`;
//       }
//     });
//     return errors;
//   };

//   // ✅ Scroll to first invalid field
//   const scrollToFirstError = (errors: Record<string, string>) => {
//     if (Object.keys(errors).length > 0) {
//       const firstField = Object.keys(errors)[0];
//       const element = document.getElementById(`field-${firstField}`);
//       if (element) {
//         element.scrollIntoView({ behavior: "smooth", block: "center" });
//       }
//     }
//   };

//   // ✅ Save Progress
//   const handleSave = () => {
//     const errors = validateStage(currentStage);
//     setValidationErrors(errors);
//     if (Object.keys(errors).length > 0) {
//       console.warn("Stage saved but has missing required fields.");
//     }
//   };

//   // ✅ Next Step
//   const handleNext = () => {
//     const errors = validateStage(currentStage);
//     if (Object.keys(errors).length > 0) {
//       setValidationErrors(errors);
//       scrollToFirstError(errors);
//       return;
//     }
//     setCurrentStageIndex((prev) => Math.min(prev + 1, stages.length - 1));
//   };

//   // ✅ Previous Step
//   const handleBack = () => {
//     setCurrentStageIndex((prev) => Math.max(prev - 1, 0));
//   };

//   // ✅ Final Submit
//   const handleSubmit = () => {
//     let allErrors: Record<string, string> = {};
//     stages.forEach((stage) => {
//       allErrors = { ...allErrors, ...validateStage(stage) };
//     });

//     if (Object.keys(allErrors).length > 0) {
//       setValidationErrors(allErrors);
//       scrollToFirstError(allErrors);
//       return;
//     }

//     onSubmit(formData);
//   };

//   // ✅ Dynamic Field Renderer
//   const renderField = (field: FieldConfig) => {
//     const error = validationErrors[field.name];
//     const commonClasses =
//       "w-full p-2 border rounded-md focus:ring-2 focus:ring-emerald-400 focus:outline-none";

//     switch (field.type) {
//       case "textarea":
//         return (
//           <textarea
//             id={`field-${field.name}`}
//             className={`${commonClasses} ${error ? "border-red-500" : "border-gray-300"}`}
//             value={formData[field.name] || ""}
//             onChange={(e) => handleChange(field, e.target.value)}
//           />
//         );
//       case "date":
//       case "time":
//       case "text":
//         return (
//           <input
//             id={`field-${field.name}`}
//             type={field.type}
//             className={`${commonClasses} ${error ? "border-red-500" : "border-gray-300"}`}
//             value={formData[field.name] || ""}
//             onChange={(e) => handleChange(field, e.target.value)}
//           />
//         );
//       case "file":
//         return (
//           <input
//             id={`field-${field.name}`}
//             type="file"
//             className={`${commonClasses} ${error ? "border-red-500" : "border-gray-300"}`}
//             onChange={(e) => handleChange(field, e.target.files?.[0])}
//           />
//         );
//       case "checkbox":
//         return (
//           <input
//             id={`field-${field.name}`}
//             type="checkbox"
//             checked={!!formData[field.name]}
//             onChange={(e) => handleChange(field, e.target.checked)}
//             className="h-5 w-5 text-emerald-500"
//           />
//         );
//       default:
//         return null;
//     }
//   };

//   return (
//     <div className="space-y-6 border-2 mt-10 rounded-2xl">
//       {/* ✅ Stepper */}
//       <div className="flex flex-wrap gap-4 justify-center mt-5">
//         {stages.map((stage, index) => (
//           <div
//             key={stage.id}
//             className={`flex items-center gap-2 cursor-pointer ${
//               index === currentStageIndex ? "text-emerald-700 font-bold" : "text-gray-500"
//             }`}
//             onClick={() => setCurrentStageIndex(index)}
//           >
//             {Object.keys(validateStage(stage)).length === 0 &&
//             stage.fields.some((f) => formData[f.name]) ? (
//               <CheckCircle className="text-emerald-500" size={18} />
//             ) : (
//               <AlertCircle className="text-gray-400" size={18} />
//             )}
//             {stage.title}
//           </div>
//         ))}
//       </div>

//       {/* ✅ Current Stage Content */}
//       <motion.div
//         key={currentStage.id}
//         initial={{ opacity: 0, x: 30 }}
//         animate={{ opacity: 1, x: 0 }}
//         exit={{ opacity: 0, x: -30 }}
//         transition={{ duration: 0.3 }}
//         ref={(el) => (stageRefs.current[currentStage.id] = el)}
//         className="bg-white p-4 rounded-xl shadow-md space-y-4"
//       >
//         <h2 className="text-xl font-semibold text-emerald-700">{currentStage.title}</h2>

//         {currentStage.fields.map((field) => (
//           <div key={field.name} className="space-y-1">
//             <label className="block text-gray-700 font-medium">
//               {field.label} {field.required && <span className="text-red-500">*</span>}
//             </label>
//             {renderField(field)}
//             {validationErrors[field.name] && (
//               <p className="text-red-500 text-sm">{validationErrors[field.name]}</p>
//             )}
//           </div>
//         ))}

//         {/* ✅ Action Buttons */}
//         <div className="flex justify-between pt-4">
//           <button
//             onClick={handleBack}
//             disabled={currentStageIndex === 0}
//             className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 disabled:opacity-50"
//           >
//             Back
//           </button>
//           <div className="flex gap-3">
//             <button
//               onClick={handleSave}
//               className="px-4 py-2 rounded-lg bg-yellow-200 hover:bg-yellow-300"
//             >
//               Save
//             </button>
//             {currentStageIndex < stages.length - 1 ? (
//               <button
//                 onClick={handleNext}
//                 className="px-4 py-2 rounded-lg bg-emerald-500 text-white hover:bg-emerald-600"
//               >
//                 Next
//               </button>
//             ) : (
//               <button
//                 onClick={handleSubmit}
//                 className="px-4 py-2 rounded-lg bg-blue-500 text-white hover:bg-blue-600"
//               >
//                 Final Submit
//               </button>
//             )}
//           </div>
//         </div>
//       </motion.div>
//     </div>
//   );
// };

// export default RFQStage;
import TGS_API_ENDPOINTS from "../../../../TGSAPI/endPoints";
import ProposedVendorPanel from "./ProposedVendorPanel";

export default function VendorPage() {
  const columns = [
    { header: "Vendor Code", accessor: "code" },
    { header: "Vendor Name", accessor: "name" },
  ];

  return (
    <div className=" mx-auto p-6">
      <h1 className="text-2xl font-bold mb-4">RFQ Submission</h1>
      <ProposedVendorPanel
        suggestionsApi={TGS_API_ENDPOINTS.SearchVendor}
        saveVendorApi={TGS_API_ENDPOINTS.submitRFQ}
        vendorDetailsApi={TGS_API_ENDPOINTS.getVendorsForRFQ}
        tableColumns={columns}
        rfqStatus="TECHCOMMOFFR"
        onChange={(vendors) => {
          console.log("Vendors list updated:", vendors);
          if (vendors.length === 0) {
            console.log("Table is empty!");
          }
        }}
      />
    </div>
  );
}
