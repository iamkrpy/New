import React from "react";
import ProposedVendorPanel from "./ProposedVendorPanel";
import TGS_API_ENDPOINTS from "../../../../TGSAPI/endPoints";

interface RFQStageProps {
  stages: any[];
  onSubmit: (data: any) => void;
  isLocked: boolean;
  rfqData: any;
  refreshRfqData?: () => void;
  infoModal: {
    open: boolean;
    type: "info" | "success" | "warning" | "error";
    message: string;
  };
  setInfoModal: React.Dispatch<
    React.SetStateAction<{
      open: boolean;
      type: "info" | "success" | "warning" | "error";
      message: string;
    }>>
}

export default function RFQStage({ stages, onSubmit, isLocked, rfqData, refreshRfqData, infoModal, setInfoModal }: RFQStageProps) {
  return (
    <div>
      {/* <h2 className="font-bold text-2xl p-4 bg-amber-300 rounded-4xl text-center">RFQ Stage</h2> */}
      <ProposedVendorPanel
        suggestionsApi={TGS_API_ENDPOINTS.SearchVendor}
        vendorDetailsApi={TGS_API_ENDPOINTS.getVendorsForRFQ}
        saveVendorApi={TGS_API_ENDPOINTS.submitRFQ}
        rfqData={rfqData}
        refreshRfqData={refreshRfqData}
        infoModal={infoModal}
        setInfoModal={setInfoModal}
      />
    </div>
  );
}
