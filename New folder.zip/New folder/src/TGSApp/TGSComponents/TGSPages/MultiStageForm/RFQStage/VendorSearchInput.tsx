import { useState, useEffect } from "react";
import { getApi } from "../../../../TGSAPI/apiLucene";
import TGS_API_ENDPOINTS from "../../../../TGSAPI/endPoints";

interface Vendor {
  code: string;
  name: string;
}

interface VendorSearchInputProps {
  onSelect: (vendor: Vendor) => void;
}

export default function VendorSearchInput({ onSelect }: VendorSearchInputProps) {
  const [query, setQuery] = useState("");
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!query) {
      setVendors([]);
      return;
    }

    const timeout = setTimeout(async () => {
      setLoading(true);
      const result = await getApi<Vendor[]>(TGS_API_ENDPOINTS.SearchVendor, {
        queryParams: { q: query },
      });
      setVendors(result.success ? result.data || [] : []);
      setLoading(false);
    }, 300); // debounce

    return () => clearTimeout(timeout);
  }, [query]);

  return (
    <div className="relative w-full max-w-md">
      <input
        type="text"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        placeholder="Search vendor code or name..."
        className="w-full border rounded-md px-3 py-2 focus:outline-none focus:ring focus:ring-blue-200"
      />

      {loading && <p className="text-sm text-gray-400 mt-1">Searching...</p>}

      {vendors.length > 0 && (
        <ul className="absolute left-0 right-0 bg-white border rounded-md shadow-md mt-1 max-h-48 overflow-y-auto z-50">
          {vendors.map((v) => (
            <li
              key={v.code}
              onClick={() => {
                onSelect(v);
                setQuery("");
                setVendors([]);
              }}
              className="px-3 py-2 hover:bg-blue-100 cursor-pointer"
            >
              {v.code} – {v.name}
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
