import { useState, useEffect, useCallback, useMemo } from "react";
import { getApi as getApiLucene, postApi as postApiLucene, type ApiResponse } from "../../../../TGSAPI/apiLucene";
import { getApi as getApiController, postApi as postApiController } from "../../../../TGSAPI/api";
import DynamicTable from "../../../../TGSComponents/utilities/DynamicTableData25";
import { vendorTableColumnsConfig } from "../../../../TGSConfig/TableColumnsConfig/ProposedVendorPanel";
import { AnimatePresence, motion } from "framer-motion";
import Loader from "../../../../../MainApp/MainAppComponents/MainAppUtilities/Loader";

type Vendor = {
  Code: string;
  Name: string;
  DisplayText: string;
  Id: string;
  [key: string]: any;
};

type VendorSubmitResult = {
  VendorCode: string;
  Status: "Success" | "Failed";
  Message: string;
};

type ProposedVendorPanelProps = {
  suggestionsApi: string;
  vendorDetailsApi: string;
  saveVendorApi: string; // API endpoint for submitting vendors
  tableColumns?: any[];
  onChange?: (vendors: Vendor[]) => void;
};

export default function ProposedVendorPanel({
  suggestionsApi,
  vendorDetailsApi,
  saveVendorApi,
  tableColumns,
  onChange,
}: ProposedVendorPanelProps) {
  const [query, setQuery] = useState("");
  const [suggestions, setSuggestions] = useState<Vendor[]>([]);
  const [vendors, setVendors] = useState<Vendor[]>([]);
  const [loadingSuggestions, setLoadingSuggestions] = useState(false);
  const [loadingVendors, setLoadingVendors] = useState(false);
  const [saving, setSaving] = useState(false);
  const [selectedRows, setSelectedRows] = useState<Vendor[]>([]);
  const [submissionResults, setSubmissionResults] = useState<VendorSubmitResult[]>([]);

  const columns = useMemo(() => vendorTableColumnsConfig, [tableColumns]);
  var rfqNo = 'RFQ123', fyYear = '25-26', parameter = 'TGS', role='CM';

  // --- Fetch vendors from API ---
  const fetchVendors = useCallback(async () => {
    try {
      setLoadingVendors(true);
  
      // Prepare payload for POST API
      const payload = {
        RFQNo: rfqNo,       // e.g., from props or state
        FYYear: fyYear,     // e.g., from props or state
        Parameter: parameter, // e.g., from props or state
        Role: role          // e.g., from props or state
      };
  
      const res: ApiResponse<Vendor[]> = await postApiController(vendorDetailsApi, payload);
      console.log(res)
  
      if (res.IsSuccess && res.Data) {
        setVendors(res.Data);
        onChange?.(res.Data);
      } else {
        setVendors([]);
      }
    } catch (err) {
      console.error("Failed to fetch vendor details:", err);
      setVendors([]);
    } finally {
      setLoadingVendors(false);
    }
  }, [vendorDetailsApi, rfqNo, fyYear, parameter, role, onChange]);
  
  useEffect(() => {
    fetchVendors();
  }, [fetchVendors]);
  

  // --- Fetch suggestions (debounced) ---
  useEffect(() => {
    if (!query.trim()) {
      setSuggestions([]);
      return;
    }
    const handler = setTimeout(async () => {
      try {
        setLoadingSuggestions(true);
        const res: ApiResponse<Vendor[]> = await getApiLucene(`${suggestionsApi}?query=${query}`);
        setSuggestions(res.IsSuccess && res.Data ? res.Data.slice(0, 10) : []);
      } catch (err) {
        console.error(err);
        setSuggestions([]);
      } finally {
        setLoadingSuggestions(false);
      }
    }, 300);

    return () => clearTimeout(handler);
  }, [query, suggestionsApi]);

  // --- Handle selecting vendor from suggestions ---
  const handleSelectSuggestion = useCallback(
    (vendor: Vendor) => {
      setVendors((prev) => {
        if (prev.some((v) => v.Id === vendor.Id)) return prev;
        const updated = [...prev, vendor];
        onChange?.(updated);
        return updated;
      });
      setQuery("");
      setSuggestions([]);
    },
    [onChange]
  );

  // --- Handle removing vendor ---
  const handleRemoveVendor = useCallback(
    (id: string) => {
      setVendors((prev) => {
        const updated = prev.filter((v) => v.Id !== id);
        onChange?.(updated);
        return updated;
      });
      setSelectedRows((prev) => prev.filter((v) => v.Id !== id));
    },
    [onChange]
  );

  const getSelectedRowsFromTable = useCallback((rows: Vendor[]) => {
    setSelectedRows(rows);
  }, []);

  // --- Handle saving vendors ---
  const handleSaveVendors = async () => {
    if (vendors.length === 0) return;

    try {
      setSaving(true);
      setSubmissionResults([]); // clear previous results

      const payload = vendors.map((v) => ({
        VendorCode: v.Code,
        VendorName: v.Name,
        VendorEmail: v.Email || "",
        AltEmail: v.AltEmail || "",
        MobileNo: v.MobileNo || "",
        Country: v.Country || "",
        PanNo: v.PanNo || "",
        StarRating: v.StarRating || "",
        VendorScore: v.VendorScore || "",
        BlockData: v.BlockData || "",
        StageId: v.StageId || "",
        Id: v.Id,
      }));

      const res: ApiResponse<VendorSubmitResult[]> = await postApiController(saveVendorApi, {
        vendors: payload,
        rfqNo: "RFQ123", // replace with actual
        fyYear: "25-26", // replace with actual
        parameter: "TGS", // replace with actual
        currentUser: "912866", // replace with actual
        role: 'CM'
      });
      console.log(res)

      if (res.IsSuccess && res.Data) {
        setSubmissionResults(res.Data);

        // Optionally, refresh the vendor table
        await fetchVendors();
      }
    } catch (err) {
      console.error("Failed to save vendors:", err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="rounded-2xl border border-gray-200 bg-white shadow-lg p-6 space-y-6 max-w-full">
      {/* Search Input */}
      <div className="relative w-full max-w-lg mx-auto">
        <input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search vendor by code or name..."
          className="w-full rounded-2xl border border-gray-300 bg-white px-4 py-3 text-sm shadow-sm focus:border-blue-500 focus:ring-2 focus:ring-blue-300 outline-none transition-all duration-200 pr-12"
        />
        {loadingSuggestions && (
          <div className="absolute right-3 top-1/2 transform -translate-y-1/2">
            <Loader fullscreen={false} size={20} color="#4ee44e" variant="dualRing" text="" />
          </div>
        )}

        <AnimatePresence>
          {suggestions.length > 0 && (
            <motion.div
              initial={{ opacity: 0, y: -5 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -5 }}
              className="absolute left-0 right-0 mt-1 max-h-64 overflow-y-auto rounded-xl border border-gray-200 bg-white shadow-lg z-50"
            >
              {suggestions.map((s) => (
                <motion.div
                  key={s.Id}
                  className="cursor-pointer px-4 py-2 hover:bg-blue-50 transition-all flex justify-between items-center"
                  onClick={() => handleSelectSuggestion(s)}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <span className="font-medium">{s.DisplayText}</span>
                  <span className="text-gray-400 text-xs">{s.Code}</span>
                </motion.div>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* Selected Vendors Table */}
      {loadingVendors ? (
        <div className="flex justify-center py-6">
          <Loader fullscreen={false} size={30} color="#3b82f6" variant="dualRing" text="Loading vendors..." />
        </div>
      ) : vendors.length > 0 ? (
        <div className="space-y-4 w-full overflow-x-auto">
          <DynamicTable
            key={vendors.map((v) => v.Id).join("|")}
            data={vendors}
            columns={columns}
            selectable
            uniqueKeys={["Code"]}
            rowsSelected={getSelectedRowsFromTable}
            onSave={(updatedRows: Vendor[]) => {
              setVendors(updatedRows);
              onChange?.(updatedRows);
            }}
          />

          {/* Delete Selected Vendors */}
          {selectedRows.length > 0 && (
            <motion.div
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex justify-end space-x-2 mt-2"
            >
              <button
                onClick={() => selectedRows.forEach((row) => handleRemoveVendor(row.Id))}
                className="rounded-xl bg-red-600 px-4 py-2 text-white font-semibold shadow hover:bg-red-700 transition-all duration-200 cursor-pointer"
              >
                Delete Selected ({selectedRows.length})
              </button>
            </motion.div>
          )}

          {/* Save Button */}
          <div className="flex justify-end">
            <button
              onClick={handleSaveVendors}
              disabled={saving}
              className={`rounded-xl px-6 py-2 text-white font-semibold shadow transition-all duration-200 ${
                saving ? "bg-gray-400 cursor-not-allowed" : "bg-blue-600 hover:bg-blue-700"
              }`}
            >
              {saving ? "Saving..." : "Submit Vendors"}
            </button>
          </div>

          {/* Submission Results */}
          {submissionResults.length > 0 && (
            <div className="mt-4 space-y-1">
              {submissionResults.map((res) => (
                <p key={res.VendorCode} className={`text-sm ${res.Status === "Success" ? "text-green-600" : "text-red-600"}`}>
                  {res.VendorCode}: {res.Message}
                </p>
              ))}
            </div>
          )}
        </div>
      ) : (
        <p className="text-sm text-gray-500 text-center animate-pulse">
          No vendors added yet.
        </p>
      )}

      {/* Refresh Button */}
      <div className="flex justify-end">
        <button onClick={fetchVendors} className="mt-2 text-xs text-blue-600 hover:underline">
          Refresh Vendors
        </button>
      </div>
    </div>
  );
}
