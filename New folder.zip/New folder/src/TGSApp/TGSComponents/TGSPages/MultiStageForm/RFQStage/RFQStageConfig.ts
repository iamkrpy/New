export const rfqStagesConfig = [
    {
      id: "vendorPanel",
      title: "Vendor Panel Suggestion",
      mandatory: true,
      fields: [
        { name: "vendorNames", label: "Vendor Names", type: "text", required: true },
        { name: "remarks", label: "Remarks", type: "textarea" },
      ],
    },
    {
      id: "dueDate",
      title: "Due Date & Time",
      mandatory: true,
      fields: [
        { name: "dueDate", label: "Due Date", type: "date", required: true },
        { name: "dueTime", label: "Due Time", type: "time", required: true },
      ],
    },
    {
      id: "attachments",
      title: "Attachments Upload",
      fields: [{ name: "documents", label: "Upload File", type: "file" }],
    },
    {
      id: "finalSubmit",
      title: "Final Confirmation",
      mandatory: true,
      fields: [{ name: "confirm", label: "Confirm Submission", type: "checkbox", required: true }],
    },
  ];