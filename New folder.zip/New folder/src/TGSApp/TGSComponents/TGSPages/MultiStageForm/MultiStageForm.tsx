// // import { useEffect, useState, useCallback } from "react";
// // import RFQHeader from "./RFQHeader/RFQHeader";
// // import RFQStage from "./RFQStage/RFQStage";
// // import { usePageTitle } from "../../../../MainApp/MainAppContexts/PageTitleContext";
// // import { useParams } from "react-router-dom";
// // import { postApi } from "../../../TGSAPI/api";
// // import TGS_API_ENDPOINTS from "../../../TGSAPI/endPoints";

// // export interface RFQItem {
// //   PRNo: string;
// //   ItemNo: string;
// //   IndNo: string;
// //   IndFY: string;
// //   Parameter: string;
// //   ItemDesc: string;
// //   ItemQty: string;
// //   MES: string;
// //   MatNo: string;
// //   CreatedBy: string;
// //   CreatedOn: string | null;
// //   ModifiedBy: string;
// //   ModifiedOn: string | null;
// //   StatusCode: string;
// //   StatusDesc: string;
// // }

// // export interface RFQData {
// //   display: string;
// //   rfqNumber: string;
// //   financialYear: string;
// //   parameter: string;
// //   technicalDueDate: Date;
// //   commercialDueDate: Date;
// //   priceDueDate: Date;
// //   status: string;
// //   pendingWith: string;
// //   createdBy: string;
// //   createdOn: string | null;
// //   modifiedBy: string;
// //   modifiedOn: string | null;
// //   items: RFQItem[];
// //   CurrentStatus: string;
// // }

// // export const rfqStagesConfig = [
// //   { key: "RFQTOBESUBMTTD", label: "RFQ TO BE SUBMITTED" },
// //   { key: "TECHCOMMOFFR", label: "TECHNOCOMMERCIAL OFFER AWAITED" },
// //   { key: "TECHOFFR", label: "TECHNICAL OFFER AWAITED" },
// //   { key: "COMMOFFR", label: "COMMERCIAL OFFER AWAITED" },
// //   { key: "PRICEOFFR", label: "PRICE OFFER AWAITED" },
// // ];

// // export default function MultiStageForm() {
// //   const { setTitle } = usePageTitle();
// //   const { rfqNumber, fyYear, parameter } = useParams<{
// //     rfqNumber: string;
// //     fyYear: string;
// //     parameter: string;
// //   }>();

// //   const [rfqData, setRfqData] = useState<RFQData | null>(null);
// //   const [loading, setLoading] = useState(true);
// //   const [error, setError] = useState<string | null>(null);
// //   const [infoModal, setInfoModal] = useState<{
// //     open: boolean;
// //     type: "info" | "warning" | "error" | "success";
// //     message: string;
// //   }>({ open: false, type: "info", message: "" });

// //   const [activeStageKey, setActiveStageKey] = useState<string>("RFQTOBESUBMTTD");

// //   useEffect(() => {
// //     setTitle("RFQ & Stages");
// //   }, [setTitle]);

// //   const fetchRFQData = useCallback(async () => {
// //     try {
// //       setLoading(true);
// //       setError(null);

// //       const payload = { RFQ_NO: rfqNumber, RFQ_FY_YR: fyYear, RFQ_PARAMETER: parameter };
// //       const response = await postApi(TGS_API_ENDPOINTS.GetRFQDetails, payload);

// //       if (!response.IsSuccess) throw new Error(response.Message || "Failed to fetch RFQ data");

// //       const rfqDetails = response.Data?.RFQDetails || {};
// //       const rfqItems = Array.isArray(response.Data?.RFQItems) ? response.Data.RFQItems : [];

// //       setRfqData({
// //         display: rfqDetails.Display || rfqNumber,
// //         rfqNumber: rfqDetails.RFQNumber || "-",
// //         financialYear: rfqDetails.FYYear || "-",
// //         parameter: rfqDetails.Parameter || "-",
// //         technicalDueDate: rfqDetails.TechDueDt,
// //         commercialDueDate: rfqDetails.CommDueDt,
// //         priceDueDate: rfqDetails.PriceDueDt,
// //         status: rfqDetails.CurrentStatusDesc || "-",
// //         pendingWith: rfqDetails.PendingWith || "-",
// //         createdBy: rfqDetails.CreatedBy || "-",
// //         createdOn: rfqDetails.CreationDate || null,
// //         modifiedBy: rfqDetails.ModifiedBy || "-",
// //         modifiedOn: rfqDetails.ModifiedDate || null,
// //         items: rfqItems.map((item: any) => ({
// //           PRNo: item.PRNo,
// //           ItemNo: item.ItemNo,
// //           IndNo: item.IndNo,
// //           IndFY: item.IndFY,
// //           Parameter: item.Parameter,
// //           ItemDesc: item.ItemDesc,
// //           ItemQty: item.ItemQty,
// //           MES: item.MES,
// //           MatNo: item.MatNo,
// //           CreatedBy: item.CreatedBy,
// //           CreatedOn: item.CreatedOn || null,
// //           ModifiedBy: item.ModifiedBy,
// //           ModifiedOn: item.ModifiedOn || null,
// //           StatusCode: item.StatusCode,
// //           StatusDesc: item.StatusDesc,
// //         })),
// //         CurrentStatus: rfqDetails.CurrentStatusCode || "RFQTOBESUBMTTD",
// //       });

// //       setActiveStageKey(rfqDetails.CurrentStatusCode || "RFQTOBESUBMTTD");
// //     } catch (err) {
// //       setError(err instanceof Error ? err.message : "Unknown error");
// //     } finally {
// //       setLoading(false);
// //     }
// //   }, [rfqNumber, fyYear, parameter]);

// //   useEffect(() => {
// //     fetchRFQData();
// //   }, [fetchRFQData]);

// //   const handleSubmit = (formData: Record<string, any>) => {
// //     console.log("✅ Stage Submitted Data:", formData);
// //   };

// //   if (loading) return <div className="p-6 text-center">Loading RFQ Data...</div>;
// //   if (error) return <div className="p-6 text-red-600 text-center">{error}</div>;
// //   if (!rfqData) return <div className="p-6 text-center">No RFQ Data found.</div>;

// //   const currentIndex = rfqStagesConfig.findIndex(s => s.key === rfqData.CurrentStatus);

// //   return (
// //     <div className="flex flex-col md:flex-row min-h-screen bg-gradient-to-r from-emerald-50 via-sky-50 to-emerald-50 p-4">
// //       {/* Sidebar */}
// //       <div className="w-full md:w-64 bg-white shadow-lg rounded-xl p-4 mb-4 md:mb-0">
// //         <h2 className="text-lg font-semibold text-emerald-700 mb-4">Stages</h2>
// //         <ul className="space-y-2">
// //           {rfqStagesConfig.map((stage, index) => {
// //             const isCompleted = index < currentIndex;
// //             const isActive = stage.key === activeStageKey;
// //             return (
// //               <li
// //                 key={stage.key}
// //                 className={`p-3 rounded-lg cursor-pointer font-medium transition-all duration-200 ${
// //                   isActive
// //                     ? "bg-emerald-600 text-white shadow"
// //                     : isCompleted
// //                     ? "bg-green-200 text-green-800"
// //                     : "bg-sky-100 text-sky-800 hover:bg-sky-200"
// //                 }`}
// //                 onClick={() => setActiveStageKey(stage.key)}
// //               >
// //                 {stage.label}
// //               </li>
// //             );
// //           })}
// //         </ul>

// //         {/* Stepper */}
// //         <div className="mt-6">
// //           <h3 className="text-sm font-semibold text-gray-600 mb-2">Progress</h3>
// //           <div className="flex space-x-2 items-center">
// //             {rfqStagesConfig.map((stage, index) => {
// //               const isCompleted = index <= currentIndex;
// //               return (
// //                 <div
// //                   key={stage.key}
// //                   className="flex-1 h-2 rounded-full"
// //                   style={{ backgroundColor: isCompleted ? "#10B981" : "#E5E7EB" }}
// //                 />
// //               );
// //             })}
// //           </div>
// //         </div>
// //       </div>

// //       {/* Main Content */}
// //       <div className="flex-1 md:ml-6 space-y-6">
// //         <RFQHeader data={rfqData} isLocked={false} />

// //         {rfqStagesConfig.map((stage) => {
// //           if (stage.key !== activeStageKey) return null;
// //           return (
// //             <RFQStage
// //               key={stage.key}
// //               stages={rfqStagesConfig}
// //               onSubmit={handleSubmit}
// //               isLocked={false}
// //               rfqData={rfqData}
// //               activeStageKey={activeStageKey}
// //               setActiveStageKey={setActiveStageKey}
// //               infoModal={infoModal}
// //               setInfoModal={setInfoModal}
// //               refreshRfqData={fetchRFQData}
// //             />
// //           );
// //         })}
// //       </div>
// //     </div>
// //   );
// // }
// import { useEffect, useState, useCallback } from "react";
// import RFQHeader from "./RFQHeader/RFQHeader";
// import RFQStage from "./RFQStage/RFQStage";
// import { usePageTitle } from "../../../../MainApp/MainAppContexts/PageTitleContext";
// import { useParams } from "react-router-dom";
// import { postApi } from "../../../TGSAPI/api";
// import TGS_API_ENDPOINTS from "../../../TGSAPI/endPoints";

// // Dummy TechnoCommercial stage component
// function TechnoCommercialOfferStage({
//   onSubmit,
//   rfqData,
// }: {
//   onSubmit: (data: any) => void;
//   rfqData: any;
// }) {
//   const [offerDetails, setOfferDetails] = useState({
//     technoComments: "",
//     commercialComments: "",
//   });

//   const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
//     const { name, value } = e.target;
//     setOfferDetails((prev) => ({ ...prev, [name]: value }));
//   };

//   const handleSubmit = () => {
//     onSubmit(offerDetails);
//     alert("TechnoCommercial Offer Submitted!");
//   };

//   return (
//     <div className="bg-white p-6 rounded-xl shadow-md space-y-4">
//       {/* <h3 className="text-lg font-semibold text-emerald-700">TechnoCommercial Offer</h3>
//       <div className="space-y-2">
//         <label className="block text-gray-700">Technical Comments:</label>
//         <textarea
//           name="technoComments"
//           value={offerDetails.technoComments}
//           onChange={handleChange}
//           className="w-full border border-gray-300 rounded p-2"
//         />
//       </div>
//       <div className="space-y-2">
//         <label className="block text-gray-700">Commercial Comments:</label>
//         <textarea
//           name="commercialComments"
//           value={offerDetails.commercialComments}
//           onChange={handleChange}
//           className="w-full border border-gray-300 rounded p-2"
//         />
//       </div>
//       <button
//         onClick={handleSubmit}
//         className="bg-emerald-600 text-white px-4 py-2 rounded hover:bg-emerald-700"
//       >
//         Submit
//       </button> */}
//       <h2 className="text-2xl text-red-400 font-bold">Releasing soon....</h2>
//     </div>
//   );
// }

// export interface RFQItem {
//   PRNo: string;
//   ItemNo: string;
//   IndNo: string;
//   IndFY: string;
//   Parameter: string;
//   ItemDesc: string;
//   ItemQty: string;
//   MES: string;
//   MatNo: string;
//   CreatedBy: string;
//   CreatedOn: string | null;
//   ModifiedBy: string;
//   ModifiedOn: string | null;
//   StatusCode: string;
//   StatusDesc: string;
// }

// export interface RFQData {
//   display: string;
//   rfqNumber: string;
//   financialYear: string;
//   parameter: string;
//   technicalDueDate: Date;
//   commercialDueDate: Date;
//   priceDueDate: Date;
//   status: string;
//   pendingWith: string;
//   createdBy: string;
//   createdOn: string | null;
//   modifiedBy: string;
//   modifiedOn: string | null;
//   items: RFQItem[];
//   CurrentStatus: string;
// }

// export const rfqStagesConfig = [
//   { key: "RFQTOBESUBMTTD", label: "RFQ TO BE SUBMITTED" },
//   { key: "TECHCOMMOFFR", label: "TECHNOCOMMERCIAL OFFER AWAITED" },
//   { key: "TECHOFFR", label: "TECHNICAL OFFER AWAITED" },
//   { key: "COMMOFFR", label: "COMMERCIAL OFFER AWAITED" },
//   { key: "PRICEOFFR", label: "PRICE OFFER AWAITED" },
// ];

// export default function MultiStageForm() {
//   const { setTitle } = usePageTitle();
//   const { rfqNumber, fyYear, parameter } = useParams<{
//     rfqNumber: string;
//     fyYear: string;
//     parameter: string;
//   }>();

//   const [rfqData, setRfqData] = useState<RFQData | null>(null);
//   const [loading, setLoading] = useState(true);
//   const [error, setError] = useState<string | null>(null);
//   const [infoModal, setInfoModal] = useState<{
//     open: boolean;
//     type: "info" | "warning" | "error" | "success";
//     message: string;
//   }>({ open: false, type: "info", message: "" });

//   const [activeStageKey, setActiveStageKey] = useState<string>("RFQTOBESUBMTTD");

//   useEffect(() => {
//     setTitle("RFQ & Stages");
//   }, [setTitle]);

//   const fetchRFQData = useCallback(async () => {
//     try {
//       setLoading(true);
//       setError(null);

//       const payload = { RFQ_NO: rfqNumber, RFQ_FY_YR: fyYear, RFQ_PARAMETER: parameter };
//       const response = await postApi(TGS_API_ENDPOINTS.GetRFQDetails, payload);

//       if (!response.IsSuccess) throw new Error(response.Message || "Failed to fetch RFQ data");

//       const rfqDetails = response.Data?.RFQDetails || {};
//       const rfqItems = Array.isArray(response.Data?.RFQItems) ? response.Data.RFQItems : [];

//       setRfqData({
//         display: rfqDetails.Display || rfqNumber,
//         rfqNumber: rfqDetails.RFQNumber || "-",
//         financialYear: rfqDetails.FYYear || "-",
//         parameter: rfqDetails.Parameter || "-",
//         technicalDueDate: rfqDetails.TechDueDt,
//         commercialDueDate: rfqDetails.CommDueDt,
//         priceDueDate: rfqDetails.PriceDueDt,
//         status: rfqDetails.CurrentStatusDesc || "-",
//         pendingWith: rfqDetails.PendingWith || "-",
//         createdBy: rfqDetails.CreatedBy || "-",
//         createdOn: rfqDetails.CreationDate || null,
//         modifiedBy: rfqDetails.ModifiedBy || "-",
//         modifiedOn: rfqDetails.ModifiedDate || null,
//         items: rfqItems.map((item: any) => ({
//           PRNo: item.PRNo,
//           ItemNo: item.ItemNo,
//           IndNo: item.IndNo,
//           IndFY: item.IndFY,
//           Parameter: item.Parameter,
//           ItemDesc: item.ItemDesc,
//           ItemQty: item.ItemQty,
//           MES: item.MES,
//           MatNo: item.MatNo,
//           CreatedBy: item.CreatedBy,
//           CreatedOn: item.CreatedOn || null,
//           ModifiedBy: item.ModifiedBy,
//           ModifiedOn: item.ModifiedOn || null,
//           StatusCode: item.StatusCode,
//           StatusDesc: item.StatusDesc,
//         })),
//         CurrentStatus: rfqDetails.CurrentStatusCode || "RFQTOBESUBMTTD",
//       });

//       setActiveStageKey(rfqDetails.CurrentStatusCode || "RFQTOBESUBMTTD");
//     } catch (err) {
//       setError(err instanceof Error ? err.message : "Unknown error");
//     } finally {
//       setLoading(false);
//     }
//   }, [rfqNumber, fyYear, parameter]);

//   useEffect(() => {
//     fetchRFQData();
//   }, [fetchRFQData]);

//   const handleSubmit = (formData: Record<string, any>) => {
//     console.log("✅ Stage Submitted Data:", formData);
//   };

//   if (loading) return <div className="p-6 text-center">Loading RFQ Data...</div>;
//   if (error) return <div className="p-6 text-red-600 text-center">{error}</div>;
//   if (!rfqData) return <div className="p-6 text-center">No RFQ Data found.</div>;

//   const currentIndex = rfqStagesConfig.findIndex(s => s.key === rfqData.CurrentStatus);

//   return (
//     <div className="flex flex-col md:flex-row min-h-screen bg-gradient-to-r from-emerald-50 via-sky-50 to-emerald-50 p-4">
//       {/* Sidebar */}
//       <div className="w-full md:w-64 bg-white shadow-lg rounded-xl p-4 mb-4 md:mb-0">
//         <h2 className="text-lg font-semibold text-emerald-700 mb-4">Stages</h2>
//         <ul className="space-y-2">
//           {rfqStagesConfig.map((stage, index) => {
//             const isCompleted = index < currentIndex;
//             const isActive = stage.key === activeStageKey;
//             const isDisabled = index > currentIndex; // Lock future stages
//             return (
//               <li
//                 key={stage.key}
//                 className={`p-3 rounded-lg cursor-pointer font-medium transition-all duration-200 ${
//                   isActive
//                     ? "bg-emerald-600 text-white shadow"
//                     : isCompleted
//                     ? "bg-green-200 text-green-800"
//                     : isDisabled
//                     ? "bg-gray-200 text-gray-400 cursor-not-allowed"
//                     : "bg-sky-100 text-sky-800 hover:bg-sky-200"
//                 }`}
//                 onClick={() => !isDisabled && setActiveStageKey(stage.key)}
//               >
//                 {stage.label}
//               </li>
//             );
//           })}
//         </ul>

//         {/* Stepper */}
//         <div className="mt-6">
//           <h3 className="text-sm font-semibold text-gray-600 mb-2">Progress</h3>
//           <div className="flex space-x-2 items-center">
//             {rfqStagesConfig.map((stage, index) => {
//               const isCompleted = index <= currentIndex;
//               return (
//                 <div
//                   key={stage.key}
//                   className="flex-1 h-2 rounded-full"
//                   style={{ backgroundColor: isCompleted ? "#10B981" : "#E5E7EB" }}
//                 />
//               );
//             })}
//           </div>
//         </div>
//       </div>

//       {/* Main Content */}
//       <div className="flex-1 md:ml-6 space-y-6">
//         <RFQHeader data={rfqData} isLocked={false} />

//         {rfqStagesConfig.map((stage) => {
//           if (stage.key !== activeStageKey) return null;

//           if (stage.key === "TECHCOMMOFFR") {
//             return (
//               <TechnoCommercialOfferStage
//                 key={stage.key}
//                 onSubmit={handleSubmit}
//                 rfqData={rfqData}
//               />
//             );
//           }

//           return (
//             <RFQStage
//               key={stage.key}
//               stages={rfqStagesConfig}
//               onSubmit={handleSubmit}
//               isLocked={false}
//               rfqData={rfqData}
//               activeStageKey={activeStageKey}
//               setActiveStageKey={setActiveStageKey}
//               infoModal={infoModal}
//               setInfoModal={setInfoModal}
//               refreshRfqData={fetchRFQData}
//             />
//           );
//         })}
//       </div>
//     </div>
//   );
// }
import { useEffect, useState, useCallback } from "react";
import RFQHeader from "./RFQHeader/RFQHeader";
import RFQStage from "./RFQStage/RFQStage";
import { usePageTitle } from "../../../../MainApp/MainAppContexts/PageTitleContext";
import { useParams } from "react-router-dom";
import { postApi } from "../../../TGSAPI/api";
import TGS_API_ENDPOINTS from "../../../TGSAPI/endPoints";
import { useAuth } from "../../../../MainApp/MainAppAuth/AuthContext";

// Dummy TechnoCommercial stage component
function TechnoCommercialOfferStage({
  onSubmit,
  rfqData,
}: {
  onSubmit: (data: any) => void;
  rfqData: any;
}) {
  const [offerDetails, setOfferDetails] = useState({
    technoComments: "",
    commercialComments: "",
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target;
    setOfferDetails((prev) => ({ ...prev, [name]: value }));
  };

  const handleSubmit = () => {
    onSubmit(offerDetails);
    alert("TechnoCommercial Offer Submitted!");
  };

  return (
    <div className="bg-white p-6 rounded-xl shadow-md space-y-4">
      {/* <h3 className="text-lg font-semibold text-emerald-700">TechnoCommercial Offer</h3> */}
      <h2 className="font-bold text-2xl p-4 bg-sky-400 rounded-4xl text-center">Techno-Commercial Stage</h2>

      <h2 className="font-bold text-2xl text-red-500"> Releasing soon....</h2>
      {/* <div className="space-y-2">
        <label className="block text-gray-700">Technical Comments:</label>
        <textarea
          name="technoComments"
          value={offerDetails.technoComments}
          onChange={handleChange}
          className="w-full border border-gray-300 rounded p-2"
        />
      </div>
      <div className="space-y-2">
        <label className="block text-gray-700">Commercial Comments:</label>
        <textarea
          name="commercialComments"
          value={offerDetails.commercialComments}
          onChange={handleChange}
          className="w-full border border-gray-300 rounded p-2"
        />
      </div> */}
      {/* <button
        onClick={handleSubmit}
        className="bg-emerald-600 text-white px-4 py-2 rounded hover:bg-emerald-700"
      >
        Submit
      </button> */}
    </div>
  );
}

// --- Interfaces ---
export interface RFQItem {
  PRNo: string;
  ItemNo: string;
  IndNo: string;
  IndFY: string;
  Parameter: string;
  ItemDesc: string;
  ItemQty: string;
  MES: string;
  MatNo: string;
  CreatedBy: string;
  CreatedOn: string | null;
  ModifiedBy: string;
  ModifiedOn: string | null;
  StatusCode: string;
  StatusDesc: string;
}

export interface RFQData {
  display: string;
  rfqNumber: string;
  financialYear: string;
  parameter: string;
  technicalDueDate: Date;
  commercialDueDate: Date;
  priceDueDate: Date;
  status: string;
  pendingWith: string;
  createdBy: string;
  createdOn: string | null;
  modifiedBy: string;
  modifiedOn: string | null;
  items: RFQItem[];
  CurrentStatus: string;
}

export const rfqStagesConfig = [
  { key: "RFQTOBESUBMTTD", label: "RFQ TO BE SUBMITTED" },
  { key: "TECHCOMMOFFR", label: "TECHNOCOMMERCIAL OFFER AWAITED" },
  { key: "TECHOFFR", label: "TECHNICAL OFFER AWAITED" },
  { key: "COMMOFFR", label: "COMMERCIAL OFFER AWAITED" },
  { key: "PRICEOFFR", label: "PRICE OFFER AWAITED" },
];

export default function MultiStageForm() {
  const { setTitle } = usePageTitle();
  const { rfqNumber, fyYear, parameter } = useParams<{
    rfqNumber: string;
    fyYear: string;
    parameter: string;
  }>();

  const [rfqData, setRfqData] = useState<RFQData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [infoModal, setInfoModal] = useState<{
    open: boolean;
    type: "info" | "warning" | "error" | "success";
    message: string;
  }>({ open: false, type: "info", message: "" });
  const {user} = useAuth()

  const [activeStageKey, setActiveStageKey] = useState<string>("RFQTOBESUBMTTD");
  const [sidebarOpen, setSidebarOpen] = useState(false);

  useEffect(() => setTitle("RFQ & Stages"), [setTitle]);

  const fetchRFQData = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);

      const payload = { RFQ_NO: rfqNumber, RFQ_FY_YR: fyYear, RFQ_PARAMETER: parameter, UserId: user?.userId, Role: "CM" };
      const response = await postApi(TGS_API_ENDPOINTS.GetRFQDetails, payload);

      if (!response.IsSuccess) throw new Error(response.Message || "Failed to fetch RFQ data");

      const rfqDetails = response.Data?.RFQDetails || {};
      const rfqItems = Array.isArray(response.Data?.RFQItems) ? response.Data.RFQItems : [];

      setRfqData({
        display: rfqDetails.Display || rfqNumber,
        rfqNumber: rfqDetails.RFQNumber || "-",
        financialYear: rfqDetails.FYYear || "-",
        parameter: rfqDetails.Parameter || "-",
        technicalDueDate: rfqDetails.TechDueDt,
        commercialDueDate: rfqDetails.CommDueDt,
        priceDueDate: rfqDetails.PriceDueDt,
        status: rfqDetails.CurrentStatusDesc || "-",
        pendingWith: rfqDetails.PendingWith || "-",
        createdBy: rfqDetails.CreatedBy || "-",
        createdOn: rfqDetails.CreationDate || null,
        modifiedBy: rfqDetails.ModifiedBy || "-",
        modifiedOn: rfqDetails.ModifiedDate || null,
        items: rfqItems.map((item: any) => ({
          PRNo: item.PRNo,
          ItemNo: item.ItemNo,
          IndNo: item.IndNo,
          IndFY: item.IndFY,
          Parameter: item.Parameter,
          ItemDesc: item.ItemDesc,
          ItemQty: item.ItemQty,
          MES: item.MES,
          MatNo: item.MatNo,
          CreatedBy: item.CreatedBy,
          CreatedOn: item.CreatedOn || null,
          ModifiedBy: item.ModifiedBy,
          ModifiedOn: item.ModifiedOn || null,
          StatusCode: item.StatusCode,
          StatusDesc: item.StatusDesc,
        })),
        CurrentStatus: rfqDetails.CurrentStatusCode || "RFQTOBESUBMTTD",
      });

      setActiveStageKey(rfqDetails.CurrentStatusCode || "RFQTOBESUBMTTD");
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unknown error");
    } finally {
      setLoading(false);
    }
  }, [rfqNumber, fyYear, parameter]);

  useEffect(() => { fetchRFQData(); }, [fetchRFQData]);

  const handleSubmit = (formData: Record<string, any>) => {
    console.log("✅ Stage Submitted Data:", formData);
  };

  if (loading) return <div className="p-6 text-center">Loading RFQ Data...</div>;
  if (error) return <div className="p-6 text-red-600 text-center">{error}</div>;
  if (!rfqData) return <div className="p-6 text-center">No RFQ Data found.</div>;

  const currentIndex = rfqStagesConfig.findIndex(s => s.key === rfqData.CurrentStatus);

  return (
    <div className="flex flex-col md:flex-row min-h-screen bg-gradient-to-r from-emerald-50 via-sky-50 to-emerald-50 p-4">
      {/* Sidebar */}
      <div className="md:w-64 w-full mb-4 md:mb-0">
        {/* Mobile Dropdown */}
        <div className="md:hidden mb-4">
          <select
            className="w-full border border-gray-300 rounded p-2"
            value={activeStageKey}
            onChange={(e) => setActiveStageKey(e.target.value)}
          >
            {rfqStagesConfig.map((stage, index) => {
              const isDisabled = index > currentIndex;
              return (
                <option key={stage.key} value={stage.key} disabled={isDisabled}>
                  {stage.label}
                </option>
              );
            })}
          </select>
        </div>

        {/* Desktop Sidebar */}
        <div className="hidden md:block bg-white shadow-lg rounded-xl p-4">
          <h2 className="text-lg font-semibold text-emerald-700 mb-4">Stages</h2>
          <ul className="space-y-2">
            {rfqStagesConfig.map((stage, index) => {
              const isCompleted = index < currentIndex;
              const isActive = stage.key === activeStageKey;
              const isDisabled = index > currentIndex; // Lock future stages
              return (
                <li
                  key={stage.key}
                  className={`p-3 rounded-lg cursor-pointer font-medium transition-all duration-200 ${
                    isActive
                      ? "bg-emerald-600 text-white shadow"
                      : isCompleted
                      ? "bg-green-200 text-green-800"
                      : isDisabled
                      ? "bg-gray-200 text-gray-400 cursor-not-allowed"
                      : "bg-sky-100 text-sky-800 hover:bg-sky-200"
                  }`}
                  onClick={() => !isDisabled && setActiveStageKey(stage.key)}
                >
                  {stage.label}
                </li>
              );
            })}
          </ul>

          {/* Stepper */}
          <div className="mt-6">
            <h3 className="text-sm font-semibold text-gray-600 mb-2">Progress</h3>
            <div className="flex space-x-2 items-center">
              {rfqStagesConfig.map((stage, index) => {
                const isCompleted = index <= currentIndex;
                return (
                  <div
                    key={stage.key}
                    className="flex-1 h-2 rounded-full"
                    style={{ backgroundColor: isCompleted ? "#10B981" : "#E5E7EB" }}
                  />
                );
              })}
            </div>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="flex-1 md:ml-6 space-y-6 min-h-screen overflow-x-hidden">
        <div className="sticky top-0 z-50 bg-white shadow-md shadow-amber-200 rounded-xl p-4">
        <RFQHeader data={rfqData} isLocked={false} />
        </div>

        {rfqStagesConfig.map((stage) => {
          if (stage.key !== activeStageKey) return null;

          if (stage.key === "TECHCOMMOFFR") {
            return (
              <TechnoCommercialOfferStage
                key={stage.key}
                onSubmit={handleSubmit}
                rfqData={rfqData}
              />
            );
          }

          return (
            <RFQStage
              key={stage.key}
              stages={rfqStagesConfig}
              onSubmit={handleSubmit}
              isLocked={false}
              rfqData={rfqData}
              activeStageKey={activeStageKey}
              setActiveStageKey={setActiveStageKey}
              infoModal={infoModal}
              setInfoModal={setInfoModal}
              refreshRfqData={fetchRFQData}
            />
          );
        })}
      </div>
    </div>
  );
}
