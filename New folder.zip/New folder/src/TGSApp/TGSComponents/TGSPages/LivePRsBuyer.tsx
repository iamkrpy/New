import { useEffect, lazy, Suspense, useState, useCallback, useMemo, useRef } from "react";
import axiosInstance from "../../TGSAPI/axiosConfig";
import { usePageTitle } from "../../../MainApp/MainAppContexts/PageTitleContext";
import Loader from "../../../MainApp/MainAppComponents/MainAppUtilities/Loader";
import TGS_API_ENDPOINTS from "../../TGSAPI/endPoints";

import CreateRFQModal from "../Modals/RFQ_Create";
import { editColumnsConfig } from "../../TGSConfig/EditColumnsConfig/LivePRs";
import { tableColumnsConfig } from "../../TGSConfig/TableColumnsConfig/LivePRsBuyer";
import clsx from "clsx";
import BulkUpload from "../../../MainApp/MainAppComponents/MainAppUtilities/BulkUpload";
import { bulkUploadColumns } from "../../TGSConfig/PayLoadColumnsConfig/BulkUploadConfig";
import { getCurrentFinancialYear } from "../utilities/GetFinancialYear";
import axios from "axios";
import ConfirmationModal from "../../../MainApp/MainAppComponents/MainAppUtilities/ConfirmationModal";

import { useAuth } from "../../../MainApp/MainAppAuth/AuthContext";
import { useNavigate } from "react-router-dom";

const DynamicTableData = lazy(() => import("../utilities/DynamicTableData25"));

// ---------- Types ----------
interface ApiListResponse<T> {
  IsSuccess: boolean;
  Data: T;
  Message?: string;
}

interface PRItem {
  PR_NO: string;
  I_IND_ITEM_NO: string;
  FY_YR: string;
  IS_LATEST_VERSION?: string | number | boolean;
  I_IS_LATEST_VERSION?: string | number | boolean;
  ACTIVE?: string | number | boolean;
  I_ACTIVE?: string | number | boolean;
  [key: string]: any;
}

interface BulkUploadResult {
  rowIndex: number;
  status: "success" | "error";
  remarks: string;
  data: any;
}

const isEmpty = (v: any) => v === undefined || v === null || String(v).trim() === "";

// ---------- Toast Hook ----------
type ToastType = "success" | "error" | "warning";
type ToastItem = { id: number; type: ToastType; msg: string };

function useToasts() {
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const timers = useRef<number[]>([]);

  const toast = useCallback((msg: string, type: ToastType = "success", ttl = 5000) => {
    const id = Date.now() + Math.random();
    const timeoutId = window.setTimeout(() => {
      setToasts((prev) => prev.filter((t) => t.id !== id));
      timers.current = timers.current.filter((t) => t !== timeoutId);
    }, ttl);
    timers.current.push(timeoutId);
    setToasts((prev) => [...prev, { id, type, msg }]);
  }, []);

  useEffect(() => {
    return () => timers.current.forEach((t) => window.clearTimeout(t));
  }, []);

  return { toasts, toast };
}

// ---------- Component ----------
const LivePRsBuyer = () => {
  const { setTitle } = usePageTitle();
  const { user, hasRole } = useAuth();

  const [data, setData] = useState<PRItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");
  const [filters, setFilters] = useState<Record<string, any>>({});
  const [selectedRows, setSelectedRows] = useState<PRItem[]>([]);
  const [selectAllFiltered, setSelectAllFiltered] = useState(false);
  const [actionBusy, setActionBusy] = useState(false);

  const [isCreateRFQOpen, setIsCreateRFQOpen] = useState(false);
  const [isBulkUploadOpen, setIsBulkUploadOpen] = useState(false);

  const { toasts, toast } = useToasts();

  const effectiveSelection = useMemo(() => (selectAllFiltered ? data : selectedRows), [selectAllFiltered, data, selectedRows]);
  const selectionCount = effectiveSelection.length;
  const toolbarDisabled = actionBusy || loading;

  const [infoModal, setInfoModal] = useState<{
    open: boolean;
    type: "info" | "warning" | "error" | "success";
    message: string;
  }>({ open: false, type: "info", message: "" });
  const navigate = useNavigate();

  // ---------- Title ----------
  useEffect(() => setTitle("Consolidated PR View - Buyer"), [setTitle]);

  // ---------- Authorization Check ----------
  useEffect(() => {
    if (!loading) {
    if (!user) return;
    if (!hasRole("CM")) {
      setTitle("Dashboard")
      navigate("/", { replace: true });
      setInfoModal({
        open: true,
        type: "error",
        message: "You do not have the CM role to access this page.",
      });
    }
  }
  }, [user, hasRole]);

  // ---------- Fetch Data ----------
  const fetchData = useCallback(
    async (filterPayload: Record<string, any> = {}) => {
      if (!user || !hasRole("CM")) return;
      const controller = new AbortController();
      setLoading(true);
      setError("");
      try {
        const payload = { ...filterPayload, UserId: user.userId, Role: "CM" };
        const response = await axiosInstance.post<ApiListResponse<PRItem[]>>(
          TGS_API_ENDPOINTS.getConsolidatedIndentItems,
          payload,
          { signal: controller.signal }
        );
        if (response.data?.IsSuccess && Array.isArray(response.data.Data)) {
          setData(response.data.Data);
          if (selectAllFiltered) setSelectedRows(response.data.Data);
        } else {
          throw new Error(response.data?.Message || "Invalid data received.");
        }
      } catch (err: any) {
        if (!axios.isCancel?.(err)) {
          setError("Failed to load data. Please try again later.");
        }
      } finally {
        setLoading(false);
      }
      return () => controller.abort();
    },
    [selectAllFiltered, user, hasRole]
  );

  useEffect(() => {
    let cancel: (() => void) | undefined;
    (async () => (cancel = await fetchData(filters)))();
    return () => cancel?.();
  }, [fetchData, filters]);

  const getSelectedRowsFromTable = useCallback((rows: PRItem[]) => {
    setSelectedRows(rows);
    setSelectAllFiltered(false);
  }, []);

  // ---------- RFQ Validation ----------
  const validateRfqNumber = useCallback(async (RFQ_NO: string, RFQ_FY_YR: string) => {
    if (!user) return { isValid: false, message: "Unauthorized" };
    try {
      const payload = { RFQ_NO, RFQ_FY_YR, UserId: user.userId, Role: "CM" };
      const res = await axiosInstance.post<ApiListResponse<unknown>>(TGS_API_ENDPOINTS.checkRFQExistence, payload);
      return { isValid: !!res.data.IsSuccess, message: res.data.Message };
    } catch {
      return { isValid: false, message: "Failed to validate RFQ number." };
    }
  }, [user]);

  // ---------- Single RFQ Creation ----------
  const postCreateRFQ = useCallback(
    async (rfqNumber: string, fyYr: string, rows: PRItem[], parameter = "TGS") => {
      if (!user) return { IsSuccess: false, Message: "Unauthorized" };
      const finalFyYr = fyYr?.trim() || getCurrentFinancialYear();
      const prItems = rows.map((r) => ({ PR_NO: r.PR_NO, PR_ITEM: r.I_IND_ITEM_NO }));
      const payload = {
        RFQ_NO: rfqNumber,
        FY_YR: finalFyYr,
        PARAMETER: parameter,
        CREATED_BY: user.userId,
        UserId: user.userId,
        Role: "CM",
        PR_ITEMS: prItems
      };
      const res = await axiosInstance.post<ApiListResponse<any>>(TGS_API_ENDPOINTS.SingleRFQCreation, payload);
      return res.data;
    },
    [user]
  );

  const handleCreateRFQ = useCallback(
    async (rfqNumber: string, fyYr: string, parameter?: string) => {
      if (actionBusy) return { success: false, message: "Action in progress" };
      if (!user) return { success: false, message: "Unauthorized" };
      setActionBusy(true);
      try {
        if (!effectiveSelection.length)
          return setInfoModal({ open: true, type: "error", message: "Please select at least one PR line item." });
        if (isEmpty(rfqNumber))
          return setInfoModal({ open: true, type: "error", message: "Please enter a RFQ number." });
        const { isValid, message } = await validateRfqNumber(rfqNumber, fyYr || "");
        if (!isValid) return setInfoModal({ open: true, type: "error", message: message || "This RFQ number is not available." });
        const result = await postCreateRFQ(rfqNumber, fyYr, effectiveSelection, parameter);
        if (result?.IsSuccess) {
          setSelectedRows([]);
          setSelectAllFiltered(false);
          await fetchData(filters);
          return { success: true, message: result.Message || "" };
        } else {
          return { success: false, message: result?.Message };
        }
      } catch {
        setInfoModal({ open: true, type: "error", message: "RFQ creation failed." });
        return { success: false, message: "RFQ creation failed." };
      } finally {
        setActionBusy(false);
      }
    },
    [actionBusy, effectiveSelection, validateRfqNumber, postCreateRFQ, fetchData, filters, user]
  );

  const createRfqFromModal = useCallback(
    async (rfqNumber: string, fyYr: string): Promise<{ success: boolean; message?: string }> => {
      if (!user) {
        setInfoModal({ open: true, type: "error", message: "Unauthorized" });
        return { success: false, message: "Unauthorized" };
      }
  
      // We call handleCreateRFQ and always return its result
      const result = await handleCreateRFQ(rfqNumber, fyYr);
      // Ensure a fallback object in case handleCreateRFQ somehow returns void
      return result ?? { success: false, message: "Unknown error" };
    },
    [handleCreateRFQ, user]
  );
  

  // ---------- Bulk Upload ----------
  const handleBulkUpload = useCallback(
    async (rows: Record<string, any>[], updateResults: (results: BulkUploadResult[]) => void, options?: { fyYr?: string; parameter?: string }) => {
      if (!user) return;
      const fyYr = options?.fyYr || getCurrentFinancialYear();
      const parameter = options?.parameter || "TGS";

      const rfqGroups: Record<string, { PR_NO: string; PR_ITEM: string }[]> = {};
      rows.forEach((r) => {
        const rfqNo = r.RFQ_NO?.trim();
        if (!rfqNo) return;
        if (!rfqGroups[rfqNo]) rfqGroups[rfqNo] = [];
        rfqGroups[rfqNo].push({ PR_NO: r.PR_NO, PR_ITEM: r.PR_ITEM });
      });

      const payload = {
        FY_YR: fyYr,
        PARAMETER: parameter,
        CREATED_BY: user.userId,
        UserId: user.userId,
        Role: "CM",
        RFQs: Object.entries(rfqGroups).map(([RFQ_NO, PR_ITEMS]) => ({ RFQ_NO, PR_ITEMS }))
      };

      try {
        const res = await axiosInstance.post<ApiListResponse<any>>(TGS_API_ENDPOINTS.bulkRFQUploadBuyer, payload);
        const results: BulkUploadResult[] = rows.map((row, idx) => {
          const apiResult = res.data.Data?.find((r: any) => (r.RFQ_NO ?? r.data?.RFQ_NO) === row.RFQ_NO);
          return {
            rowIndex: idx + 2,
            status: apiResult?.Status?.toLowerCase?.() === "error" ? "error" : "success",
            remarks: apiResult?.Message ?? apiResult?.remarks ?? "No response for this row",
            data: apiResult ?? row,
          };
        });
        updateResults(results);
        if (res.data?.IsSuccess) fetchData(filters);
      } catch (err: any) {
        updateResults([{ rowIndex: 0, status: "error", remarks: err.message || "Upload failed", data: {} }]);
      }
    },
    [user, fetchData, filters]
  );

  // ---------- Render ----------
  return (
    <div className="p-4 space-y-4">
      {loading && <Loader fullscreen={false} variant="dualRing" text="Loading... Please wait..." />}

      {!loading && !error && (
        <>
          <div className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
            <p className="text-sm text-gray-500">Select PR line items and create RFQs using the below buttons.</p>
          </div>
          <div className="flex gap-2">
            <button
              onClick={() => setIsCreateRFQOpen(true)}
              disabled={toolbarDisabled || selectionCount === 0}
              className={clsx(
                "px-4 py-2 rounded-xl bg-indigo-600 text-white shadow-sm disabled:opacity-50 disabled:cursor-not-allowed",
                !(toolbarDisabled || selectionCount === 0) && "hover:bg-indigo-700 hover:scale-110 hover:cursor-pointer"
              )}
            >
              RFQ Creation
            </button>
            <button
              onClick={() => setIsBulkUploadOpen(true)}
              className="px-4 py-2 rounded-xl bg-emerald-600 text-white shadow-sm hover:bg-emerald-700 hover:scale-110 hover:cursor-pointer"
            >
              Bulk RFQ Creation
            </button>
          </div>
        </>
      )}

      {error && <p className="text-red-500">{error}</p>}

      <Suspense fallback={<Loader size={40} text="Loading table..." />}>
        {!loading && !error && (
          <div className="bg-white border border-gray-200 rounded-2xl shadow-sm">
            <DynamicTableData
              columns={tableColumnsConfig}
              data={data}
              selectable
              visibleColumnCount={6}
              collapsable
              uniqueKeys={["PR_NO","IND_NO","I_IND_ITEM_NO","FY_YR","IS_LATEST_VERSION","I_IS_LATEST_VERSION","ACTIVE","I_ACTIVE"]}
              onSave={() => {}}
              rowsSelected={getSelectedRowsFromTable}
              editColumnsConfig={editColumnsConfig}
              isRowSelectable={(row: { STATUS?: string; I_STATUS?: string }) => row.STATUS === "RFQTOBEDONE" && row.I_STATUS === "RFQTOBEDONE"}
            />
          </div>
        )}
      </Suspense>

      <CreateRFQModal
        isOpen={isCreateRFQOpen}
        onClose={() => setIsCreateRFQOpen(false)}
        selectedRows={effectiveSelection}
        onCreate={createRfqFromModal}
        onValidateRFQ={validateRfqNumber}
      />

      <BulkUpload
        isOpen={isBulkUploadOpen}
        onClose={() => setIsBulkUploadOpen(false)}
        columns={bulkUploadColumns}
        headerText="Bulk Upload for RFQ Creation"
        uploadButtonText="Upload for RFQ Creation"
        onDataReady={handleBulkUpload}
      />

      <div className="fixed bottom-4 right-4 z-50 space-y-2">
        {toasts.map((t) => (
          <div
            key={t.id}
            className={`rounded-xl px-4 py-3 shadow-lg border backdrop-blur ${
              t.type === "success" ? "bg-emerald-50 border-emerald-200 text-emerald-900" :
              t.type === "error" ? "bg-rose-50 border-rose-200 text-rose-900" :
              "bg-amber-50 border-amber-200 text-amber-900"
            }`}
          >
            {t.msg}
          </div>
        ))}
      </div>

      <ConfirmationModal
        isOpen={infoModal.open}
        type={infoModal.type}
        title={infoModal.type === "error" ? "Error" : infoModal.type === "warning" ? "Warning" : "Information"}
        message={infoModal.message}
        onClose={() => setInfoModal({ ...infoModal, open: false })}
        positiveLabel="OK"
        height="auto"
      />
    </div>
  );
};

export default LivePRsBuyer;
