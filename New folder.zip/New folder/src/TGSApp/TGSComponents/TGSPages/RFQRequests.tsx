import { useEffect, useState, lazy, Suspense, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import axiosInstance from "../../TGSAPI/axiosConfig";
import { usePageTitle } from "../../../MainApp/MainAppContexts/PageTitleContext";
import Loader from "../../../MainApp/MainAppComponents/MainAppUtilities/Loader";
import TGS_API_ENDPOINTS from "../../TGSAPI/endPoints";
import { rfqTableColumnsConfig } from "../../TGSConfig/TableColumnsConfig/RFQRequests";
import { useAuth } from "../../../MainApp/MainAppAuth/AuthContext";

const DynamicTableData = lazy(() => import("../utilities/DynamicTableData25"));

interface ApiListResponse<T> {
  IsSuccess: boolean;
  Data: T;
  Message?: string;
}

interface RFQItem {
  [key: string]: any;
}

const RFQRequestsPage = () => {
  const { setTitle } = usePageTitle();
  const { user, loading: authLoading, hasRole } = useAuth();
  const navigate = useNavigate();

  const [data, setData] = useState<RFQItem[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string>("");

  // ---------- Redirect if user is not CM ----------
  useEffect(() => {
    if (!authLoading) {
      if (!user || !hasRole("CM")) {
        navigate("/dashboard", { replace: true });
      }
    }
  }, [authLoading, user, hasRole, navigate]);

  useEffect(() => setTitle("View RFQ Requests"), [setTitle]);

  const fetchRFQs = useCallback(async () => {
    if (!user) return; // safety check

    setLoading(true);
    setError("");

    // ---------- Build payload with dynamic userId and role ----------
    const payload = {
      RFQ_PARAMETER: "TGS",
      UserId: user.userId,
      Role: "CM", // hardcode as CM for all payloads per your requirement
      RoleForData: "CM",
    };
    console.log(payload)
    try {
      const response = await axiosInstance.post<ApiListResponse<RFQItem[]>>(
        TGS_API_ENDPOINTS.GetRFQRequestsHead,
        payload
      );

      if (response.data?.IsSuccess && Array.isArray(response.data.Data)) {
        setData(response.data.Data);
      } else {
        setError(response.data?.Message || "Failed to fetch RFQ requests.");
      }
    } catch (err: unknown) {
      if (err instanceof Error) setError(err.message);
      else setError("Failed to fetch RFQ requests.");
    } finally {
      setLoading(false);
    }
  }, [user]);

  useEffect(() => {
    fetchRFQs();
  }, [fetchRFQs]);

  return (
    <div className="p-4">
      {loading && (
        <Loader
          fullscreen={false}
          variant="dualRing"
          text="Loading RFQ requests..."
        />
      )}

      {error && <p className="text-red-500">{error}</p>}

      {!loading && !error && data.length > 0 && (
        <Suspense
          fallback={<Loader size={40} text="Loading table..." />}
        >
          <div className="bg-white border border-gray-200 rounded-2xl shadow-sm">
            <DynamicTableData
              columns={rfqTableColumnsConfig}
              data={data}
              visibleColumnCount={rfqTableColumnsConfig.length}
              uniqueKeys={["RFQ_No"]}
              onSave={() => {}}
            />
          </div>
        </Suspense>
      )}

      {!loading && !error && data.length === 0 && (
        <p className="text-gray-500">No RFQ requests found.</p>
      )}
    </div>
  );
};

export default RFQRequestsPage;
