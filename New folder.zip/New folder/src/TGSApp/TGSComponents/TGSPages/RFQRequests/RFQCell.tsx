import { useNavigate } from "react-router-dom";
import { FiExternalLink } from "react-icons/fi";
import TGS_CLIENT_ENDPOINTS from "../../../TGSAPI/frontendEndPoints";

const RFQCell = ({ value, row }: { value: string; row: any }) => {
  const navigate = useNavigate();

  const statusColor = row.StageCode === "RFQTOBESUBMTTD" ? "bg-rose-100" : "bg-emerald-300";
  const statusColor1 = row.StageCode === "RFQTOBESUBMTTD" ? "text-rose-800" : "text-emerald-950";

  const handleClick = (e: React.MouseEvent) => {
    e.stopPropagation();

    if (!row.RFQ_No || !row.FY_Year) {
      console.error("RFQ_No or FY_Year missing", row);
      return;
    }

    navigate(TGS_CLIENT_ENDPOINTS.GetRFQ+`${row.RFQ_No}/${row.FY_Year}/${row.Parameter}`);
  };

  return (
    <button
      type="button"
      onClick={handleClick}
      className={`flex items-center gap-2 font-bold text-md ${statusColor1} ${statusColor} p-2 rounded-3xl cursor-pointer transition-all transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
      title={`View RFQ ${row.RFQ_No}`}
      aria-label={`View RFQ ${row.RFQ_No}`}
    >
      {value}
      <FiExternalLink className="text-shadow-blue-600" size={28} />
    </button>
  );
};

export default RFQCell;
