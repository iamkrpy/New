import { useEffect, useState } from "react";
import axios from "axios";
import { usePageTitle } from "../../../MainApp/MainAppContexts/PageTitleContext";
import DynamicTableData from "../utilities/DynamicTableData25";
import DynamicFilter from "../utilities/DynamicFilter2";
import { editColumnsConfig } from "../../TGSConfig/EditColumnsConfig/LivePRs";
import { filterColumnsConfig } from "../../TGSConfig/FilterColumnsConfig/LivePRs"
import { tableColumnsConfig } from "../../TGSConfig/TableColumnsConfig/LivePRs";

const LivePR = () => {
  const { setTitle } = usePageTitle();
  const [data, setData] = useState([]);
  const [loading, setLoading] = useState<boolean>(false);
  const [error, setError] = useState<string>("");
  const [filters, setFilters] = useState<any>({});

  useEffect(() => {
    setTitle("Consolidated PR View - Head");
    fetchData();
  }, []);

  const fetchData = async (filterPayload: Record<string, any> = {}) => {
    setLoading(true);
    setError("");

    const payload = {
  spr_id: filterPayload.Id || [],
  spr_pr: filterPayload.Pr || [],
  spr_pr_item: filterPayload.PrItem || [],
  spr_fy_yr: filterPayload.FyYr || [],
  spr_version: filterPayload.Version || [],
  spr_purchase_grp: filterPayload.PurchaseGrp || [],
  spr_proc_head: filterPayload.ProcHead || [],
  spr_proc_mgr: filterPayload.ProcMgr || [],
  spr_item_desc: filterPayload.ItemDesc || [],
  spr_item_qty: filterPayload.ItemQty || [],
  spr_mes: filterPayload.Mes || [],
  spr_mat_no: filterPayload.MatNo || [],
  spr_mat_group: filterPayload.MatGroup || [],
  spr_mat_desc: filterPayload.MatDesc || [],
  spr_mat_type: filterPayload.MatType || [],
  spr_kostl: filterPayload.Kostl || [],
  spr_psp_pnr: filterPayload.PspPnr || [],
  spr_nplnr: filterPayload.Nplnr || [],
  spr_aupl: filterPayload.Aupl || [],
  spr_aufnr: filterPayload.Aufnr || [],
  spr_loekz: filterPayload.Loekz || [],
  spr_knttp: filterPayload.Knttp || [],
  spr_order_no: filterPayload.OrderNo || [],
  spr_order_status: filterPayload.OrderStatus || [],
  spr_order_item_no: filterPayload.OrderItemNo || [],
  spr_wbs: filterPayload.Wbs || [],
  spr_wbs_desc: filterPayload.WbsDesc || [],
  spr_ord_date: filterPayload.OrdDate || [],
  spr_delivery_ind: filterPayload.DeliveryInd || [],
  spr_item_del_dt: filterPayload.ItemDelDt || [],
  spr_active: filterPayload.Active || [],
  spr_created_by: filterPayload.CreatedBy || [],
  spr_created_on: filterPayload.CreatedOn || [],
  spr_modified_by: filterPayload.ModifiedBy || [],
  spr_modified_on: filterPayload.ModifiedOn || [],
};

    try {
      const response = await axios.post("http://localhost:57730/api/smartprocTGS/getPRPRLineItems?role=CM", payload);
      const apiResult = response.data;
      if (apiResult.IsSuccess && Array.isArray(apiResult.Data)) {
        setData(apiResult.Data);
      } else {
        throw new Error(apiResult.message || "Invalid data format received.");
      }
    } catch (err: any) {
      console.error("API fetch error:", err);
      setError("Failed to load data. Please try again later.");
    } finally {
      setLoading(false);
    }
  };
  const extractId = (str: string | null | undefined): string | null => {
  if (!str) return null;
  const match = str.match(/\((\d+)\)/);
  return match ? match[1] : null;
};
  const handleSaveFromChild = async (filterPayload: Record<string, any>[] = []) => {
    try {
         const payload = filterPayload.map(row => ({
  spr_id: row.Id ?? null,
  spr_pr: row.Pr ?? null,
  spr_pr_item: row.PrItem ?? null,
  spr_fy_yr: row.FyYr ?? null,
  spr_version: row.Version ?? null,
  spr_purchase_grp: row.PurchaseGrp ?? null,
  spr_proc_head: extractId(row.ProcHead) ?? null,
  spr_proc_mgr: extractId(row.ProcMgr) ?? null,
  spr_item_desc: row.ItemDesc ?? null,
  spr_item_qty: row.ItemQty ?? null,
  spr_mes: row.Mes ?? null,
  spr_mat_no: row.MatNo ?? null,
  spr_mat_group: row.MatGroup ?? null,
  spr_mat_desc: row.MatDesc ?? null,
  spr_mat_type: row.MatType ?? null,
  spr_kostl: row.Kostl ?? null,
  spr_psp_pnr: row.PspPnr ?? null,
  spr_nplnr: row.Nplnr ?? null,
  spr_aupl: row.Aupl ?? null,
  spr_aufnr: row.Aufnr ?? null,
  spr_loekz: row.Loekz ?? null,
  spr_knttp: row.Knttp ?? null,
  spr_order_no: row.OrderNo ?? null,
  spr_order_status: row.OrderStatus ?? null,
  spr_order_item_no: row.OrderItemNo ?? null,
  spr_wbs: row.Wbs ?? null,
  spr_wbs_desc: row.WbsDesc ?? null,
  spr_ord_date: row.OrdDate ?? null,
  spr_delivery_ind: row.DeliveryInd ?? null,
  spr_item_del_dt: row.ItemDelDt ?? null,
  spr_active: row.Active ?? null,
  spr_created_by: extractId(row.CreatedBy) ?? null,
  spr_modified_by: extractId(row.ModifiedBy) ?? null,
}));

      const res = await axios.post('http://localhost:57730/api/smartprocTGS/updateSubcategoryBuyerMapping', payload);
      await fetchData();
    //   if (res.data?.isSuccess) {
    //     await fetchData(); // Refresh full data
    //   } else {
    //     console.error("Update failed:", res.data?.message);
    //   }
    } catch (error) {
      console.error("API error:", error);
    }
  };

  return (
    <div className="p-4">
      <DynamicFilter
        filterColumns={filterColumnsConfig}
        onFilterApply={(filters: {} | undefined) => {
          setFilters(filters);
          fetchData(filters);
        }}
      />

      {loading && <p className="text-gray-600">Loading data...</p>}
      {error && <p className="text-red-500">{error}</p>}

      {!loading && !error && (
        <>
          <DynamicTableData
            columns={tableColumnsConfig}
            data={data}
            selectable={true}
            visibleColumnCount={6}
            collapsable={true}
            uniqueKeys={['Pr','PrItem','FyYr','Version']}
            editable={true}
            onSave={handleSaveFromChild}
            editColumnsConfig = {editColumnsConfig}
            isRowSelectable={(row: { ActiveStatus: string; }) => row.ActiveStatus !== "Y"}
          />
        </>
      )}
    </div>
  );
};

export default LivePR;
