import React from "react";
import BulkEditUploader from "../utilities/BulkEditUploader9";

interface UploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  columns: any[];
  uniqueKeys: string[];
  existingData: any[];
  apiUrl: string;
  payloadMapper: (row: any) => any;
  onResult: (result: {
    message: string;
    successCount: number;
    failureCount: number;
    excelBlobUrl: string;
  }) => void;
}

const UploadModal: React.FC<UploadModalProps> = ({
  isOpen,
  onClose,
  columns,
  uniqueKeys,
  existingData,
  apiUrl,
  payloadMapper,
  onResult,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
      <div className="bg-white rounded-lg shadow-lg p-10 w-full max-w-2xl relative">
        <button
          onClick={onClose}
          className="absolute top-2 text-4xl text-red-700 right-2 hover:text-gray-800 hover:cursor-pointer"
        >
          &times;
        </button>

        <h2 className="text-2xl font-semibold mb-15 w-full p-2">Upload for Bulk Edit</h2>

        <BulkEditUploader
          columns={columns}
          uniqueKeys={uniqueKeys}
          existingData={existingData}
          apiUrl={apiUrl}
          payloadMapper={payloadMapper}
          onResult={onResult}
        />
      </div>
    </div>
  );
};

export default UploadModal;
