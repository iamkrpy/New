import React, { useState, useEffect, useMemo, useRef } from "react";
import { CloseIcon } from "../utilities/icons";
import { SuggestionBox } from "../utilities/SuggestionBox1";
import axios from "axios";

interface FilterColumn {
  accessor: string;
  label: string;
  type: string;
  labelkey?: string;
  dataSourceUrl?: string;
  selectionMode?: "single" | "multiple";
  options?: { label: string; value: string }[];
  placeholder?: string;
  required?: boolean;
  editable?: boolean;
}

interface EditRowModalProps {
  isOpen: boolean;
  rows: any[];
  columns: FilterColumn[];
  getRowKey: (row: any) => string;
  onClose: () => void;
  onSave: (updatedRows: any[]) => void;
}

const EditRowModal: React.FC<EditRowModalProps> = ({
  isOpen,
  rows,
  columns,
  getRowKey,
  onClose,
  onSave,
}) => {
  const [editedRows, setEditedRows] = useState<any[]>([]);

  const inputRefs = useRef<Record<string, React.RefObject<HTMLInputElement>>>({});

  const originalRowMap = useMemo(() => {
    const map: Record<string, any> = {};
    rows.forEach((row) => {
      const key = getRowKey(row);
      map[key] = { ...row };
    });
    return map;
  }, [rows, getRowKey]);

  useEffect(() => {
    // Ensure values are copied from accessor to labelkey (if needed)
    
    const initialized = rows.map((row) => {
      const newRow = { ...row };
      columns.forEach((col) => {
        const labelKey = col.labelkey?.trim();
        const accessorKey = labelKey || col.accessor;
        if (!newRow[accessorKey] && newRow[col.accessor]) {
          newRow[accessorKey] = newRow[col.accessor];
        }
      });
      return newRow;
    });
    setEditedRows(initialized);
  }, [rows, columns]);

  const fetchSuggestions = async (
    query: string
  ): Promise<{ label: string; value: any }[]> => {
    const res = await axios.get(
      `http://localhost:57730/api/luceneSearch/searchEmployees?query=${query}`
    );
    return res.data.map((item: any) => ({
      label: `${item.Name} (${item.Code})`,
      value: item,
    }));
  };

  const handleChange = (index: number, key: string, value: string) => {
    const updated = [...editedRows];
    updated[index] = { ...updated[index], [key]: value };
    setEditedRows(updated);
  };

  const handleRemoveRow = (index: number) => {
    const updated = [...editedRows];
    updated.splice(index, 1);
    setEditedRows(updated);
  };

  const hasChanged = (row: any, key: string) => {
    const rowKey = getRowKey(row);
    const original = originalRowMap[rowKey];
    return original && original[key] !== row[key];
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40 p-4">
      <div className="bg-white rounded-lg shadow-lg w-full max-w-6xl max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="px-6 py-4 border-b flex items-center justify-between bg-emerald-400">
          <h2 className="text-xl font-bold">Edit Rows</h2>
          <button onClick={onClose} className="w-10 h-10" title="Close">
            <CloseIcon />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-auto p-10 space-y-6 flex-1">
          {editedRows.slice(0, 10).map((row, rowIndex) => {
            const rowKey = getRowKey(row);

            return (
              <div
                key={rowKey}
                className="border border-blue-200 mb-10 rounded-2xl bg-blue-100 p-4 relative shadow-md hover:shadow-xl hover:ring-4 hover:ring-blue-400 transition-all"
              >
                <button
                  onClick={() => handleRemoveRow(rowIndex)}
                  className="absolute top-2 right-2 text-red-600 hover:text-red-800 text-lg font-extrabold"
                  title="Remove this record"
                >
                  X
                </button>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-5">
                  {columns.map((col, colIndex) => {
                    const accessorKey =
                      col.labelkey?.trim() || col.accessor;
                    const formKey = `${rowKey}_${accessorKey}__${colIndex}`;

                    if (!inputRefs.current[formKey]) {
                      inputRefs.current[formKey] =
                        React.createRef<HTMLInputElement>();
                    }

                    const ref = inputRefs.current[formKey];

                    return (
                      <div key={formKey}>
                        <label className="font-medium text-md block mb-1">
                          {col.label}
                        </label>
                        {col.editable ? (
                          <>
                            <input
                              ref={ref}
                              type="text"
                              value={row[accessorKey] ?? ""}
                              onChange={(e) =>
                                handleChange(
                                  rowIndex,
                                  accessorKey,
                                  e.target.value
                                )
                              }
                              className={`w-full border rounded-4xl font-bold px-3 py-2 text-md focus:outline-none ${
                                hasChanged(row, accessorKey)
                                  ? "bg-yellow-100 border-yellow-400"
                                  : "bg-white"
                              }`}
                            />

                            {ref && (
                              <SuggestionBox
                                inputRef={ref}
                                fetchSuggestions={fetchSuggestions}
                                onSelect={(val) =>
                                  handleChange(
                                    rowIndex,
                                    accessorKey,
                                    `${val.Name} (${val.Code})`
                                  )
                                }
                              />
                            )}
                          </>
                        ) : (
                          <div className="text-md">{row[accessorKey]}</div>
                        )}

                        {hasChanged(row, accessorKey) && (
                          <div className="text-xs text-red-600 mt-1">
                            {originalRowMap[rowKey]?.[accessorKey] ?? "∅"} →{" "}
                            {row[accessorKey] ?? "∅"}
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="sticky bottom-0 left-0 right-0 bg-white px-6 py-3 flex justify-end gap-4">
          <button
            onClick={onClose}
            className="bg-gray-200 hover:bg-gray-300 text-gray-800 font-semibold py-2 px-4 rounded"
          >
            Cancel
          </button>
          <button
            onClick={() => onSave(editedRows)}
            className="bg-green-600 hover:bg-green-700 text-white font-semibold py-2 px-4 rounded"
          >
            Save
          </button>
        </div>
      </div>
    </div>
  );
};

export default EditRowModal;
