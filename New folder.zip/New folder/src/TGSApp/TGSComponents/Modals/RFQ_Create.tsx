import { useState, useEffect, useRef, useCallback } from "react";
import Loader from "../../../MainApp/MainAppComponents/MainAppUtilities/Loader";
import ConfirmationModal from "../../../MainApp/MainAppComponents/MainAppUtilities/ConfirmationModal";
import Modal from "../../../MainApp/MainAppComponents/MainAppUtilities/GenericModal";

interface PRItem {
  PR_NO: string;
  I_IND_ITEM_NO: string;
  FY_YR: string;
  [key: string]: any;
}

interface CreateRFQModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedRows: PRItem[];
  onCreate: (rfqNumber: string, fyYr: string) => Promise<{ success: boolean; message?: string }>;
  onValidateRFQ?: (rfqNumber: string, fyYr: string) => Promise<{ isValid: boolean; message?: string }>;
}

export default function CreateRFQModal({
  isOpen,
  onClose,
  selectedRows,
  onCreate,
  onValidateRFQ,
}: CreateRFQModalProps) {
  const [rfqNumber, setRfqNumber] = useState("");
  const [fyYr] = useState(getCurrentFY()); // keep FY fixed during a session
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [isValid, setIsValid] = useState(false);
  const [isAvailable, setIsAvailable] = useState(false);
  const [checking, setChecking] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [infoModal, setInfoModal] = useState<{
    open: boolean;
    type: "info" | "warning" | "error" | "success";
    message: string;
  }>({ open: false, type: "info", message: "" });

  const debounceTimeout = useRef<NodeJS.Timeout | null>(null);

  const resetState = useCallback(() => {
    setRfqNumber("");
    setIsValid(false);
    setIsAvailable(false);
    setError("");
    setChecking(false);
    setLoading(false);
    setShowConfirm(false);
  }, []);

  useEffect(() => {
    if (!isOpen) resetState();
  }, [isOpen, resetState]);

  useEffect(() => {
    return () => {
      if (debounceTimeout.current) clearTimeout(debounceTimeout.current);
    };
  }, []);

  function getCurrentFY(): string {
    const today = new Date();
    let year = today.getFullYear();
    let month = today.getMonth() + 1;

    let fyStart: number, fyEnd: number;
    if (month >= 4) {
      fyStart = year % 100;
      fyEnd = (year + 1) % 100;
    } else {
      fyStart = (year - 1) % 100;
      fyEnd = year % 100;
    }
    return `${fyStart}-${fyEnd}`;
  }

  const validateFormat = (value: string) => /^[a-zA-Z0-9-]{3,}$/.test(value);

  const handleInputChange = useCallback(
    (value: string) => {
      setRfqNumber(value);
      setIsValid(false);
      setIsAvailable(false);
      setError("");

      if (!value) {
        setError("RFQ Number cannot be empty");
        return;
      }
      if (!validateFormat(value)) {
        setError("At least 3 chars: letters, numbers, dash only");
        return;
      }

      setIsValid(true);

      if (onValidateRFQ) {
        if (debounceTimeout.current) clearTimeout(debounceTimeout.current);
        debounceTimeout.current = setTimeout(async () => {
          setChecking(true);
          try {
            const available = await onValidateRFQ(value, fyYr);
            setIsAvailable(available.isValid);
            if (!available.isValid) {
              setError((available.message || `RFQ Number already exists `)+" \u2717");
            }
          } catch {
            setError("Validation failed. Try again.");
          } finally {
            setChecking(false);
          }
        }, 500);
      } else {
        setIsAvailable(true);
      }
    },
    [onValidateRFQ, fyYr]
  );

  const handleSubmit = useCallback(async () => {
    setShowConfirm(false);
    setLoading(true);
    setError("");
  
    try {
      const result = await onCreate(rfqNumber, fyYr);
  
      const normalized = result ?? { success: false, message: "Unknown error" };
  
      if (normalized.success) {
        setInfoModal({
          open: true,
          type: "success",
          message: normalized.message || `RFQ ${rfqNumber} created successfully!`,
        });
        resetState();
        onClose();
      } else {
        throw new Error(normalized.message || "Failed to create RFQ");
      }
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : "Failed to create RFQ";
      setError(msg);
      setInfoModal({ open: true, type: "error", message: msg });
    } finally {
      setLoading(false);
    }
  }, [rfqNumber, fyYr, onCreate, onClose, resetState]);

  const handleClose = useCallback(() => {
    resetState();
    onClose();
  }, [onClose, resetState]);

  const getInputClass = useCallback(() => {
    if (!rfqNumber) return "border-gray-300 focus:ring-blue-500";
    if (isValid && isAvailable)
      return "border-green-500 focus:ring-green-500";
    if (error) return "border-red-500 focus:ring-red-500";
    return "border-gray-300 focus:ring-blue-500";
  }, [rfqNumber, isValid, isAvailable, error]);

  const renderStatus = () => {
    if (checking)
      return <p className="text-blue-500 text-sm" role="status">Checking availability...</p>;
    if (isValid && isAvailable)
      return (
        <p className="text-green-600 text-sm font-bold" role="status">
          RFQ Number is available &#10003;
        </p>
      );
    if (error)
      return (
        <p className="text-red-500 text-sm font-bold" role="alert">
          {error}
        </p>
      );
    return null;
  };

  return (
    <>
      <Modal
        isOpen={isOpen}
        title="RFQ Creation"
        onClose={handleClose}
        footer={
          <>
            <button
              type="button"
              aria-label="Cancel RFQ creation"
              className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition disabled:opacity-50 hover:cursor-pointer hover:scale-110 transform"
              onClick={handleClose}
              disabled={loading}
            >
              Cancel
            </button>
            <button
              type="button"
              aria-label="Confirm RFQ creation"
              className={`px-4 py-2 rounded-lg text-white transition transform ${
                loading || !isValid || !isAvailable
                  ? "bg-blue-400 opacity-50 cursor-not-allowed"
                  : "bg-blue-600 hover:bg-blue-700 hover:scale-110 cursor-pointer"
              }`}
              onClick={() => setShowConfirm(true)}
              disabled={loading || !isValid || !isAvailable}
              title={
                !isValid || !isAvailable
                  ? "Enter a valid and available RFQ number first"
                  : ""
              }
            >
              {loading ? <Loader size={20} color="white" /> : "Create RFQ"}
            </button>
          </>
        }
      >
        <div className="space-y-2">
          <p className="text-sm text-gray-600">
            Selected {selectedRows.length} PR items will be included in this RFQ.
          </p>

          <div className="flex items-center gap-10">
            <input
              type="text"
              value={rfqNumber}
              onChange={(e) => handleInputChange(e.target.value)}
              className={`w-60 border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 ${getInputClass()}`}
              placeholder="Enter new RFQ Number"
              aria-label="Enter RFQ Number"
            />
            {renderStatus()}
          </div>

          <div className="max-h-[30vh] overflow-y-auto border rounded-lg">
            <table className="w-full text-sm text-left border-collapse">
              <thead className="bg-gray-100 text-gray-700 sticky top-0">
                <tr>
                  <th className="px-3 py-2 border">PR</th>
                  <th className="px-3 py-2 border">PR Line Item</th>
                  <th className="px-3 py-2 border">FY Year</th>
                </tr>
              </thead>
              <tbody>
                {selectedRows.map((row) => (
                  <tr
                    key={`${row.PR_NO}-${row.I_IND_ITEM_NO}`}
                    className="hover:bg-gray-50"
                  >
                    <td className="px-3 py-2 border">{row.PR_NO}</td>
                    <td className="px-3 py-2 border">{row.I_IND_ITEM_NO}</td>
                    <td className="px-3 py-2 border">{row.FY_YR}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </Modal>


      <ConfirmationModal
        isOpen={showConfirm}
        type="confirmation"
        title="Confirm RFQ Creation"
        message={`Are you sure you want to create RFQ '${rfqNumber}'?`}
        onClose={() => setShowConfirm(false)}
        onConfirm={handleSubmit}
        positiveLabel="Yes, Create"
        negativeLabel="Cancel"
        height="auto"
      />

      <ConfirmationModal
        isOpen={infoModal.open}
        type={infoModal.type}
        title={
          infoModal.type === "error"
            ? "Error"
            : infoModal.type === "warning"
            ? "Warning"
            : "Information"
        }
        message={infoModal.message}
        onClose={() => setInfoModal({ ...infoModal, open: false })}
        positiveLabel="OK"
        height="auto"
      />
    </>
  );
}
