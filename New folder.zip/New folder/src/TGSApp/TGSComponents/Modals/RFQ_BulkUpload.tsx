import { useState } from "react";
import Modal from "../../../MainApp/MainAppComponents/MainAppUtilities/GenericModal";
import Loader from "../../../MainApp/MainAppComponents/MainAppUtilities/Loader";

interface BulkUploadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onUpload: (file: File) => Promise<void>;
}

export default function BulkUploadModal({ isOpen, onClose, onUpload }: BulkUploadModalProps) {
  const [file, setFile] = useState<File | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleUpload = async () => {
    if (!file) {
      setError("Please select a file to upload");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await onUpload(file);
      onClose();
      setFile(null);
    } catch (err: any) {
      setError(err.message || "Upload failed");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      title="Bulk Upload RFQ"
      onClose={onClose}
      footer={
        <>
          <button
            type="button"
            className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition"
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            type="button"
            className="px-4 py-2 rounded-lg bg-green-600 text-white hover:bg-green-700 transition disabled:opacity-50"
            onClick={handleUpload}
            disabled={loading}
          >
            {loading ? <Loader size={20} color="white" /> : "Upload"}
          </button>
        </>
      }
    >
      <div className="space-y-2">
        <input
          type="file"
          accept=".xlsx,.csv"
          onChange={(e) => setFile(e.target.files?.[0] ?? null)}
          className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500"
        />
        {file && <p className="text-sm text-gray-600">Selected file: {file.name}</p>}
        {error && <p className="text-red-500 text-sm">{error}</p>}
      </div>
    </Modal>
  );
}
