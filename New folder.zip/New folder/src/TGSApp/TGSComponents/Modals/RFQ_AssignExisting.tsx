import { useState } from "react";
import Modal from "../../../MainApp/MainAppComponents/MainAppUtilities/GenericModal";
import Loader from "../../../MainApp/MainAppComponents/MainAppUtilities/Loader";

interface AssignRFQModalProps {
  isOpen: boolean;
  onClose: () => void;
  selectedRows: any[];
  existingRFQs: string[];
  onAssign: (rfqNumber: string) => Promise<void>;
}

export default function AssignRFQModal({ isOpen, onClose, selectedRows, existingRFQs, onAssign }: AssignRFQModalProps) {
  const [selectedRFQ, setSelectedRFQ] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleAssign = async () => {
    if (!selectedRFQ) {
      setError("Please select an RFQ");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await onAssign(selectedRFQ);
      onClose();
      setSelectedRFQ("");
    } catch (err: any) {
      setError(err.message || "Failed to assign RFQ");
    } finally {
      setLoading(false);
    }
  };

  return (
    <Modal
      isOpen={isOpen}
      title="Assign Existing RFQ"
      onClose={onClose}
      footer={
        <>
          <button
            type="button"
            className="px-4 py-2 rounded-lg bg-gray-200 hover:bg-gray-300 transition"
            onClick={onClose}
          >
            Cancel
          </button>
          <button
            type="button"
            className="px-4 py-2 rounded-lg bg-blue-600 text-white hover:bg-blue-700 transition disabled:opacity-50"
            onClick={handleAssign}
            disabled={loading}
          >
            {loading ? <Loader size={20} color="white" /> : "Assign"}
          </button>
        </>
      }
    >
      <div className="space-y-2">
        <p className="text-sm text-gray-600">Selected {selectedRows.length} PR items will be assigned.</p>
        <select
          value={selectedRFQ}
          onChange={(e) => setSelectedRFQ(e.target.value)}
          className="w-full border rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-blue-500"
        >
          <option value="">Select RFQ</option>
          {existingRFQs.map((rfq) => (
            <option key={rfq} value={rfq}>
              {rfq}
            </option>
          ))}
        </select>
        {error && <p className="text-red-500 text-sm">{error}</p>}
      </div>
    </Modal>
  );
}
