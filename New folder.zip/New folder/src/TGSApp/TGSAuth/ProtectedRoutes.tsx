// import { Route } from "react-router-dom";
// import RequireAuth from "./RequireAuth";
// import RequireRole from "./RequireRole";
// import Layout from "../components/layout/Layout";
// import LivePRs from "../pages/LivePRs";
// import CatSubCatBuyer from "../pages/CatSubCatBuyer";
// import PurchaseGrpHead from "../pages/PurchaseGrpHead";
// export const protectedRoutes = (
//   <Route element={<RequireAuth><Layout /></RequireAuth>}>
//     <Route path="LivePRs" element={<LivePRs />} />
//     <Route
//       path="PROCHEAD"
//       element={
//         <RequireRole roles="PurchaseGrpHead">
//           <PurchaseGrpHead />
//         </RequireRole>
//       }
//     />
//     <Route
//       path="PROCBUYER"
//       element={
//         <RequireRole roles={["PROCBUYER", "PROCHEAD"]}>
//           <CatSubCatBuyer />
//         </RequireRole>
//       }
//     />
//   </Route>
// );