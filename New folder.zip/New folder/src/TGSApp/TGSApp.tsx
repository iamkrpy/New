import '../App.css'
import TGSRoutes from './TGSRoutes/TGSRoutes'

function TGSApp() {

  return (
    <div>
      <TGSRoutes/>
    </div>
  )
}

export default TGSApp

