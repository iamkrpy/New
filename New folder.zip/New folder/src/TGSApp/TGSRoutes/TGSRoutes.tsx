import { Route, Routes } from 'react-router-dom';
import CatSubCatBuyer from '../TGSComponents/TGSPages/CatSubCatBuyer';
import LivePRs from '../TGSComponents/TGSPages/LivePRs';
import PurchaseGrpHead from '../TGSComponents/TGSPages/PurchaseGrpHead';
import LivePRsBuyer from '../TGSComponents/TGSPages/LivePRsBuyer';
import DemandPR from '../TGSComponents/TGSPages/DemandPR';
import TER from '../TGSComponents/TGSPages/TER';
import RFQRequests from '../TGSComponents/TGSPages/RFQRequests';
import MultiStageForm from '../TGSComponents/TGSPages/MultiStageForm/MultiStageForm';

function TGSRoutes() {
  return (
    <Routes>
      <Route path="CatSubCatBuyer" element={<CatSubCatBuyer />} />
      <Route path="LivePRs" element={<LivePRs />} />
      <Route path="LivePRsBuyer" element={<LivePRsBuyer />} />
      <Route path="PurchaseGrpHead" element={<PurchaseGrpHead />} />
      <Route path="RFQRequests" element={<RFQRequests />} />
      <Route path="PurchaseGrpHead" element={<PurchaseGrpHead />} />
      <Route path="/rfq/:rfqNumber/:fyYear/:parameter" element={<MultiStageForm />} />
    </Routes>
  );
}

export default TGSRoutes;
