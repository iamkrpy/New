import axios, { type AxiosRequestConfig, type AxiosResponse } from "axios";

export interface ApiResponse<T = any> {
  IsSuccess: boolean;
  Message: string;
  StatusCode: number;
  Data: T | null;
}

const axiosInstance = axios.create({
  baseURL: import.meta.env.VITE_API_BASE_URL_TGS || "/api",
  withCredentials: true,
  timeout: 10000,
});

axiosInstance.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response?.status === 401) {
      console.warn("Unauthorized - redirect to login");
      // Optional: trigger logout or redirect
    }
    return Promise.reject(error);
  }
);

export async function postApi<T = any>(
  url: string,
  payload: object = {},
  config?: AxiosRequestConfig
): Promise<ApiResponse<T>> {
  const response: ApiResponse<T> = {
    IsSuccess: false,
    Message: "",
    StatusCode: 0,
    Data: null,
  };

  try {
    const res: AxiosResponse = await axiosInstance.post(url, payload, config);
    response.StatusCode = res.status;
    response.IsSuccess = res.data?.IsSuccess ?? true;
    response.Message = res.data?.Message ?? "Success";
    response.Data = res.data?.Data ?? res.data;
    return response;
  } catch (err: any) {
    response.StatusCode = err.response?.status ?? 500;
    response.Message = err.response?.data?.Message || err.message || "Unknown error";
    response.IsSuccess = false;
    response.Data = null;
    return response;
  }
}

export async function getApi<T = any>(
  url: string,
  config?: AxiosRequestConfig
): Promise<ApiResponse<T>> {
  const response: ApiResponse<T> = {
    IsSuccess: false,
    Message: "",
    StatusCode: 0,
    Data: null,
  };

  try {
    const res: AxiosResponse = await axiosInstance.get(url, config);
    response.StatusCode = res.status;
    response.IsSuccess = res.data?.IsSuccess ?? true;
    response.Message = res.data?.Message ?? "Success";
    response.Data = res.data?.Data ?? res.data;
    return response;
  } catch (err: any) {
    response.StatusCode = err.response?.status ?? 500;
    response.Message = err.response?.data?.Message || err.message || "Unknown error";
    response.IsSuccess = false;
    response.Data = null;
    return response;
  }
}

export default axiosInstance;
