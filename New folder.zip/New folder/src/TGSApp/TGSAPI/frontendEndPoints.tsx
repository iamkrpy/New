const TGS_CLIENT_ENDPOINTS = {
    GetRFQ: '/TGSApp/RFQ/'
}

export default TGS_CLIENT_ENDPOINTS;