const TGS_API_ENDPOINTS = {
  //LivePRs Buyer & Head
    getConsolidatedIndentItems: "PRView/getConsolidatedIndentItems",
  //RFQ
    checkRFQExistence:"rfq/checkRFQExistence",
    SingleRFQCreation: "rfq/SingleRFQCreation",
    bulkRFQUploadBuyer: "rfq/BulkRFQCreation",
    GetRFQRequestsHead: "rfq/GetRFQRequests?role=CH&baseURL="+import.meta.env.VITE_BASE_URL_TGS+'/RFQ',
    GetRFQRequestsBuyer: "rfq/GetRFQRequests?role=CM&baseURL="+import.meta.env.VITE_BASE_URL_TGS+'/RFQ',
    SearchVendor: "/searchVendors",
    GetRFQDetails: "rfq/getRFQDetails?role=CM",
    submitRFQVendorList: "rfq/submitRFQVendorList",
    getVendorsForRFQ: "rfq/getVendorsForRFQ",
    submitRFQ: "rfq/submitRFQ"
  };
  
  export default TGS_API_ENDPOINTS;