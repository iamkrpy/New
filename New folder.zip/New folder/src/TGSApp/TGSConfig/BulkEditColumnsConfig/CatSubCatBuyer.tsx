export const bulkEditColumnsConfig = [
    {
      Header: "Subcategory Description",
      accessor: "tcs_catsubcat_desc",
      editable: true,
      required: true,
      type: "string" as "string" | "number" | "date",
      maxLength: 100,
    },
    {
      Header: "Initial Procurement Manager",
      accessor: "tcs_ini_proc_mgr",
      editable: true,
      required: false,
      type: "string" as "string" | "number" | "date",
    },
    {
      Header: "SLA PR to PO (days)",
      accessor: "tcs_sla_pr_po",
      editable: true,
      required: false,
      type: "number" as "string" | "number" | "date",
    },
    {
      Header: "Updated Date (YYYY-MM-DD)",
      accessor: "tcs_update_dt",
      editable: true,
      required: true,
      type: "date" as "string" | "number" | "date",
      format: /^\d{4}-\d{2}-\d{2}$/, // YYYY-MM-DD
    },
    {
      Header: "Active",
      accessor: "tcs_active",
      editable: true,
      required: true,
      type: "string" as "string" | "number" | "date",
      allowedValues: ["Y", "N"],
    },
  ];