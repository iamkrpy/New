
export const tableColumnsConfig = [
  { Header: "PR No", accessor: "PRNo", filter: true, editable: false , headerStyle: headerStyle(), rowStyle: rowStyle()},
  { Header: "Item No", accessor: "ItemNo", filter: true, editable: false , headerStyle: headerStyle(), rowStyle: rowStyle()},
//   { Header: "Ind No", accessor: "IndNo", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle()},
  { Header: "Financial Year", accessor: "IndFY", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: "Status Description", accessor: "StatusDesc", filter: true, editable: false , headerStyle: headerStyle(), rowStyle: rowStyle() },
//   { Header: "Parameter", accessor: "Parameter", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: "Item Description", accessor: "ItemDesc", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: "Quantity", accessor: "ItemQty", filter: true, editable: true , headerStyle: headerStyle(), rowStyle: rowStyle()},
  { Header: "UOM", accessor: "MES", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: "Material No", accessor: "MatNo", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: "Created By", accessor: "CreatedBy", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  {
    Header: "Created On",
    accessor: "CreatedOn",
    filter: true,
    editable: false,
     headerStyle: headerStyle(), rowStyle: rowStyle() ,
    cellRender: (value: string | null) => {
      if (!value) return "";
      return value.split("T")[0]; // display only date part
    },
  },
  { Header: "Modified By", accessor: "ModifiedBy", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle()  },
  {
    Header: "Modified On",
    accessor: "ModifiedOn",
    filter: true,
    editable: false,
    cellRender: (value: string | null) => {
      if (!value) return "";
      return value.split("T")[0];
    }, headerStyle: headerStyle(), rowStyle: rowStyle() 
  },
  // { Header: "Status Code", accessor: "StatusCode", filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle()  },
];

// Optional: style helpers (if your DynamicTableData supports it)
export function headerStyle() {
  return {
    backgroundColor: "#e0f2fe",
    padding: "0.5rem",
    fontSize: "1rem",
    fontWeight: 600,
    textAlign: "center",
  };
}

export function rowStyle() {
  return {
    padding: "0.5rem",
    fontSize: "0.95rem",
    textAlign: "center",
  };
}
