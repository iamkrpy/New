import { FiAlertTriangle, FiExternalLink } from "react-icons/fi";
import { useNavigate } from "react-router-dom";
import RFQCell from "../../TGSComponents/TGSPages/RFQRequests/RFQCell";

export const rfqTableColumnsConfig = [
    { Header: 'RFQ Number', accessor: 'RFQ_No', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() ,
    // cellRender: (value: any, row: any) => {
    //     const statusLink = row.Status_Tracker_HyperLink;
    //     return statusLink ?(
    //             <a href={value} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-800 underline cursor-pointer">
    //             {row.RFQ_No}
    //           </a>
    //            ):(<span>value</span>)
    //     }
    // cellRender: (value: any, row: any) => {
    //     const statusLink = row.Status_Tracker_HyperLink;
      
    //     // Fallback if status link is missing
    //     if (!statusLink) {
    //       return <span className="text-gray-500">{row.RFQ_No || value}</span>;
    //     }
      
    //     return (
    //       <div className="flex items-center gap-1">
    //         <a
    //           href={statusLink}
    //           target="_blank"
    //           rel="noopener noreferrer"
    //           className="flex items-center gap-1 text-indigo-600 font-semibold hover:text-indigo-800 underline transition-colors"
    //           onClick={(e) => e.stopPropagation()} // prevent table row click interference
    //           title="Click to view status"
    //         >
    //           {row.RFQ_No}
    //           <FiExternalLink size={14} />
    //         </a>
    //       </div>
    //     );
    //   }
    },
    { Header: 'Financial Year', accessor: 'FY_Year', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Status', accessor: 'StageCode', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Status Tracker with hyperlink to access the package for processing', accessor: 'StageName', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() ,
    // cellRender: (value: any, row: any) => {
    //     const statusLink = row.Status_Tracker_HyperLink;
      
    //     if (!statusLink) {
    //       return <span className="text-gray-500 font-medium text-lg">{row.RFQ_No || value}</span>;
    //     }
    //     const statusColor = row.StageCode === "RFQTOBESUBMTTD" ? "bg-red-400" : "bg-emerald-300";
    
    //     const statusColor1 = row.StageCode === "RFQTOBESUBMTTD" ? "text-red-950" : "bg-emerald-950";
    //     return (
    //       <>
    //         {/* RFQ Number Link */}
    //         <a
    //           href={statusLink}
    //           target="_blank"
    //           rel="noopener noreferrer"
    //           className={`flex items-center gap-2 font-bold text-md ${statusColor1}  ${statusColor} p-2 rounded-3xl transition-all transform hover:scale-105`}
    //           onClick={(e) => e.stopPropagation()}
    //           title="Click to view status"
    //         >
    //           {value}
    //           {/* Modern external link icon */}
    //           <FiExternalLink className="text-shadow-blue-600" size={28} />
    //         </a>
    //       </>
    //     );
    //   }   
    // cellRender: (value: any, row: any) => {
    //   const navigate = useNavigate();
    
    //   const statusColor = row.StageCode === "RFQTOBESUBMTTD" ? "bg-red-400" : "bg-emerald-300";
    //   const statusColor1 = row.StageCode === "RFQTOBESUBMTTD" ? "text-red-950" : "bg-emerald-950";
    
    //   const handleClick = (e: React.MouseEvent) => {
    //     e.stopPropagation();
    //     navigate(`/RFQ/${row.RFQ_No}/${row.FY_Year}`);
    //   };
    
    //   return (
    //     <button
    //       type="button"
    //       onClick={handleClick}
    //       className={`flex items-center gap-2 font-bold text-md ${statusColor1} ${statusColor} p-2 rounded-3xl transition-all transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-indigo-500`}
    //       title={`View RFQ ${row.RFQ_No}`}
    //       aria-label={`View RFQ ${row.RFQ_No}`}
    //     >
    //       {value}
    //       <FiExternalLink className="text-shadow-blue-600" size={28} />
    //     </button>
    //   );
    // }
    cellRender: (value:any, row:any) => <RFQCell value={value} row={row} />
     },
    // { Header: 'SLA PR/PO (Days)', accessor: 'TCS_SLA_PR_PO', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'No of PRs', accessor: 'No_of_PR', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'No of PR Items', accessor: 'No_of_PR_Items', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'No of PR Items', accessor: 'No_of_PR_Items_RYG', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() ,
    cellRender: (value:any, row:any) => {
        if (!value) return <span className="text-gray-500">-</span>;
      
        // value example: "R:2 Y:1 G:3"
        const parts = value.split(" "); // ["R:2", "Y:1", "G:3"]
        const showAlert = !row.TCS_SLA_PR_PO;
      
        return (
          <div className="flex items-center gap-5">
            <div className="flex flex-col gap-1 w-25">
            {parts.map((part:any, idx:any) => {
              const color = part.startsWith("R:") ? "-red-600" :
                            part.startsWith("Y:") ? "-yellow-500" :
                            part.startsWith("G:") ? "-green-600" :
                            "text-gray-500";
              const number = part.split(":")[1] || 0;
      
              return (
                <span key={idx} title={number+' items'} className={`${'bg'+ color} font-semibold text-sm text-center p-1 rounded-2xl`}>
                  {number}
                </span>
              );
            })}
          </div>
          {showAlert && (
            <FiAlertTriangle className="text-yellow-500 font-extrabold mt-1 hover:cursor-pointer" title='SLA_PR_PO is missing' size={28}/>
          )}
          </div>
        );
      },
      },
    { Header: 'Sub Categories', accessor: 'Sub_Categoryies', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Project Managers', accessor: 'Project_Managers', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Age at Current Stage', accessor: 'Age_at_Current_Stage', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Pending With', accessor: 'Pending_With', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
//     { Header: 'Status Tracker', accessor: 'Status_Tracker_HyperLink', filter: false, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle()
//     ,cellRender: (value: any) => (
//         <a href={value} target="_blank" rel="noopener noreferrer" className="text-indigo-600 hover:text-indigo-800 underline cursor-pointer">
//         View Status
//       </a>
//        )
// },
  ];

  function headerStyle() {
    return {
      backgroundColor: '#e0f2fe',
      padding: '0.5rem',
      fontSize: '1rem',
      fontWeight: '600',
      textAlign: 'center',
    };
  }
  
  function rowStyle() {
    return {
      padding: '0.2',
      fontSize: '1rem',
      textAlign: 'center',
      fontWeight: '600',
    };
  }
  