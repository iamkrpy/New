export const tableColumnsConfig = [
  {
    Header: 'PR',
    accessor: 'SPR_IND',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'PR Item',
    accessor: 'SPR_IND_ITEM',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'PR FY_YR',
    accessor: 'SPR_FY_YR',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Item Description',
    accessor: 'SPR_ITEM_DESC',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Unit',
    accessor: 'SPR_MES',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'UMC No',
    accessor: 'SPR_MAT_NO',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'UMC Description',
    accessor: 'SPR_MAT_DESC',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Proc Manager',
    accessor: 'SPR_PROC_MGR',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
];
function headerStyle() {
  return {
    backgroundColor: '#e0f2fe',
    padding: '0.5rem',
    fontSize: '0.875rem',
    fontWeight: '600',
    align: 'center',
  };
}

function rowStyle() {
  return {
    padding: '0.5rem',
    fontSize: '0.875rem',
    align: 'center',
  };
}