// ✅ Column config for Proposed Vendor Panel
export const vendorTableColumnsConfig = [
    {
      Header: "Vendor Code",
      accessor: "Code",
      filter: true,
      editable: false,
      headerStyle: headerStyle(),
      rowStyle: rowStyle(),
    },
    {
      Header: "Vendor Name",
      accessor: "Name",
      filter: true,
      editable: false,
      headerStyle: headerStyle(),
      rowStyle: rowStyle(),
    },
    // {
    //   Header: "Display Text",
    //   accessor: "DisplayText",
    //   filter: true,
    //   editable: false,
    //   headerStyle: headerStyle(),
    //   rowStyle: rowStyle(),
    // },
  ];
  
  // ✅ Style helpers (same as your existing config)
  export function headerStyle() {
    return {
      backgroundColor: "#e0f2fe",
      padding: "0.5rem",
      fontSize: "1rem",
      fontWeight: 600,
      textAlign: "center",
    };
  }
  
  export function rowStyle() {
    return {
      padding: "0.5rem",
      fontSize: "0.95rem",
      textAlign: "center",
    };
  }
  