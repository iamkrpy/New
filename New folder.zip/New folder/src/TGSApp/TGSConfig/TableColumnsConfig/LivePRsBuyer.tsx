export const tableColumnsConfig = [
    { Header: 'PR No', accessor: 'PR_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'PR Item No', accessor: 'I_IND_ITEM_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Financial Year', accessor: 'FY_YR', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'PR Status', accessor: 'STATUS_DESC', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Item Status', accessor: 'I_STATUS_DESC', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'UMC/USC', accessor: 'I_MAT_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Short Text', accessor: 'I_ITEM_DESC', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Item Qty', accessor: 'I_ITEM_QTY', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'UOM', accessor: 'I_MES', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'WBS Name', accessor: 'I_WBS', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'WBS Desc', accessor: 'I_WBS_DESC', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'PR Release Date', accessor: 'PR_RELEASE_DT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle(),cellRender: (value: any, row: any) => {
        if (!value) return '';
        // Convert to string in case it's a Date object
        const dateStr = typeof value === 'string' ? value : new Date(value).toISOString();
        // Trim everything after 'T'
        return dateStr.split('T')[0];
      } },
    { Header: 'PR Registration Date', accessor: 'REGD_DT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle(),cellRender: (value: any, row: any) => {
        if (!value) return '';
        // Convert to string in case it's a Date object
        const dateStr = typeof value === 'string' ? value : new Date(value).toISOString();
        // Trim everything after 'T'
        return dateStr.split('T')[0];
      } },
    { Header: 'Expected Ordering Date', accessor: 'ORD_REQ_DT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle(),cellRender: (value: any, row: any) => {
        if (!value) return '';
        // Convert to string in case it's a Date object
        const dateStr = typeof value === 'string' ? value : new Date(value).toISOString();
        // Trim everything after 'T'
        return dateStr.split('T')[0];
      } },
    { Header: 'Project Manager', accessor: 'PROJ_MGR', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Commercial Manager', accessor: 'PROC_MGR', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Head', accessor: 'PROC_HEAD', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Purchasing Group', accessor: 'PURCHGRP', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'SLA (PR to PO)', accessor: 'I_MAT_SLA_PR_PO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'SLA (PO to GRN)', accessor: 'I_MAT_SLA_PO_GRN', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'Valid ARC No', accessor: 'I_VALID_ARC_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'ARC_ITEM_NO', accessor: 'I_ARC_ITEM_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'ARC_VALIDITY_END_DATE', accessor: 'I_ARC_VALIDITY_END_DATE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle(),cellRender: (value: any, row: any) => {
        if (!value) return '';
        // Convert to string in case it's a Date object
        const dateStr = typeof value === 'string' ? value : new Date(value).toISOString();
        // Trim everything after 'T'
        return dateStr.split('T')[0];
      } },
    { Header: 'ARC_OPEN_VALUE', accessor: 'I_ARC_OPEN_VALUE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'STOCK QUANTITY', accessor: 'I_STOCK_QTY', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'STOCK LOCATION', accessor: 'I_STOCK_LOCATION', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'LPP PRICE', accessor: 'I_LPP_PRICE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'LPP PO', accessor: 'I_LPP_PO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    { Header: 'LPP PO DATE', accessor: 'I_LPP_PO_DATE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle(),cellRender: (value: any, row: any) => {
        if (!value) return '';
        // Convert to string in case it's a Date object
        const dateStr = typeof value === 'string' ? value : new Date(value).toISOString();
        // Trim everything after 'T'
        return dateStr.split('T')[0];
      } },
    { Header: 'LPP PO VENDOR', accessor: 'I_LPP_PO_VENDOR', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },




    // { Header: 'SPH ID', accessor: 'ID', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Indent No', accessor: 'NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Parameter', accessor: 'PARAMETER', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Latest Version', accessor: 'IS_LATEST_VERSION', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Status', accessor: 'STATUS', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Description', accessor: 'DESC', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    
    // { Header: 'Project Head', accessor: 'PROJ_HEAD', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    
    
    // { Header: 'Proc Head Assign Date', accessor: 'PROC_HEAD_ASSGN_DT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Proc Head Remarks', accessor: 'PROC_HEAD_REMARKS', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Proc Mgr Assign Date', accessor: 'PROC_MGR_ASSGN_DT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Proc Mgr Remarks', accessor: 'PROC_MGR_REMARKS', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    
    // { Header: 'Sourcing', accessor: 'SOURCING', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Package Type', accessor: 'PACKAGE_TYPE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Discipline', accessor: 'DISCIPLINE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Location', accessor: 'LOC', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Subcategory', accessor: 'SUB_CATEGORY', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Project Name', accessor: 'PROJ_NAME', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Priority', accessor: 'PRIORITY', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Account No', accessor: 'ACNT_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Account Assignment', accessor: 'ACNT_ASSIGNMENT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Type', accessor: 'TYPE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    
    // { Header: 'PR Type', accessor: 'PR_TYPE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'DU No', accessor: 'DU_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Additional Remarks', accessor: 'ADD_REMARKS', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Material Req Date', accessor: 'MAT_REQ_DT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Expected Value', accessor: 'EXP_VALUE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'WBS Name', accessor: 'WBS_NAME', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Sub ID', accessor: 'SUB_ID', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Sub Date', accessor: 'SUB_DT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Batch Run ID', accessor: 'BATCHRUN_ID', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Batch Exception Notes', accessor: 'BATCH_EXCP_NOTES', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Active', accessor: 'ACTIVE', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Created By', accessor: 'CREATED_BY', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Created On', accessor: 'CREATED_ON', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Modified By', accessor: 'MODIFIED_BY', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Modified On', accessor: 'MODIFIED_ON', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'Post Timestamp', accessor: 'POST_TIMESTAMP', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  

    // { Header: 'SPR ID', accessor: 'I_ID', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR No', accessor: 'I_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Item', accessor: 'I_ITEM', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Financial Year', accessor: 'I_FY_YR', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Parameter', accessor: 'I_PARAMETER', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Latest Version', accessor: 'I_IS_LATEST_VERSION', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Status', accessor: 'I_STATUS', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR PR No', accessor: 'I_PR_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Purchase Group', accessor: 'I_PURCHGRP', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Proc Head', accessor: 'I_PROC_HEAD', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Proc Manager', accessor: 'I_PROC_MGR', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },

    
    // { Header: 'SPR Material Group', accessor: 'I_MAT_GROUP', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Material Desc', accessor: 'I_MAT_DESC', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Material Type', accessor: 'I_MAT_TYPE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Cost Center', accessor: 'I_KOSTL', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR WBS Element', accessor: 'I_PS_PNR', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Network Planner', accessor: 'I_NPLNR', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR AUPL', accessor: 'I_AUFPL', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR SAP Order No', accessor: 'I_ORDER_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR SAP Order Status', accessor: 'I_ORDER_STATUS', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Order Item No', accessor: 'I_ORDER_ITEM_NO', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Order Date', accessor: 'I_ORD_DATE', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Delivery Indicator', accessor: 'I_DELIVERY_IND', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Item Delivery Date', accessor: 'I_ITEM_DEL_DT', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Active', accessor: 'I_ACTIVE', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Created By', accessor: 'I_CREATED_BY', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Created On', accessor: 'I_CREATED_ON', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Modified By', accessor: 'I_MODIFIED_BY', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Modified On', accessor: 'I_MODIFIED_ON', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
    // { Header: 'SPR Post Timestamp', accessor: 'I_POST_TIMESTAMP', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  ];
  
  function headerStyle() {
    return {
      backgroundColor: '#e0f2fe',
      padding: '0.5rem',
      fontSize: '1rem',
      fontWeight: '600',
      align: 'center',
    };
  }
  
  function rowStyle() {
    return {
      padding: '0.5rem',
      fontSize: '1rem',
      align: 'center',
    };
  }
  