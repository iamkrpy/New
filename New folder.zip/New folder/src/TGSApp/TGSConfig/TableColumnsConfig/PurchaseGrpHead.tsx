export const tableColumnsConfig = [
    {
      Header: 'Purchase Group',
      accessor: 'PurchaseGroup',
      filter: true,
      editable: true,
      headerStyle: headerStyle(),
      rowStyle: rowStyle(),
    },
    {
      Header: 'Description',
      accessor: 'Description',
      filter: true,
      editable: true,
      headerStyle: headerStyle(),
      rowStyle: rowStyle(),
    },
    {
      Header: 'Procurement Head PNo',
      accessor: 'ProcurementHeadPNo',
      filter: true,
      editable: true,
      headerStyle: headerStyle(),
      rowStyle: rowStyle(),
    },
    {
      Header: 'Procurement Head Name',
      accessor: 'ProcurementHeadName',
      filter: true,
      editable: true,
      headerStyle: headerStyle(),
      rowStyle: rowStyle(),
    },
    {
      Header: 'Procurement Head',
      accessor: 'ProcurementHead',
      filter: true,
      editable: false, // Computed field (name + ID), usually not editable
      headerStyle: headerStyle(),
      rowStyle: rowStyle(),
    },
  ];
  
  function headerStyle() {
    return {
      backgroundColor: '#e0f2fe',
      padding: '0.5rem',
      fontSize: '1.2rem',
      fontWeight: '600',
      textAlign: 'center',
    };
  }
  
  function rowStyle() {
    return {
      padding: '0.5rem',
      fontSize: '1.1rem',
      textAlign: 'center',
    };
  }
  