export const tableColumnsConfig = [
  { Header: 'Id', accessor: 'Id', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'PR Number', accessor: 'Pr', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'PR Item', accessor: 'PrItem', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Financial Year', accessor: 'FyYr', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  // { Header: 'Version', accessor: 'Version', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Purchase Group', accessor: 'PurchaseGrp', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Procurement Head', accessor: 'ProcHead', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Procurement Manager', accessor: 'ProcMgr', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Item Description', accessor: 'ItemDesc', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Item Quantity', accessor: 'ItemQty', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Measurement Unit', accessor: 'Mes', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Material Number', accessor: 'MatNo', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Material Group', accessor: 'MatGroup', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Material Description', accessor: 'MatDesc', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Material Type', accessor: 'MatType', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Cost Center', accessor: 'Kostl', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'WBS Element', accessor: 'PspPnr', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Network Planner', accessor: 'Nplnr', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'AUPL', accessor: 'Aupl', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Order Number', accessor: 'Aufnr', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Deletion Flag', accessor: 'Loekz', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Account Assignment Category', accessor: 'Knttp', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'SAP Order No', accessor: 'OrderNo', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'SAP Order Status', accessor: 'OrderStatus', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Order Item No', accessor: 'OrderItemNo', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'WBS Code', accessor: 'Wbs', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'WBS Description', accessor: 'WbsDesc', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Order Date', accessor: 'OrdDate', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Delivery Indicator', accessor: 'DeliveryInd', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  { Header: 'Item Delivery Date', accessor: 'ItemDelDt', filter: true, editable: true, headerStyle: headerStyle(), rowStyle: rowStyle() },
  // { Header: 'Active', accessor: 'Active', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  // { Header: 'Created By', accessor: 'CreatedBy', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  // { Header: 'Created On', accessor: 'CreatedOn', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  // { Header: 'Modified By', accessor: 'ModifiedBy', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
  // { Header: 'Modified On', accessor: 'ModifiedOn', filter: true, editable: false, headerStyle: headerStyle(), rowStyle: rowStyle() },
];
function headerStyle() {
  return {
    backgroundColor: '#e0f2fe',
    padding: '0.5rem',
    fontSize: '0.875rem',
    fontWeight: '600',
    align: 'center',
  };
}

function rowStyle() {
  return {
    padding: '0.5rem',
    fontSize: '0.875rem',
    align: 'center',
  };
}