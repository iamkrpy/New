export const tableColumnsConfig = [
  // {
  //   Header: 'Category SubCategory Code',
  //   accessor: 'Code',
  //   filter: true,
  //   editable: false,
  //   headerStyle: headerStyle(),
  //   rowStyle: rowStyle(),
  // },
  {
    Header: 'Category SubCategory',
    accessor: 'CategorySubCategory',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Commercial Manager',
    accessor: 'CommercialManager',
    filter: true,
    editable: true,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Commercial Head',
    accessor: 'CommercialHead',
    filter: true,
    editable: true,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'SLA PR PO',
    accessor: 'SLAPRPO',
    filter: true,
    editable: true,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'SLA TER',
    accessor: 'SLATER',
    filter: true,
    editable: true,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'SLA PO-GRN',
    accessor: 'SLAPOGRN',
    filter: true,
    editable: true,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'SLA GRN QA',
    accessor: 'SLAPOGRNQA',
    filter: true,
    editable: true,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Created By',
    accessor: 'CreatedBy',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Created On',
    accessor: 'CreatedDate',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Updated By',
    accessor: 'UpdatedBy',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  {
    Header: 'Updated On',
    accessor: 'UpdatedDate',
    filter: true,
    editable: false,
    headerStyle: headerStyle(),
    rowStyle: rowStyle(),
  },
  // {
  //   Header: 'Active Status',
  //   accessor: 'ActiveStatus',
  //   filter: true,
  //   editable: false,
  //   headerStyle: headerStyle(),
  //   rowStyle: rowStyle(),
  // },
];
function headerStyle() {
  return {
    backgroundColor: '#e0f2fe',
    padding: '0.5rem',
    fontSize: '1.2rem',
    fontWeight: '600',
    align: 'center',
  };
}

function rowStyle() {
  return {
    padding: '0.5rem',
    fontSize: '1.1rem',
    textAlign: 'center',
  };
}