export const editColumnsConfig = [
    {
      accessor: "PurchaseGroup",
      label: "Purchase Group",
      type: "dropdown",
      editable: true,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getProcurementHeads",
      selectionMode: "single" as "single" | "multiple",
      placeholder: "Select PNo",
    },
    {
      accessor: "Description",
      label: "Description Group",
      type: "dropdown",
      editable: true,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getProcurementHeads",
      selectionMode: "single" as "single" | "multiple",
      placeholder: "Select PNo",
    },
    {
      accessor: "ProcurementHeadPNo",
      label: "Procurement Head PNo",
      type: "dropdown",
      editable: true,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getProcurementHeads",
      selectionMode: "single" as "single" | "multiple",
      placeholder: "Select PNo",
    },
    {
      accessor: "ProcurementHeadName",
      label: "Procurement Head Name",
      type: "dropdown",
      editable: false,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getProcurementHeadNames",
      selectionMode: "single" as "single" | "multiple",
      placeholder: "Select Name",
    },
    // {
    //   accessor: "ProcurementHead",
    //   label: "Procurement Head",
    //   type: "text",
    //   editable: false,
    //   placeholder: "
  
]  