export const filterColumnsConfig = [
    {
      accessor: "Pr",
      label: "PR Number",
      type: "dropdown",
      required: false,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getPRNumbers",
      selectionMode: "multiple" as "single" | "multiple",
      placeholder: "Select PR Number(s)",
    },
    {
      accessor: "FyYr",
      label: "Financial Year",
      type: "dropdown",
      required: false,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getFinancialYears",
      selectionMode: "multiple" as "single" | "multiple",
      placeholder: "Select Financial Year(s)",
    },
    {
      accessor: "PurchaseGrp",
      label: "Purchase Group",
      type: "dropdown",
      required: false,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getPurchaseGroups",
      selectionMode: "multiple" as "single" | "multiple",
      placeholder: "Select Purchase Group(s)",
    },
    {
      accessor: "ProcHead",
      label: "Procurement Head",
      type: "dropdown",
      required: false,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getProcurementHeads",
      selectionMode: "multiple" as "single" | "multiple",
      placeholder: "Select Procurement Head(s)",
    },
    {
      accessor: "ProcMgr",
      label: "Procurement Manager",
      type: "dropdown",
      required: false,
      dataSourceUrl: "http://localhost:57730/api/smartprocTGS/getProcurementManagers",
      selectionMode: "multiple" as "single" | "multiple",
      placeholder: "Select Procurement Manager(s)",
    },
  ];
  
  