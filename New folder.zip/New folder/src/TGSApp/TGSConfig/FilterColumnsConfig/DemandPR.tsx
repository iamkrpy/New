export const filterColumnsConfig = [
  {
    accessor: "SPR_IND",
    label: "PR",
    type: "dropdown",
    dataSourceUrl:
      import.meta.env.VITE_API_BASE_URL_TGS + "/getPRItemsToDemand",
    required: false,
    selectionMode: "multiple" as "single" | "multiple",
    placeholder: "Select PR",
  },
  {
    accessor: "SPR_IND_ITEM",
    label: "PR Item",
    type: "dropdown",
    dataSourceUrl:
      import.meta.env.VITE_API_BASE_URL_TGS + "/getPRItemsToDemand",
    required: false,
    selectionMode: "multiple" as "single" | "multiple",
    placeholder: "Select PR Item",
  },
  {
    accessor: "SPR_FY_YR",
    label: "FY YR",
    type: "dropdown",
    dataSourceUrl:
      import.meta.env.VITE_API_BASE_URL_TGS + "/getPRItemsToDemand",
    required: false,
    selectionMode: "multiple" as "single" | "multiple",
    placeholder: "Select FY YR",
  },
  {
    accessor: "SPR_MAT_NO",
    label: "UMC No",
    type: "dropdown",
    dataSourceUrl:
      import.meta.env.VITE_API_BASE_URL_TGS + "/getPRItemsToDemand",
    required: false,
    selectionMode: "multiple" as "single" | "multiple",
    placeholder: "Select UMC",
  },
];