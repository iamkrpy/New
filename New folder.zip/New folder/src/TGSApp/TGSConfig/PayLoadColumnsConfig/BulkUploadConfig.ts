import { type ColumnDefinition } from "../../../MainApp/MainAppConfig/BulkUpload/types";
// import { getCurrentFinancialYear } from "../../TGSComponents/utilities/GetFinancialYear";

export const bulkUploadColumns: ColumnDefinition[] = [
  { excelColumn: "RFQ_NO", dbColumn: "RFQ_NO", required: true },
  { excelColumn: "PR_NO", dbColumn: "PR_NO", required: true},
  { excelColumn: "PR_ITEM", dbColumn: "PR_ITEM", required: true, uniqueWith: ['PR_NO'] },

//   { 
//     excelColumn: "FY_YR", 
//     dbColumn: "FY_YR", 
//     required: true, 
//     defaultValue: getCurrentFinancialYear() 
//   },
];
