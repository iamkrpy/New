export const payloadMapper = (row: any) => ({
    tcs_catsubcat_id: row.tcs_catsubcat_id ?? null,
    tcs_catsubcat_desc: row.tcs_catsubcat_desc ?? null,
    tcs_ini_proc_mgr: extractId(row.tcs_ini_proc_mgr) ?? null,
    tcs_ini_proc_head: extractId(row.tcs_ini_proc_head) ?? null,
    tcs_sla_pr_po: row.tcs_sla_pr_po ?? null,
    tcs_sla_ter: row.tcs_sla_ter ?? null,
    tcs_sla_po_grn: row.tcs_sla_po_grn ?? null,
    tcs_sla_grn_qa: row.tcs_sla_grn_qa ?? null,
    tcs_create_id: extractId(row.tcs_create_id) ?? null,
    tcs_update_id: extractId(row.tcs_update_id) ?? null,
    tcs_active: row.tcs_active ?? null,
  });
  
  const extractId = (str: string | null | undefined): string | null => {
    if (!str) return null;
    const match = str.match(/\((\d+)\)/);
    return match ? match[1] : null;
  };
  