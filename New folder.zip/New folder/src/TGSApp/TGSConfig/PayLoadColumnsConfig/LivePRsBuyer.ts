export const extractId = (str: string | null | undefined): string | null => {
    if (!str) return null;
    const match = str.match(/\((\d+)\)/);
    return match ? match[1] : null;
  };
  
export const mapPRItem = (row: any) => ({
PR_NO: row.PR_NO ?? null,
I_IND_ITEM_NO: row.I_IND_ITEM_NO ?? null,
});
  
export const payloadMapper = (
rfqNumber: string,
fyYr: string,
createdBy: string,
rows: any[]
) => ({
RFQ_NO: rfqNumber,
FY_YR: fyYr,
CREATED_BY: createdBy,
PR_ITEMS: rows.map(mapPRItem),
});
