import { Routes, Route } from "react-router-dom";
import { AuthProvider } from "./MainApp/MainAppAuth/AuthContext";
import { PageTitleProvider } from "./MainApp/MainAppContexts/PageTitleContext";
import RequireAuth from "./MainApp/MainAppAuth/RequireAuth";
import Layout from "./MainApp/MainAppComponents/MainAppLayout/Layout";
import TGSApp from "./TGSApp/TGSApp";
import InactivityHandler from "./MainApp/MainAppSessionTimeOut/InactivityHandler";
import LoginPage from "./MainApp/MainAppComponents/MainAppPages/LoginPage";

function App() {
  return (
    <AuthProvider>
      <PageTitleProvider>
        <Routes>
          <Route path="/login" element={<LoginPage />} />
          <Route
            path="/"
            element={
              <RequireAuth>
                <>
                  <InactivityHandler />
                  <Layout />
                </>
              </RequireAuth>
            }
          >
            <Route path="TGSApp/*" element={<TGSApp />}></Route>
          </Route>
        </Routes>
      </PageTitleProvider>
    </AuthProvider>
  );
}

export default App;
